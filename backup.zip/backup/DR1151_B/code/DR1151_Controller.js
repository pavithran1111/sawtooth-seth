console.log("VMO2AB_Version2 - DR1151 Controller");
(function () {
  
  function loadGlassbox() {
    try {
      _detector.triggerABTestingEvent(
        "Adobe",
        "${campaign.id}",
        "${campaign.name}",
        "${campaign.recipe.name}",
        "${campaign.recipe.name}"
      );
    } catch (error) {
      console.log(error.message);
    }
  }
    loadGlassbox();

  function poll(fn, callback, errback, timeout, interval) {
    let endTime = Number(new Date()) + (timeout || 2000);
    interval = 1000;
    (function p() {
      // If the condition is met, we're done! 
      if (fn()) {
        callback();
      }
      // If the condition isn't met but the timeout hasn't elapsed, go again
      else if (Number(new Date()) < endTime) {
        setTimeout(p, interval);
      }
      // Didn't match and too much time, reject!
      else {
        errback(new Error('timed out for ' + fn + ': ' + arguments));
      }
    })();
  }
  poll(
    function () {
      return typeof jQuery == "function" && typeof $ == "function";
    },
    function () {
      // Done, success callback
      loadExperience();
    },
    function (err) {
      // Error, failure callback
      console.log("error: ", err);
    },
    40000
  );

  function loadExperience() {

    let flag1151;
		const login = getCookie("username");

		if (login) {
			let count = 0;
			const interval = setInterval(() => {
				if ($(".tariff-card__roof.tariff-card__roof_pink-customer").length) {	
          clearInterval(interval);
          flag1151 = false;
          return false;
        }
				else if	(++count > 15) {
          flag1151 = true;
          clearInterval(interval);
          return false;
				} else if (++count > 300) {
					clearInterval(interval);
				}
			}, 100);
		} else {
			flag1151 = true;
		}

    poll(
      function () {
				return (
					$(".device-customization__plan-picker-content").length &&	flag1151
				);
      },
      function () {
        // Done, success callback
        executeExprience();
      },
      function (err) {
        // Error, failure callback
        console.log("error: ", err);
      }
    );
  }

  function getCookie(name) {
    let pattern = RegExp(name + "=.[^;]*")
    let matched = document.cookie.match(pattern)
    if (matched) {
      let cookie = matched[0].split('=')
      return cookie !== '';
    }
    return false;
  }

  function executeExprience() {
    $('body').addClass('DR1151');
    fireOnLoadTracking();    
  }

  function fireOnLoadTracking() {
    let count = 0;
    const interval = setInterval(() => {
      if (!$("body").find(".onLoadTrackClick1151").length) {
        $("body").append('<div class="onLoadTrackClick1151" manual_cm_re = "DR1151-_-onLoad-_-Controller"></div>');
        setTimeout(function () {
          $("body").find(".onLoadTrackClick1151").click();
        }, 3000);
        clearInterval(interval);
      }
      else if(++count > 300){
        clearInterval(interval);
      }
    });
  }
})();