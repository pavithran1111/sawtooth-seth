console.log("VMO2AB_Version2 - DR1151 challenger");
(function () {
  
      function loadGlassbox() {
        try {
            _detector.triggerABTestingEvent(
                "Adobe",
                "${campaign.id}",
                "${campaign.name}",
                "${campaign.recipe.name}",
                "${campaign.recipe.name}"
            );
        } catch (error) {
            console.log(error.message);
        }
    }
    loadGlassbox();
  
    function GA4Integration(){
    if(typeof gtag !== "undefined"){
    	gtag('event', 'optimizely_campaign', {
        'optimizely_experiment': "O-27316960371" ,
        'optimizely_experiment_name': "DR1151 360 Tiered phone tariff design iteration",
        'optimizely_variant_name': "DR1151 b"
      });
    }
  }
  GA4Integration();

  function poll(fn, callback, errback, timeout, interval) {
    let endTime = Number(new Date()) + (timeout || 2000);
    interval = 3000;
    (function p() {
      // If the condition is met, we're done! 
      if (fn()) {
        callback();
      }
      // If the condition isn't met but the timeout hasn't elapsed, go again
      else if (Number(new Date()) < endTime) {
        setTimeout(p, interval);
      }
      // Didn't match and too much time, reject!
      else {
        errback(new Error('timed out for ' + fn + ': ' + arguments));
      }
    })();
  }
  poll(
    function () {
      return typeof jQuery == "function" && typeof $ == "function";
    },
    function () {
      // Done, success callback
      loadExperience();
    },
    function (err) {
      // Error, failure callback
      console.log("error: ", err);
    },
    40000
  );

  function loadExperience() {

    let flag1151;
		const login = getCookie("username");

		if (login) {
			let count = 0;
			const interval = setInterval(() => {
				if ($(".tariff-card__roof.tariff-card__roof_pink-customer").length) {	
          clearInterval(interval);
          flag1151 = false;
          return false;
        }
				else if	(++count > 15) {
          flag1151 = true;
          clearInterval(interval);
          return false;
				} else if (++count > 300) {
					clearInterval(interval);
				}
			}, 100);
		} else {
			flag1151 = true;
		}

    poll(
      function () {
				return (
					$(".device-customization__plan-picker-content").length &&	flag1151
				);
      },
      function () {
        // Done, success callback
        executeExprience();              
      },
      function (err) {
        // Error, failure callback
        console.log("error: ", err);
      }
    );
  }

  function getCookie(name) {
    let pattern = RegExp(name + "=.[^;]*");
    let matched = document.cookie.match(pattern);
    if (matched) {
      let cookie = matched[0].split('=');
      return cookie !== '';
    }
    return false;
  }

  function executeExprience() {
    addBanner();
    updateDR1151();
		addFamilyLinks();
    updatePlusPlan();
    $(document).on('click', '.global-header__navigation-menu.global-header__navigation-menu_opened .o2uk-container .row > div:first-child .row > .global-header__navigation-menu-item:first-child ul > li:nth-child(4)', function(){
    	console.log('click');
    	executeSPA();
    	addFamilyLinks();
    });
    $(document).on('click','.DR1151-family-container', function(){
      console.log('click SPA');
      executeSPA();
      addFamilyLinks();
      $('.device-details-header__main-content .family-links a[href="'+$(this).find('.o2uk-link').attr('href')+'"] .o2uk-link-text').click();
    });
	}
  
  function addFamilyLinks() {
    let count = 0;
    $('.DR1151-family-container').remove();
    const interval = setInterval(() => {
      if($("body").find(".o2uk-buble-loader_fade-out").length && $('.device-details-header__main-content .family-links .o2uk-link__container').length >=2){
        
        clearInterval(interval);
        $('.device-details-header__main-content .family-links > .o2uk-link__container').each(function(i, v){

          if(!$(v).attr('class').includes('DR1151-family-container') && i < $('.device-details-header__main-content .family-links .o2uk-link__container a').length){
            $('.device-details-header__main-content .family-links').append('<o2uk-link class="o2uk-link__container ng-star-inserted DR1151-family-container"><div accessiblelink="" class="o2uk-link o2uk-link_size_large ng-star-inserted" href="'+$(v).find('a').attr('href')+'" target="_self"><span class="ng-star-inserted"><span class="o2uk-link-text ng-star-inserted">'+$(v).find('.o2uk-link-text').text()+'</span></span></div></o2uk-link>');
            $(v).hide();
          }
        });
        setTimeout(()=>{
          removeExtraFamilyLink();
        }, 200);
        }
    else if(++count > 300){
      clearInterval(interval);
    }
  }, 300);
  }
  
  function removeExtraFamilyLink(){
    if($('.device-details-header__main-content .family-links .o2uk-link__container a').length !== $('.device-details-header__main-content .family-links .o2uk-link__container div').length){
    	let i = $('.device-details-header__main-content .family-links .o2uk-link__container a').length;
      for(a=0; a<i; a++){
        $('.device-details-header__main-content .family-links .o2uk-link__container div').last().parent('.o2uk-link__container').remove();
      }
    }
  }
  
  function updatePlusPlan() {
    let plusPlanRibbon = `<div class="plusPlanRibbon">PLUS PLAN</div>`;
    $(document).on('click', '.o2uk-scroll-wrapper div[role="listbox"]', function(){
      $('.tariff-card__wrapper .plusPlanRibbon').remove();
      let count = 0;
      const interval = setInterval(() => {
      if($("body").find(".o2uk-buble-loader_fade-out").length){
        $('.tariff-card__container').each(function () {
          clearInterval(interval);
          if ($(this).find('.tariff-card__wrapper h2.font_bold').html().includes('Plus')) {
            $(this).find('.tariff-card__wrapper').prepend(plusPlanRibbon);
          }
        });
      }
      else if(++count> 300){
        clearInterval(interval);
      }
      }, 300);
    });
  }
  
  function executeSPA(){
   sessionStorage.removeItem("bannerFlag");
    setTimeout(()=>{
      let count = 0;
      const interval = setInterval(() => {
        if ($("body").find(".o2uk-buble-loader_fade-out").length > 0) {
          clearInterval(interval);
          addBanner();
          setTimeout(()=>{
            let bannerFlag = true;
            if($('.tab-slider-body-content > .o2uk-container').length == 1 && sessionStorage.getItem('bannerFlag') == null){
              plusPlanRibbon1151();
            }
            if($('.tab-slider-body-content > .o2uk-container').length > 1){
              updateDR1151();
              sessionStorage.setItem('bannerFlag', $('.tab-slider-body-content > .o2uk-container').length);
              revertChanges();
            }
          }, 2200);
        }
        else if(++count > 300){
          clearInterval(interval);
        }
      }, 300);
    }, 400); 
  }

  function addBanner(){
    $('body').addClass('DR1151');
    const voltDiv = voltBoost();
    if (!$('.DR1151-container').length){
      setTimeout(()=>{
    	  $('body').find('.device-customization__plan-picker-content').before(voltDiv);
      }, 2000);
  	}
  }
  
  function revertChanges(){
  	$('.tab-slider-body-content > .o2uk-container:first-child').remove();
  }
  
  function updateDR1151() {
    $('body').addClass('DR1151');
    fireOnLoadTracking();
    // Interval for applying changes 
    let toApplyChanges1151Counter = 0;
    let toApplyChanges1151 = setInterval(function () {

      if ($('.tariff-card__container').length && $('.tariff-card__info-top-section').length && $('.o2uk-promo-block').length && $('.tariff-promos__wrapper_extras').length) {
        plusPlanRibbon1151();
        clearInterval(toApplyChanges1151);
      }
      else if (toApplyChanges1151Counter == 200) {
        clearInterval(toApplyChanges1151);
      }
      toApplyChanges1151Counter++;
    }, 50);

    // Handleing the tab Operation in the Mobile
    // if (window.innerWidth < 434) {
    //   $('.device-customization__plan-picker .tab-slider__topic').hide();
    //   let newTabs1151 = `<div class="wrapperNewTab1151">
    //         <div class="newTabs1151">
    //         <div class="tab-labels51" id="labelOne">
    //         <div class="tab-label-content1151">
    //             <p class="tab-text-border51 ng-star-inserted">Pick a pre-built plan</p><!----><!---->
    //         </div>
    //         </div>
    //         <div class="tab-labels51 activeTab51" id="labelTwo">
    //         <div class="tab-label-content1151 tab-label-border51">
    //             <p class="tab-text-border51 ng-star-inserted">Customise your plan</p><!----><!---->
    //         </div>
    //         </div>
    //     </div>
    //     <o2uk-ink-bar class="ink-bar51 mat-ink-bar51" style="visibility: visible; left: 0px; width: 150px;"></o2uk-ink-bar51>
    //     `;
    //   $('.device-customization__title:contains(Choose your plan)').after(newTabs1151);
    //   $(document).on('click', '.newTabs1151 .tab-labels51', function () {
    //     $('.cdk-overlay-panel').css('opacity', '0');

    //     $('.tab-labels51').removeClass('activeTab51');
    //     $(this).addClass('activeTab351');
    //     $('.device-customization__plan-picker').find('.o2uk-form-field-infix').click();
    //     if ($(this).attr('id') == 'labelOne') {
    //       $('.o2uk-option .o2uk-option-content:contains(Pick a pre-built plan)').click();
    //       $('.ink-bar51').css('transform', 'translateX(0px)');
    //       $('.cdk-overlay-panel').css('opacity', '1');

    //     }
    //     if ($(this).attr('id') == 'labelTwo') {
    //       $('.o2uk-option .o2uk-option-content:contains(Customise your plan)').click();

    //       $('.ink-bar51').css('transform', 'translateX(150px)');
    //       $('.cdk-overlay-panel').css('opacity', '1');
    //     }
    //   });
    // }

    // ------ Handelling all clicks  ---------
    // Click of Collapsing extras
    $(document).on('click', '.icon-chevron-down', function () {
      $(this).removeClass('icon-chevron-down');
      $(this).addClass('icon-chevron-up');
      $(this).parents('.tariff-card__container').find('.wrapForDropDivision').css('height', 'auto');
      $(this).parents('.tariff-card__container').find('.wrapForDropDivision > div').css('display', 'block');
    });
    $(document).on('click', '.icon-chevron-up', function () {
      $(this).removeClass('icon-chevron-up');
      $(this).addClass('icon-chevron-down');
      $(this).parents('.tariff-card__container').find('.wrapForDropDivision').css('height', '0');
      $(this).parents('.tariff-card__container').find('.wrapForDropDivision > div').css('display', 'none');
    });
    // Click of Use Calculator
    // $(document).on('click', '.useCalculator', function () {
    //     if (window.innerWidth < 434) {
    //         $('body').find('#labelTwo').click();
    //         setTimeout(function () {
    //             $('.device-customization__plan-picker-heading .o2uk-link:contains(Use our calculator)').click();
    //         }, 500);
    //     }
    //     else {
    //         $('body').find('.device-customization__plan-picker-tab .tab-label-container').last().click();
    //         $('body').find('.device-customization__plan-picker-tab .tab-label-container p').last().text('Customise your plan');
    //     }
    // });
    // Click of learn more information 
    $(document).on('click', '.learnMore', function () {
      $(".overlayTermsApply1151, .overlayGreyDR").show();
      $('html').css('overflow-y', 'hidden');
      $('body').addClass('overlayView');
    });
    $(document).on('click', '.overlayTermsApply1151 .boxclose,.overlayGreyDR', function () {
      console.log('terms');
      $(".overlayTermsApply1151, .overlayGreyDR").hide();
      $('body').removeClass('overlayView').attr("style", "");
      $('html').css('overflow-y', 'scroll');
    });

		triggerLearnMore();
    
    let newPopup1151 = `<div id="newPopup1151">
<div class="overlayTermsApply1151 newPopup1151">
<div class="box-header">
    <h3>What you get on Pay Monthly</h3>
    <o2uk-dialog-cross><button type="button" role="button" class="o2uk-dialog-title__button boxclose"><o2uk-svg-resolver
                role="presentation" classlist="o2uk-svg o2uk-svg_size_m o2uk-dialog-title__button-svg"
                svgid="icon-cross" class="svg-resolver o2uk-svg o2uk-svg_size_m" aria-hidden="true">
                <div class="o2uk-svg o2uk-svg_size_m o2uk-dialog-title__button-svg"><span
                        class="o2uk-icon-font icon-cross "></span></div>
                <title></title>
            </o2uk-svg-resolver><span class="sr-only">Close Dialog</span></button></o2uk-dialog-cross>
</div>
<div class="box-content scroll-bar">
    <h3>Unlimited minutes and texts</h3>
    <p>Enjoy Unlimited Data. Available on all phones.</p>

    <h3>Plans unlink after 24 months</h3>
    <p>For customers who took out an O2 Refresh custom plan on or after 17 December 2021, your Airtime Plan and Device plans unlink after 24 months. This means that if you are in the first 24 months of your Device Plan you will have to pay off your Device Plan in full if you decide to end your Airtime Plan (but we won’t charge you an Early Termination Charge to exit your Airtime Plan).</p>
    <p>
        After 24 months you can: (i) keep your Airtime and Device Plans without changing anything (ii) Cancel your Airtime Plan and keep paying off your Device Plan instalments or, (iii) Cancel your Airtime Plan and pay off your Device Plan in full.  For customers who took out an O2 Refresh custom plan before the 17 December 2021, the Airtime and Device Plans remain linked for the duration of the Device Plan, this means you will have to pay off your Device Plan in full if you decide to end your Airtime Plan at any point (but we won’t charge you an Early Termination Charge to exit your Airtime Plan).
    </p>
    <h3>5G network</h3>
    <p>All of our tariffs are 5G compatible, but in order to get 5G speeds you will need a 5G phone. O2 5G has coverage in areas of the following 30 towns and cities: Belfast, Birmingham, Bradford, Bristol, Cardiff, Chatham, Coventry, Derby, Eastbourne, Edinburgh, Gateshead, Glasgow, Leeds, Leicester, Lisburn, Liverpool, London, Lowestoft, Luton, Manchester, Mansfield, Newcastle, Northampton, North Shields, Norwich, Nottingham, Sheffield, Slough, South Shields and Stoke-on-Trent. <a href="https://www.o2.co.uk/termsandconditions/mobile/additional-terms-and-conditions-for-5g-services" target="_blank">Read full 5G Terms and conditions</a></p>
</div>
</div>
</div>
<div class="overlayGreyDR"></div>`;
    $('body').append(newPopup1151);
    let iPhone = /iPhone/i.test(navigator.userAgent) || $(document).width() <= 400;
    if(iPhone)
	    $('.device-customization__plan-picker-content .row > div > .tariff-card .amount-info-monthly').css('gap','5px');
  }
  
   function plusPlanRibbon1151() {
      let lengthOfTiles;
    	let lengthOfTilesOld = 0;
      let plusPlanRibbon = `<div class="plusPlanRibbon">PLUS PLAN</div>`;
      $('.tariff-card__container').each(function () {
        $(this).addClass('newTile1151');
        if ($(this).find('.tariff-card__wrapper h2.font_bold').html().includes('Plus')) {
          $(this).find('.tariff-card__wrapper').prepend(plusPlanRibbon);
        }
        if (!$(this).siblings('.tariff-card__roof').find('.tariff-card__roof-inner').length) {
          $(this).siblings('.tariff-card__roof').css('background-color', 'transparent');
        }
        $(this).find('.tariff-card__info-bottom-section .tariff-card__info_text').hide();
        // $(this).find('.tariff-promos__offer-content').hide();
        $(this).find('.tariff-card__info-bottom-section').css('height', 'auto');
        $(this).find('.tariff-card__info-top-section .tariff-card__info_text').html('<p class="addText">36 month Device Plan</p>');
        $(this).find('.tariff-card__info-top-section .tariff-card__info_text').append('<p class="addText">Monthly rolling Airtime Plan</p>');
        $(this).find('.tariff-card__info-top-section .tariff-card__info_text').append('<p class="addText">Plans unlinked after 24 months</p>');
        $(this).find('.tariff-card__info-top-section .tariff-card__info_text').after('<div class="tileTopPartline"></div>');

        $(this).find('.tariff-promos__volt-boost').parent('.tariff-promos__wrapper').hide();

        let div1ToSwitch = $(this).find('.o2uk-promo-block').last();

        let div2ToSwitch = $(this).find('.tariff-promos__wrapper_extras');
        $(this).find('.tariff-card__info-top-section').after(div1ToSwitch);
        $(this).find(div1ToSwitch).after(div2ToSwitch);
        if (!$(this).find('.pickOneButton').length) {
          $(div1ToSwitch).after('<div class="pickOneButton" manual_cm_re="DR1151-_-Challenger-_-Plus pick one Extra">Plus pick one Extra, on us<div manual_cm_re="DR1151-_-Challenger-_-Plus pick one Extra" class="pickOneArrow o2uk-icon-font icon-chevron-down"></div></div>');
        }
        $(div2ToSwitch).wrap('<div class="wrapForDropDivision"></div>');
        //$(this).find('.tariff-card__info-top-section').css('height', '15px');

        lengthOfTiles = $(this).find('.tariff-promos__offer').length;
        if (lengthOfTiles > lengthOfTilesOld) {
          lengthOfTilesOld = lengthOfTiles;
        }
        else {
          lengthOfTilesOld = lengthOfTilesOld;
        }

        $(this).find('.o2uk-promo-block__image-wrapper').hide();
        $(this).find('.tariff-card__price-block').css({ 'min-height': '70px', 'margin-top': '10px' });
        $(this).find('.tariff-card__price-wrapper').css('min-height', '55px');
        $(this).find('.tariff-card__data-info').css('min-height', '70px');
        $(this).find('.o2uk-promo-block_one-top-border').css('margin-top', '20px');
        $(this).find('.tariff-promos__offer-icon').css({ 'min-width': '30px', 'width': '30px', 'height': '30px' });

        let inforIcon = $(this).find('.o2uk-link-text:contains(Payment and plan details)').first().parents('.o2uk-link__container');
        $(this).find('.amount-info-monthly ').append(inforIcon);
        $(this).find('.o2uk-link-text:contains(Payment and plan details)').hide();
        $(this).find('.amount-info-monthly .o2uk-link').addClass('newInfoPosition');

        $(this).find('.o2uk-link-text:contains(Edit this plan)').first().parents('.o2uk-link__container').hide();
      });

      // To set heigh of offer tile section

      if (lengthOfTilesOld > 3) {
        $('.newTile1151').find('.tariff-promos__offer').parent('.tariff-promos__wrapper').css('height', '270px');
      }
      if (lengthOfTilesOld > 4) {
        $('.newTile1151').find('.tariff-promos__offer').parent('.tariff-promos__wrapper').css('height', '320px');
      }
      if (lengthOfTilesOld < 3) {
        $('.newTile1151').find('.tariff-promos__offer').parent('.tariff-promos__wrapper').css('height', '220px');
      }
    }

  function voltBoost() {
    return `<div class="o2uk-container DR1151-container"><div class="parentVolt newVoltDiv1151">
  <div class="child1Volt">
  <img src="https://econtent.o2.co.uk/o/econtent/media/get/51e6e48e-a2a3-4fac-8d51-54cb0d6767b7" alt="Image">
  </div>
  <div class="child2Volt">
  <h2>Volt boosts</h2>
  <p>Get double data when your household also has Virgin Media broadband.</p>
  <a class="learnMoreVolt" manual_cm_re="DR1151-_-Challenger-_-Volt-_-Learn More">Learn more.</a>
  </div></div></div>`;
  }
  
  function triggerLearnMore() {
    // Click of learn more Volt information 
    $(document).on('click', '.learnMoreVolt', function () {
        $('.tariff-promos__volt-boost .tariff-promos__volt-boost-wrapper .o2uk-link').first().click();
        setTimeout(()=>{
          if($('.cdk-overlay-container .cdk-global-overlay-wrapper').length > 1){
            $('.cdk-overlay-container >:last-child').remove();
            $('.cdk-overlay-container >:last-child').remove();
          }
        }, 50);
    });
  }

  function fireOnLoadTracking() {
    let count = 0;
    const interval = setInterval(() => {
      if (!$("body").find(".onLoadTrackClick1151").length) {
        $("body").append('<div class="onLoadTrackClick1151" manual_cm_re = "DR1151-_-onLoad-_-Challenger"></div>');
        setTimeout(function () {
          $("body").find(".onLoadTrackClick1151").click();
        }, 4000);
        clearInterval(interval);
      }
      else if(++count > 300){
        clearInterval(interval);
      }
    });
  }
})();