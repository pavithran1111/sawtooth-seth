$('.device-details-header__main-content .family-links > .o2uk-link__container').each(function(i, v){
  console.log($(v).find('.o2uk-link-text').text())
  $(v).find('a').after('<div accessiblelink="" class="o2uk-link o2uk-link_size_large ng-star-inserted DR1151-link" href="'+$(v).find('a').attr('href')+'" target="_self"><span class="ng-star-inserted"><span class="o2uk-link-text ng-star-inserted">'+$(v).find('.o2uk-link-text').text()+'</span></span></div>');
  $(v).find('a').hide()
});

$(document).on('click', '.DR1151-container', function(v){
	console.log('sdv')
	$('.family-links .o2uk-link__container:first-child a').click();
});

$('.device-details-header__main-content .family-links > .o2uk-link__container').each(function(i, v){
  console.log($(v).find('.o2uk-link-text').text())
});

$('.device-details-header__main-content .family-links > .o2uk-link__container').each(function(i, v){
  if(!$(v).attr('class').includes('DR1151-container')){
    $('.device-details-header__main-content .family-links').append('<o2uk-link class="o2uk-link__container ng-star-inserted DR1151-container" name="'+(i+1)+'"><div accessiblelink="" class="o2uk-link o2uk-link_size_large ng-star-inserted" href="'+$(v).find('a').attr('href')+'" target="_self"><span class="ng-star-inserted"><span class="o2uk-link-text ng-star-inserted">'+$(v).find('.o2uk-link-text').text()+'</span></span></div></o2uk-link>');
    $(v).hide();
  }
});


$(document).on('click','.DR1151-container', function(){
  console.log($(this).find('.o2uk-link').attr('href'))
  $('.device-details-header__main-content .family-links a[href="'+$(this).find('.o2uk-link').attr('href')+'"] .o2uk-link-text').click()
})




$(document).on('click','.DR1151-container', function(v){
  $('.device-details-header__main-content .family-links > .o2uk-link__container a[href="'+$(this).find('.o2uk-link').attr('href')+'"]').find('a')
});


$('.device-details-header__description').click(function(){
  $('.DR1151-test').trigger('click');
  $('.DR1151-test').click();
  console.log('sedf')
})


