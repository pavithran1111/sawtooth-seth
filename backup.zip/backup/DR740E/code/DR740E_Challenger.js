console.log("VMO2AB_Version2 DR740E Challenger");
(function () {
	// function loadGlassbox() {
	// 	try {
	// 			_detector.triggerABTestingEvent("Adobe", '${campaign.id}', '${campaign.name}', '${campaign.recipe.name}', '${campaign.recipe.name}');
	// 	}
	// 	catch (error) {
	// 			console.log(error.message);
	// 	}
  // }

	// loadGlassbox();

function poll(fn, callback, errback, timeout, interval) {
var endTime = Number(new Date()) + (timeout || 2000);
interval = interval || 100;
(function p() {
		// If the condition is met, we're done! 
		if (fn()) {
			callback();
		}
		// If the condition isn't met but the timeout hasn't elapsed, go again
		else if (Number(new Date()) < endTime) {
			setTimeout(p, interval);
		}
		// Didn't match and too much time, reject!
		else {
			errback(new Error('timed out for ' + fn + ': ' + arguments));
		}
})();
}

poll(
function () {
  return typeof jQuery == "function" && typeof $ == "function";
},
function () {
  // Done, success callback
  loadExperience();
},
function (err) {
  // Error, failure callback
  console.log("error: ", err);
},
40000
);

function loadExperience() {
poll(
	function () {
    return !!$('.layout-content.portlet-layout').length;
	},
	function () {
			// Done, success callback
			executeExprience();
	},
	function (err) {
			// Error, failure callback
			console.log("error: ", err);
	},
	20000
);
}
		
function executeExprience() {
console.log("VMO2AB_Version2 DR740E Challenger");
$('.layout-content.portlet-layout > section:nth-child(3) .col-md-12 > div').children().remove();
let elements = '';

if(localStorage.getItem('devices') == null){
	
	let setLocationStorage = [{name:'Samsung Galaxy S23 Ultra', pageURL: '/shop/samsung/galaxy-s23-ultra', classification: 'phones, phones:SmartPhone, phones:Paymonthly', ribbon: 'Great low price. Ends 2 August.', sku: '1SAM32GN', ecomID: 'c492c6cf-e28d-4bf0-a2ca-255fb2b5a112', thumbnailURL: '//static-www.o2.co.uk/sites/default/files/samsung-s23-ultra-green-sku-header-201222.png'}, {name:'Apple iPhone 14', 'pageURL': '/shop/apple/iphone-14', classification: 'phones, phones:iPhone, phones:Paymonthly', ribbon: 'Great low price. Ends 4 October.', sku: 'MPUF3ZD/A', ecomID: 'f6ee5abb-62be-4f62-947f-442e8ef96939', thumbnailURL: '//static-www.o2.co.uk/sites/default/files/iphone-14-midnight-sku-header-070922.png'}, {name: 'Apple iPhone 14 Pro Max', 'pageURL': '/shop/apple/iphone-14-pro-max', classification: 'phones, phones:iPhone, phones:Paymonthly', ribbon: 'Great low price. Ends 4 October.', sku: 'MQ9T3ZDA', ecomID: '652b4980-0110-4b31-8e90-dc294c363704', thumbnailURL: '//static-www.o2.co.uk/sites/default/files/iphone-14-pro-max-deep-purple-sku-header-070922.png'}];
	localStorage.setItem('devices', JSON.stringify(setLocationStorage));
}

let devices = JSON.parse(localStorage.getItem('devices')).length == 3 ?  JSON.parse(localStorage.getItem('devices')) : [];

devices.forEach((v, i) => {
	let ribbon = getRibbonText(v.ecomID, v.sku);
	elements +=`<div class="at-table-column">
	<a href="${v.pageURL}" manual_cm_re="DR740E_${v.name}" data-cat="${v.classification}">
		<h3>${v.name}</h3>
	</a>
	<div class="ribbonContainer drClickable">
		<h4 data-ribbon="${ribbon}" data-deviceid="${v.ecomID}">${ribbon}</h4>
	</div>
	<a href="${v.pageURL}" manual_cm_re="DR740E_${v.name}" data-cat="${v.classification}">
		<img class="at-thumbnail" src="${v.thumbnailURL}"> <br>
		<p class="rec-cta">Buy now</p>
	</a>
</div>`;});

let $newdiv = $(`<div class="at-table">
        <div class="at-table-row">
        	<div class="recHeader">
          <h2 class="at-title">Most popular items</h2>
          <p class="product-cta" id="tablet-cta">
					<a href="https://www.o2.co.uk/shop/tablets#sort=content.sorting.featured&amp;page=1" manual_cm_re="DR740D_See all phones">See all tablets</a></p>
          <p class="product-cta" id="phone-cta"><a href="https://www.o2.co.uk/shop/phones#sort=content.sorting.featured&amp;page=1" manual_cm_re="DR740D_See all phones">See all phones</a></p></div>${elements}</div></div>`);
$('.layout-content.portlet-layout > section:nth-child(3) .col-md-12 > div').append($newdiv);

	function getRibbonText(ecom, sku){
		let url = 'https://www.o2.co.uk/drupal/shop/ajax/custom/v2/device/'+ecom+'/tariffs?planCategory=normal&dataAllowanceType=smartphone&sku='+sku;
		let ribbonText="";
		$.ajax({url: url, async: false, success: function(data) {
				ribbonId = data.payMonthlyPlans.plans[0].campaignsAttached[0].campaignId;
				ribbonText = data.payMonthlyPlans.campaigns[ribbonId].ribbonText;
			}
		});
		return ribbonText;
	}
}
})();