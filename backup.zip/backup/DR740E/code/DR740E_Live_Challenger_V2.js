console.log("VMO2AB_Version2 DR740E Challenger V2");
(function () {
	// function loadGlassbox() {
	// 	try {
	// 			_detector.triggerABTestingEvent("Adobe", '${campaign.id}', '${campaign.name}', '${campaign.recipe.name}', '${campaign.recipe.name}');
	// 	}
	// 	catch (error) {
	// 			console.log(error.message);
	// 	}
  // }

	// loadGlassbox();

function poll(fn, callback, errback, timeout, interval) {
var endTime = Number(new Date()) + (timeout || 2000);
interval = interval || 100;
(function p() {
		// If the condition is met, we're done! 
		if (fn()) {
			callback();
		}
		// If the condition isn't met but the timeout hasn't elapsed, go again
		else if (Number(new Date()) < endTime) {
			setTimeout(p, interval);
		}
		// Didn't match and too much time, reject!
		else {
			errback(new Error('timed out for ' + fn + ': ' + arguments));
		}
})();
}

poll(
function () {
  return typeof jQuery == "function" && typeof $ == "function";
},
function () {
  // Done, success callback
  loadExperience();
},
function (err) {
  // Error, failure callback
  console.log("error: ", err);
},
40000
);

function loadExperience() {
poll(
	function () {
    return !!$('.layout-content.portlet-layout').length;
	},
	function () {
			// Done, success callback
			executeExprience();
	},
	function (err) {
			// Error, failure callback
			console.log("error: ", err);
	},
	20000
);
}
		
function executeExprience() {
console.log("VMO2AB_Version2 DR740E Challenger V2");
$('.layout-content.portlet-layout > section:nth-child(3) .col-md-12 > div').children().remove();
let elements = '';

let devices = JSON.parse(localStorage.getItem('devices')).length > 0 ?  JSON.parse(localStorage.getItem('devices')) : [];
let icon = `<a tabindex="0" data-qa-i-icon="" class="information pointOnHover" title="Learn more" data-v-f749b00e=""><span class="sr-only" data-v-f749b00e=""><!--v-if--><span data-v-f749b00e="">48 month Device Plan</span><span data-v-f749b00e=""> Monthly rolling Airtime Plan </span></span></a>`;
devices.forEach((v, i) => {
	//let {ribbonText, ribbonOverlayHtml } = getRibbonText(v.ecomID, v.sku);
	elements +=`<div class="at-table-column icon${i+2}">
	<a href="${v.pageURL}" manual_cm_re="DR740E_${v.name}" data-cat="${v.classification}">
		<h3>${v.name}</h3>
	</a>
	<div class="ribbonContainer drClickable">
    <h4 data-ribbon="${/*ribbonText*/v.ribbon}" data-deviceid="${v.ecomID}">${/*ribbonText*/v.ribbon}${icon}</h4>
    </div>
	<a href="${v.pageURL}" manual_cm_re="DR740E_${v.name}" data-cat="${v.classification}">
		<img class="at-thumbnail" src="${v.thumbnailURL}"> <br>
		<p class="rec-cta">Buy now</p>
	</a></div>`;});
//${ribbonOverlayHtml}
//${ ribbonText.includes('Terms apply') ? icon: ''}

let $newdiv = $(`<div class="at-table DR740E">
        <div class="at-table-row">
        	<div class="recHeader">
          <h2 class="at-title">Recently viewed</h2>
          <p class="product-cta" id="tablet-cta">
					<a href="https://www.o2.co.uk/shop/tablets#sort=content.sorting.featured&amp;page=1" manual_cm_re="DR740D_See all phones">See all tablets</a></p>
          <p class="product-cta" id="phone-cta"><a href="https://www.o2.co.uk/shop/phones#sort=content.sorting.featured&amp;page=1" manual_cm_re="DR740D_See all phones">See all phones</a></p></div>${elements}</div></div>`);
  $('.layout-content.portlet-layout > section:nth-child(3) .col-md-12 > div').append($newdiv);
  $('.layout-content.portlet-layout > section:nth-child(3)').show();
	/*function getRibbonText(ecom, sku){
		let url = 'https://www.o2.co.uk/drupal/shop/ajax/custom/v2/device/'+ecom+'/tariffs?planCategory=normal&dataAllowanceType=smartphone&sku='+sku;
		let ribbonText="";
		let ribbonOverlayHtml="";
		$.ajax({url: url, async: false, success: function(data) {
				ribbonId = data.payMonthlyPlans.plans[0].campaignsAttached[0].campaignId;
				ribbonText = data.payMonthlyPlans.campaigns[ribbonId].ribbonText;
				ribbonOverlayHtml = data.payMonthlyPlans.campaigns[ribbonId].ribbonOverlayHtml;
			}
		});
		return {ribbonText, ribbonOverlayHtml};
	}*/

	$(document).on("click", ".at-table-row .at-table-column:nth-child(2) a.pointOnHover, .at-table-row .at-table-column:nth-child(3) a.pointOnHover, .at-table-row .at-table-column:nth-child(4) a.pointOnHover", function() {
		$('body').find('.popUp740E').show();
		const icon = $(this).closest('.at-table-column').attr('class').split(' ');
		const digit = parseInt(icon[1].charAt(icon[1].length - 1));
		$('.popUp740E').find('.heading').html($('body').find('.at-table-row .'+icon[1]+':nth-child('+digit+') .box-header h3, .at-table-row .'+icon[1]+':nth-child('+digit+') .swap-header h3').text());
		$('.popUp740E').find('.box-content').html($('body').find('.at-table-row .'+icon[1]+':nth-child('+digit+') .box-content, .at-table-row .'+icon[1]+':nth-child('+digit+') .swap-content').html());
	});

	$(document).on("click", ".popUp740E .close", function() {
		$('body').find('.popUp740E').hide();
	});

	let popUp740E = `<div data-v-6454edfe="" class="popUp740E" id="popUp740E"><div data-v-6454edfe="" component-name="overlay" class="overlay-content-wrapper"><div data-v-6454edfe="" data-qa-offer-overlay="" class="o2-modal modal-open"><div data-v-6454edfe="" class="overlayContainerPromoIcon modal-body"><div data-v-6454edfe="">
<div component-name="overlay"><div class="box-header xxx"><span></span><h3 id="dialog-title" tabindex="0" class="heading"></h3></div>
</div>

<div class="box-content scroll-bar">

</div>
</div><div data-v-6454edfe="" id="closeBtn" class="btn-close"><button data-v-6454edfe="" data-qa-boxclose="" aria-label="Close" tabindex="0" class="close boxclose"></button></div></div></div></div><div data-v-6454edfe="" tabindex="-1" class="modal-backdrop fade in"></div></div>`;
$('body').append(popUp740E);

}
})();