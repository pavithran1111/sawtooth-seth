console.log("VMO2AB_Version2 DR740E Devices");
(function () {

function poll(fn, callback, errback, timeout, interval) {
var endTime = Number(new Date()) + (timeout || 2000);
interval = interval || 100;
(function p() {
		// If the condition is met, we're done! 
		if (fn()) {
			callback();
		}
		// If the condition isn't met but the timeout hasn't elapsed, go again
		else if (Number(new Date()) < endTime) {
			setTimeout(p, interval);
		}
		// Didn't match and too much time, reject!
		else {
			errback(new Error('timed out for ' + fn + ': ' + arguments));
		}
})();
}

poll(
function () {
  return typeof jQuery == "function" && typeof $ == "function";
},
function () {
  // Done, success callback
  loadExperience();
},
function (err) {
  // Error, failure callback
  console.log("error: ", err);
},
40000
);

function loadExperience() {
poll(
	function () {
    return !!$('.container-fluid .product-background').length || $('.device-details-header__background').length > 0;
	},
	function () {
			// Done, success callback
			executeExprience();
	},
	function (err) {
			// Error, failure callback
			console.log("error: ", err);
	},
	20000
);
}
		
function executeExprience() {

  let count = 0;
  const interval = setInterval(()=>{

    if(($('.device-details-promo-offer__content .device-details-promo-offer__offer').find(':nth-child(2) > div > div:first-child .device-details-promo-offer__offer_item_description-title').text() !== '' && typeof deviceJson == 'undefined') || typeof deviceJson !== 'undefined'){
      clearInterval(interval);
      dataLocationStorage();
    }
    else if(count > 700){
      clearInterval(interval);
    }
    count++;
  }, 200);
}

function dataLocationStorage() {
  const pathname = window.location.pathname;
  const pathURL = window.location.pathname.indexOf("upgrade") > 0 ? pathname.replace("upgrade", "shop") : pathname;
  let isCOntractDevice, ribbonSelector, categoryString , deviceFamily, sku, ecomID, image = '';
  
  if(typeof deviceJson !== 'undefined'){
    //Legacy    
    //Category string params
    const productType = digitalData.product.producttype;
    // Define Category String 
    categoryString = productType + ", " + productType + ":" + deviceJson.productSubType;

    // Add contract type
    isCOntractDevice = deviceJson.contractType === "phones" || deviceJson.contractType === "tablets" || deviceJson.contractType === "smartwatches" || deviceJson.contractType === "mobile-broadband";

    if (isCOntractDevice && deviceJson.tabStatus.length > 0) {
      const conType = deviceJson.tabStatus.length === 2 ? productType + ":" + toTitleCase(deviceJson.tabStatus[0]) + ", " + productType + ":" + toTitleCase(deviceJson.tabStatus[1]) : productType + ":" + toTitleCase(deviceJson.tabStatus[0]);
      console.log('conType',conType);
      categoryString = categoryString + ", " + conType;
    }

    //Universal Ribbons
    ribbonSelector = document.querySelector("div[data-qa-calculator-offer].hide-offers-in-mobile  p.offer-text") || document.querySelector("div.offers  p.offer-text") || document.querySelector('.pd-offer-section .offer-text');
    ribbonSelector = ribbonSelector.textContent.replace('link opens in popup window','').trim()
    deviceFamily = digitalData.product.devicefamily;
    sku = digitalData.product.devicesku.replace('/','');
    ecomID = deviceJson.dynamicLeadVariantId;
    image = deviceJson.media.images.hero.img_url;
  }
  else {
    //360
    //Category string params
    let deviceData = window.ncPortlets.DeviceDetailsPortlet.initData.deviceDetails;                        
    const productType = deviceData.offeringGroupName.toLocaleLowerCase();
    console.log(productType+' test');
    // Define Category String
    let categoryString = productType + ", " + productType + ":" + deviceData.name;
    // Add contract type
    let devices = ['phones', 'tablets', 'smartwatches', 'mobile-broadband'];
    if($.inArray(deviceData.offeringGroupName.toLocaleLowerCase(), devices)!==-1){
      const conType = productType + ":";
      categoryString = categoryString + ", " + conType;
    }
    
    //Universal Ribbons
    //ribbonSelector = document.querySelector('.device-promo__wrapper .device-promo__item:first-child .device-promo__info-title');
    ribbonSelector = $('.device-details-promo-offer__content .device-details-promo-offer__offer').find(':nth-child(2) > div > div:first-child .device-details-promo-offer__offer_item_description-title').text().trim();
    deviceFamily = deviceData.brand+' '+deviceData.code.replace('New','');
    sku = deviceData.skuCode.replace('/','');
    ecomID = deviceData.image.split('get/')[1];
    image = deviceData.image;
  }
  
  const currentData = {name: deviceFamily, pageURL: pathURL, classification: categoryString, ribbon: ribbonSelector, sku: sku, ecomID: ecomID, thumbnailURL: image};
  let devices = [];
  //console.log(JSON.parse(localStorage.getItem('devices')).length <= 2);
  if(localStorage.getItem('devices') == null){
    devices.push(currentData);
    localStorage.setItem('devices', JSON.stringify(devices));
  }
  else if(JSON.parse(localStorage.getItem('devices')).length <= 2){
    let prevData = JSON.parse(localStorage.getItem('devices'));
      if(checkDuplicate(prevData, currentData.name)){
        devices.push(currentData);
        devices.push(prevData[0]);
        if(JSON.parse(localStorage.getItem('devices')).length == 2)
          devices.push(prevData[1]);
        localStorage.setItem('devices', JSON.stringify(devices));
      }
  }
  else {
    let prevData = JSON.parse(localStorage.getItem('devices'));
    if(checkDuplicate(prevData, currentData.name)){
      devices.push(currentData);
      devices.push(prevData[0]);
      devices.push(prevData[1]);
      console.log('devices',devices);
      localStorage.setItem('devices', JSON.stringify(devices));
    }
  }
}

function checkDuplicate(prevData, currentName){
  let flag = true;
  prevData.forEach(function(v, i){
    if(v.name == currentName){
      flag = false;
      return;
    }
  });
	return flag;
}

function toTitleCase(str) {
  return str.replace(/\w\S*/g, function (txt) {
    return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
  });
}
})();