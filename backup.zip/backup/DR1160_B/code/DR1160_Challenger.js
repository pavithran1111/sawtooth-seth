(function () {
  console.log("VMO2AB_Version2 DR1160 Challenger Phase 2");

  function loadGlassbox() {
    try {
      _detector.triggerABTestingEvent(
        "Adobe",
        "${campaign.id}",
        "${campaign.name}",
        "${campaign.recipe.name}",
        "${campaign.recipe.name}"
      );
    } catch (error) {
      console.log(error.message);
    }
  }
  loadGlassbox();

  function poll(fn, callback, errback, timeout, interval) {
    var endTime = Number(new Date()) + (timeout || 2000);
    interval = interval || 100;
    (function p() {
      // If the condition is met, we're done!
      if (fn()) {
        callback();
      }
      // If the condition isn't met but the timeout hasn't elapsed, go again
      else if (Number(new Date()) < endTime) {
        setTimeout(p, interval);
      }
      // Didn't match and too much time, reject!
      else {
        errback(new Error("timed out for " + fn + ": " + arguments));
      }
    })();
  }

  poll(
    function () {
      return typeof jQuery == "function" && typeof $ == "function";
    },
    function () {
      // Done, success callback
      loadExperience();
    },
    function (err) {
      // Error, failure callback
      console.log("error: ", err);
    },
    40000
  );

  function loadExperience() {
    poll(
      function () {
        return (
          $("body").find(".billBoardBackgroundImage").length > 0 &&
          !$("body").hasClass("DR1160") && utag_data_copy.page_name.includes('portal:con|black-friday-cyber-monday|home')
        );
      },
      function () {
        // Done, success callback
        executeExperience();
      },
      function (err) {
        // Error, failure callback
        console.log("error: ", err);
      },
      20000
    );
  }

  function executeExperience() {
    $("body").addClass("DR1160");
    $(blackFridayCasousel()).insertAfter(
      ".layout-content.portlet-layout > section:nth-child(4)"
    );
    $(spaceBelowSIMO()).insertAfter(".black-friday");
    setTimeout(() => {
      scrollBehaviour();
    }, 1000);
    $(".Dots > a:first-child").addClass("Dot--active");
  }

  function blackFridayCasousel() {
    return '<section class="bg- black-friday"><div class="container-fluid px-3 py-3">	<div class="row "><div class="col-md-12"><div id="fragment-0-msxt"><div class="portlet-boundary portlet-boundary_com_liferay_journal_content_web_portlet_JournalContentPortlet_  portlet-static portlet-static-end portlet-journal-content " id="p_p_id_com_liferay_journal_content_web_portlet_JournalContentPortlet_INSTANCE_TIOh4KTvTjD6_"><span id="p_com_liferay_journal_content_web_portlet_JournalContentPortlet_INSTANCE_TIOh4KTvTjD6"></span><section class="portlet mb-0 top-content" id="portlet_com_liferay_journal_content_web_portlet_JournalContentPortlet_INSTANCE_TIOh4KTvTjD6"><div class="portlet-content"><div class="autofit-float autofit-row portlet-header"><div class="autofit-col autofit-col-end"><div class="autofit-section"><div class="visible-interaction"></div></div></div></div>			<div class=" portlet-content-container">	<div class="portlet-body">		<div class="" data-fragments-editor-item-id="172001-9197738" data-fragments-editor-item-type="fragments-editor-mapped-item">		<div class="journal-content-article " data-analytics-asset-id="8921607" data-analytics-asset-title="BF PAYM Sim only Carousel - Phase 1 - 02.11.2023" data-analytics-asset-type="web-content"><div class="Background-container dark " id="moreoffers"><div class="top-spacer hide"></div>    <div component="Background" class="background clipped-wrapper   " style="background-color: #0D0E3A;">        <div class="top-mask hide"></div>		  <div class="bg-img backgroundFixer2000" style="background-color: #0D0E3A;padding-top:40px;padding-bottom:20px; ">          <div class="container" style="">           <div class="row header-content headerContentDownSpacer">                <div class="col-xs-12 dark"><h2>Bag a Black Friday sim only deal today</h2><p>Don\'t miss out. Save more with a 24-month sim only Plus Plan, on selected tariffs.</p>                </div>            </div> 			               <div component="shopOfferComponent" class="shopOfferComponent">				<div class="shopOfferWrapper"><div class="row slick-initialized slick-initialized slick-slider slick-dotted"><div class="slick-list"><div class="slick-track"><main class="Main"><section class="Carousel" id="carousel" tabindex="-1"><article class="Card Card--overlay Card--portrait" id="card-1">      <div class="Card__media"> <div class="slick-list"><div class="slick-track"><div class="device-detail-tile slick-slide slick-current slick-active" data-slick-index="0"  id="slick-slide20"><div class="non-clickable-tile active-device-tile">	<div class="device-tile-image">		<img src="//static-www.o2.co.uk/sites/default/files/30gb-bf-img-text-module-1100.png?t=1698930235310" data-min-width-320="//static-www.o2.co.uk/sites/default/files/30gb-bf-img-text-module-574.png?t=1698930235198" data-min-width-1100="//static-www.o2.co.uk/sites/default/files/30gb-bf-img-text-module-1100.png?t=1698930235310" alt="30 GB Plus Plan" data-init-response="//static-www.o2.co.uk/sites/default/files/30gb-bf-img-text-module-1100.png?t=1698930235310">		</div>	<div class="device-tile-info"><h3 class="tile-heading"></h3><div class="tile-content"><p>Get a sim only 30GB Plus Plan for just £12.99 a month. Ends 6 Dec.</p></div>	</div>	<div class="tile-button">		<a href="https://www.o2.co.uk/shop/sim-cards/sim-only-deals" target="" title="Shop your sim" role="button" manual_cm_re="shopoffer-_-5_1-_-DR1160-_-30GB Plus Plan for £12.99">			<div class="cta">Shop your sim</div>		</a>     	</div></div></div> </div></article>              <article class="Card Card--overlay Card--portrait" id="card-2">      <div class="Card__media"> <div class="slick-list"><div class="slick-track" ><div class="device-detail-tile slick-slide slick-current slick-active" data-slick-index="0" id="slick-slide20"><div class="non-clickable-tile active-device-tile"><div class="device-tile-image">		<img src="//static-www.o2.co.uk/sites/default/files/150gb-bf2-img-text-module-1100.png?t=1698930235310" data-min-width-320="//static-www.o2.co.uk/sites/default/files/150gb-bf2-img-text-module-574.png?t=1698930235198" data-min-width-1100="//static-www.o2.co.uk/sites/default/files/150gb-bf2-img-text-module-1100.png?t=1698930235310" alt="150 GB Plus Plan" data-init-response="//static-www.o2.co.uk/sites/default/files/150gb-bf2-img-text-module-1100.png?t=1698930235310">		</div>	<div class="device-tile-info">		<div class="tile-content"><p>Grab a sim only 150GB Plus Plan for just £17.99 a month. Ends 6 Dec.</p></div>	</div>	<div class="tile-button">		<a href="https://www.o2.co.uk/shop/sim-cards/sim-only-deals" target="" title="Shop your sim" role="button" manual_cm_re="shopoffer-_-5_1-_-DR1160-_-150GB Plus Plan for £17.99">			<div class="cta">Shop your sim</div>		</a>     	</div></div></div> </div></div>   </article><article class="Card Card--overlay Card--portrait" id="card-3">      <div class="Card__media"> <div class="slick-list"><div class="slick-track"><div class="device-detail-tile slick-slide slick-current slick-active" data-slick-index="0" id="slick-slide20"><div class="non-clickable-tile active-device-tile"><div class="device-tile-image">		<img src="//static-www.o2.co.uk/sites/default/files/unlimited-bf2-img-text-module-1100.png?t=1698930235310" data-min-width-320="//static-www.o2.co.uk/sites/default/files/unlimited-bf2-img-text-module-574.png?t=1698930235310" data-min-width-1100="//static-www.o2.co.uk/sites/default/files/unlimited-bf2-img-text-module-1100.png?t=1698930235310" alt="Unlimited Plus Plan" data-init-response="//static-www.o2.co.uk/sites/default/files/unlimited-bf2-img-text-module-1100.png?t=1698930235310">		</div>	<div class="device-tile-info">		<div class="tile-content"><p>Bag a sim only Unlimited Plus Plan for just £25.99 a month. Ends 6 Dec.</p></div>	</div>	<div class="tile-button">		<a href="https://www.o2.co.uk/shop/sim-cards/sim-only-deals" target="" title="Shop your sim" role="button" manual_cm_re="shopoffer-_-5_1-_-DR1160-_-Unlimited Plus Plan for £25.99">			<div class="cta">Shop your sim</div>		</a>     	</div></div></div> </div></div>   </article><article class="Card Card--overlay Card--portrait" id="card-4">      <div class="Card__media"> <div class="slick-list"><div class="slick-track"><div class="device-detail-tile slick-slide slick-current slick-active" data-slick-index="0" id="slick-slide20"><div class="non-clickable-tile active-device-tile"><div class="device-tile-image">		<img src="//static-www.o2.co.uk/sites/default/files/12gb-bf-img-text-module-1100.png?t=1698930235310" data-min-width-320="//static-www.o2.co.uk/sites/default/files/12gb-bf-img-text-module-574.png?t=1698930235310" data-min-width-1100="//static-www.o2.co.uk/sites/default/files/12gb-bf-img-text-module-1100.png?t=1698930235310" alt="12 GB Plus Plan" data-init-response="//static-www.o2.co.uk/sites/default/files/12gb-bf-img-text-module-1100.png?t=1698930235310">		</div>	<div class="device-tile-info">		<div class="tile-content"><p>Bag a sim only 12GB Plus Plan. Yours for just £16.99 a month. Ends 6 Dec.</p></div>	</div>	<div class="tile-button">		<a href="https://www.o2.co.uk/shop/sim-cards/sim-only-deals" target="" title="Shop your sim" role="button" manual_cm_re="shopoffer-_-5_1-_-DR1160-_-12GB Plus Plan for £16.99">			<div class="cta">Shop your sim</div>		</a>     	</div></div></div> </div></div>   </article> </section></main>               </div></div></div></div></div><nav class="Pagination"><button class="Arrow" type="button" aria-controls="carousel" disabled=""><span class="Hidden">Previous slide</span></button><button class="Arrow" type="button" aria-controls="carousel"><span class="Hidden">Next slide</span></button><div class="Dots"><a href="#card-1" class="Dot" tabindex="-1"><span class="Hidden">Slide 1</span></a><a href="#card-2" class="Dot" tabindex="-1"><span class="Hidden">Slide 2</span></a><a href="#card-3" class="Dot" tabindex="-1"><span class="Hidden">Slide 3</span></a><a href="#card-4" class="Dot" tabindex="-1"><span class="Hidden">Slide 4</span></a></div></nav><div class="row"><div class="col-xs-12"> <div class="cta-cont"><a class="manual_cm_re" href="https://www.o2.co.uk/shop/sim-cards/sim-only-deals" title="See all sim offers" target="" role="button" manual_cm_re="GenericBackground-_-5_1-_-Pay Monthly Black Friday sim only deals">						<div class="cta">See all sim offers</div>						 </a>   </div>					</div>				  </div>          </div>        </div>        <div class="bottom-mask hide"></div>     </div>     <div class="bottom-spacer hide"></div></div>		</div>	</div>	</div>	</div>	</div></section>	</div></div></div></div></div></section>';
  }

  function spaceBelowSIMO() {
    return '<section class="bg-" style=""><div class="container px-3 py-3"><div class="row"><div class="col-md-12"><div id="fragment-0-mzdl"><div class="portlet-boundary portlet-boundary_com_liferay_journal_content_web_portlet_JournalContentPortlet_ portlet-static portlet-static-end portlet-journal-content" id="p_p_id_com_liferay_journal_content_web_portlet_JournalContentPortlet_INSTANCE_5ordxmpa7fif_"><span id="p_com_liferay_journal_content_web_portlet_JournalContentPortlet_INSTANCE_5ordxmpa7fif"></span><section class="portlet mb-0 top-content" id="portlet_com_liferay_journal_content_web_portlet_JournalContentPortlet_INSTANCE_5ordxmpa7fif"><div class="portlet-content"><div class="autofit-float autofit-row portlet-header"><div class="autofit-col autofit-col-end"><div class="autofit-section"><div class="visible-interaction"></div></div></div></div><div class="portlet-content-container"><div class="portlet-body"><div class="" data-fragments-editor-item-id="172001-3701336" data-fragments-editor-item-type="fragments-editor-mapped-item"><div class="journal-content-article" data-analytics-asset-id="3702601" data-analytics-asset-title="BFCM Spacer for Carousels" data-analytics-asset-type="web-content"><div component-name="spacer" class="clear-fix" style="height:4px"></div></div></div></div></div></div></section></div></div></div></div></div></section>';
  }

  function scrollBehaviour() {
    // Respect user perference
    const isReducedMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    ).matches;

    // Helper to apply inline CSS
    /*const setStyleProps = ($el, styles) => {
  for (const [key, value] of Object.entries(styles)) {
    if (value === false) {
      $el.style.removeProperty(key);
    } else {
      $el.style.setProperty(key, value);
    }
  }
};*/

    document.querySelectorAll(".Carousel").forEach(($carousel) => {
      $carousel.scrollLeft = 0;

      const $cards = Array.from($carousel.querySelectorAll(".Card"));
      //  const $pagination = $carousel.nextElementSibling;
      const $pagination = $carousel.closest(
        ".shopOfferComponent"
      ).nextElementSibling;
      // const $pagination = $('.Pagination');
      const [$previous, $next] = $pagination.querySelectorAll(".Arrow");
      $pagination.querySelector(".Dot").classList.add("Dot--active");

      const $start = document.createElement("div");
      const $end = document.createElement("div");
      $carousel.prepend($start);
      $carousel.append($end);

      const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
          if (entry.target === $start) {
            if ($previous) {
              $previous.disabled = entry.isIntersecting;
            }
          }
          if (entry.target === $end) {
            if ($next) {
              $next.disabled = entry.isIntersecting;
            }
          }
        });
      });
      observer.observe($start);
      observer.observe($end);

      const scrollTo = ($card) => {
        let offset = getOffset($card);
        const left = document.dir === "rtl" ? -offset : offset;
        const behavior = isReducedMotion ? "auto" : "smooth";
        $carousel.scrollTo({ left, behavior });
      };

      const getOffset = ($el) => {
        let offset = $el.offsetLeft;
        if (document.dir === "rtl") {
          offset = $carousel.offsetWidth - (offset + $el.offsetWidth);
        }
        return offset;
      };

      $previous.addEventListener("click", (ev) => {
        ev.preventDefault();
        let $card = $cards[0];
        const scroll = Math.abs($carousel.scrollLeft);
        $cards.forEach(($item) => {
          const offset = getOffset($item);
          if (offset - scroll < -1 && offset > getOffset($card)) {
            $card = $item;
          }
        });
        scrollTo($card);
      });

      $next.addEventListener("click", (ev) => {
        ev.preventDefault();
        let $card = $cards[$cards.length - 1];
        const scroll = Math.abs($carousel.scrollLeft);
        $cards.forEach(($item) => {
          const offset = getOffset($item);
          if (offset - scroll > 1 && offset < getOffset($card)) {
            $card = $item;
          }
        });
        scrollTo($card);
      });

      $pagination.addEventListener("click", (ev) => {
        if (ev.target.classList.contains("Dot")) {
          ev.preventDefault();
          const $card = document.querySelector(new URL(ev.target.href).hash);
          if ($card) scrollTo($card);
        }
      });

      // Highlight nearest "Dot" in pagination
      let scrollTimeout;
      $carousel.addEventListener(
        "scroll",
        () => {
          clearTimeout(scrollTimeout);
          scrollTimeout = setTimeout(() => {
            let $dot = $pagination.querySelector(".Dot--active");
            if ($dot) $dot.classList.remove("Dot--active");
            let $active;
            const scroll = Math.abs($carousel.scrollLeft);
            if (scroll <= 0) {
              $active = $cards[0];
            }
            if (scroll >= $carousel.scrollWidth - $carousel.offsetWidth) {
              // let len = $cards.length - 1;
              // if($(document).width()>= 601)
              // 	len = 2;
              $active = $cards[$cards.length - 1];
            }

            if (!$active) {
              let oldDiff;
              $cards.forEach(($card) => {
                const newDiff = Math.abs(scroll - getOffset($card));
                if (!$active || newDiff < oldDiff) {
                  $active = $card;
                  oldDiff = newDiff;
                }
              });
            }
            //$dot = $pagination.querySelector(`[href="#${($active ?? $card[0]).id}"]`);
            const href = ($active ? $active: $card[0]).id;
            $dot = $pagination.querySelector('[href="#'+href+'"]');
            if ($dot) $dot.classList.add("Dot--active");
          }, 50);
        },
        { passive: true }
      );

      // Improve arrow key navigation
      $carousel.addEventListener("keydown", (ev) => {
        if (/^(Arrow)?Left$/.test(ev.key)) {
          ev.preventDefault();
          (document.dir === "rtl" ? $next : $previous).click();
        } else if (/(Arrow)?Right$/.test(ev.key)) {
          ev.preventDefault();
          (document.dir === "rtl" ? $previous : $next).click();
        }
      });
    });
  }
})();