console.log("VMO2AB_DR1212 Version2");
(function () {
    function poll(conditionFn, successCallback, errorCallback, timeout = 20000, interval = 500) {
        const endTime = Number(new Date()) + timeout;

        (function checkCondition() {
            if (conditionFn()) {
                successCallback();
            } else if (Number(new Date()) < endTime) {
                setTimeout(checkCondition, interval);
            } else {
                errorCallback(new Error('Timed out'));
            }
        })();
    }

    poll(
        function () {
            return typeof jQuery === "function" && typeof $ === "function" && $('.o2uk-sort-and-filter__dropdown-wrapper').length && typeof (lpTag) != 'undefined' && ($('body').find('button:contains(Give Feedback)').length || $('body').find('button:contains(Give feedback)').length) && !$('body').hasClass('DR1212').length;
        },
        function () {
            executeExperience();
        },
        function (err) {
            console.error("Error: ", err);
        },
        40000
    );

    function executeExperience() {
        // function execute1190() {
        console.log("Executed DR1212");
        $('body').addClass('DR1212');
        localStorage.setItem("test-name", "VMO2AB_DR1212_Version2");

        let newRoundel = `<div class="roundel_dr1212_container">
                <div class="roundel_dr1212_options">
                    <div class="roundel_dr1212_option" id="roundel_dr1212_options_chat">
                    <span class="roundel-1212-text">Chat</span>
                    <div class="logo_container">
                        <img src='https://static-www.o2.co.uk/sites/default/files/chat-icon-white-outline.svg'/>
                    </div>
                    </div>

                    <div class="roundel_dr1212_option" id="roundel_dr1212_options_feedback">
                    <span class="roundel-1212-text">Give feedback</span>
                    <div class="logo_container">
                        <img src='https://static-www.o2.co.uk/sites/default/files/feedback-icon-white-outline.svg'/>
                    </div>
                    </div>

                    <div class="roundel_dr1212_option" id="roundel_dr1212_options_switchUp"><span class="roundel-1212-text">Switch Up Guide</span><img src='https://static-www.o2.co.uk/sites/default/files/blue-switch-up-icon.png'/></div>
                </div> 
                <div class="roundel_dr1212_button"> Help</div >
                </div >`;

        $('body').append(newRoundel);
        // }


        $('.roundel_dr1212_option').css({
            'opacity': '0',
            'transform': 'translateY(50px)'
        });

        $(document).off('mousedown').on('mousedown', '.roundel_dr1212_button', function (e) {
            console.log('roundel_dr1212_button clicked');

            const optionsElement = $('body').find('.roundel_dr1212_options');
            const backdropElement = $('body').find('.positioned-blur');

            if (optionsElement.hasClass('roundel_dr1212_options-open')) {
                optionsElement.removeClass('roundel_dr1212_options-open').addClass('roundel_dr1212_options-closing');
                optionsElement.find('.roundel_dr1212_option').css({
                    'opacity': '0',
                    'transform': 'translateY(20px)'
                });
                setTimeout(() => {
                    optionsElement.removeClass('roundel_dr1212_options-closing').css({
                        'visibility': 'hidden' // Hide after animation
                    });
                    backdropElement.removeClass('open');
                }, 500); // Duration should match transition time
            } else {
                optionsElement.css({
                    'visibility': 'visible' // Make visible before animation starts
                }).addClass('roundel_dr1212_options-open');
                optionsElement.find('.roundel_dr1212_option').each(function (index, element) {
                    setTimeout(() => {
                        $(element).css({
                            'opacity': '1',
                            'transform': 'translateY(0)'
                        });
                    }, index * 200); // Staggered appearance
                });
                backdropElement.addClass('open');
            }

            window['optimizely'] = window['optimizely'] || [];
            window['optimizely'].push({
                type: "event",
                eventName: "DR1212-Help-Button",
            });

        });

        // Chat Button click
        $(document).on('mousedown', '#roundel_dr1212_options_chat', function (e) {
            lpTag.taglets.rendererStub.click(6574324750);

            window['optimizely'] = window['optimizely'] || [];
            window['optimizely'].push({
                type: "event",
                eventName: "DR1212-Chat-Button",
            });
        });

        // Feedback button click
        $(document).on('mousedown', '#roundel_dr1212_options_feedback', function (e) {
            $('body').find('button:contains(Give Feedback)').length ? $('body').find('button:contains(Give Feedback)').trigger('click') : $('body').find('button:contains(Give feedback)').trigger('click');

            window['optimizely'] = window['optimizely'] || [];
            window['optimizely'].push({
                type: "event",
                eventName: "DR1212-Feedback-Button",
            });
        });

        $(document).on('mousedown', function (e) {
            if (!e.target.closest('.roundel_dr1212_button') && !e.target.closest('.roundel_dr1212_options') && $('body').find('.roundel_dr1212_options').hasClass('roundel_dr1212_options-open')) {
                $('body').find('.roundel_dr1212_button').trigger('mousedown');
            }
        });
        console.log('should started');
        // Check if utils and utag_obj are available in the window object
        if (window.optimizely && window.optimizely.get) {
            let utils = window.optimizely.get("utils");
            console.log('Optiizely should started');
            // Check if observeSelector method is available in the utils object
            if (utils && utils.observeSelector) {
                utils.observeSelector(
                    "o2uk-breadcrumbs",
                    function () {
                        if (
                            (!(window.location.href.includes('https://www.o2.co.uk/shop/sim-cards/sim-only-deals') || window.location.href.includes('https://www.o2.co.uk/shop/upgrade-simplicity')) || window.location.href.includes('https://www.o2.co.uk/shop/sim-cards/sim-only-deals/configuration'))  
                        ) {
                            // console.log('Should remove container');
                            $('body').find('.roundel_dr1212_container').remove();
                        }
                    },
                    {
                        once: false,
                    }
                );
            } else {
                console.error("observeSelector method is not available in utils object.");
            }
        } else {
            console.error("utils or utag_obj is not available in the window object.");
        }

    }
})();