console.log("VMO2AB_Version2 -  DR1117B Challenger");
(function () {
	// function loadGlassBox() {
	// 	try {
	// 		_detector.triggerABTestingEvent(
	// 			"Adobe",
	// 			"${campaign.id}",
	// 			"${campaign.name}",
	// 			"${campaign.recipe.name}",
	// 			"${campaign.recipe.name}"
	// 		);
	// 	} catch (error) {
	// 		console.log(error.message);
	// 	}
	// }
	function poll(fn, callback, errback, timeout, interval) {
		var endTime = Number(new Date()) + (timeout || 2000);
		interval = interval || 2000;
		(function p() {
			// If the condition is met, we’re done!
			if (fn()) {
				callback();
			}
			// If the condition isn’t met but the timeout hasn’t elapsed, go again
			else if (Number(new Date()) < endTime) {
				setTimeout(p, interval);
			}
			// Didn’t match and too much time, reject!
			else {
				errback(new Error("timed out for " + fn + ": " + arguments));
			}
		})();
	}
	poll(
		function () {
			return typeof jQuery == "function" && typeof $ == "function";
		},
		function () {
			// Done, success callback
			loadExperience();
			
		},
		function (err) {
			// Error, failure callback
			console.log("error: ", err);
		},
		20000
	);
	function loadExperience() {
    console.log('loadExp');
		poll(
			function () {
				// if (
				// 	utag_data.page_page_name != "" &&
				// 	!utag_data.page_page_name.includes("phones")
				// ) {
				// 	$(".dr1117B-style").remove();
				// }
				return (
					!!$("body").find(".o2uk-header-curve__container").length > 0 &&
					!$("body").hasClass("DR1117B") 
          // &&
					// utag_data.page_page_name.includes("phones")
				);
			},
			function () {
        console.log('testing');
				// loadGlassBox();
				executeExprience();
			},
			function (err) {
				// Error, failure callback
				console.log("error: ", err);
			},
			20000
		);
	}

	function includeStyleSheet() {
		return `<style class="dr1117B-style">
      html {
scroll-behavior: smooth;
}

#extrasSection .order-configuration__item {
  transition: all .5s ease-in;
  overflow: hidden;
}
#extrasSection > p {
  position: absolute;
  bottom: 35px;
  left: 50%;
  transform: translateX(-50%);
  color: #107ac0;
  font-weight: 600;
}
#extrasSection > p {
  bottom: 22px;
  color: #006;
  font-weight: 500;
}
#extrasSection > button {
  position: absolute;
  bottom: -30px;
  left: 50%;
  transform: translateX(-50%);
  transition: .7s;
  background-color: #107ac0;
  border-radius: 50%;
  padding: 15px;
  width: 60px;
  height: 60px;
  z-index: 1;
}
#extrasSection.active .dr1117B-extras-icon:before {
  transform: rotate(-90deg);
}

.dr1117B-extras-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 85%;
  height: 30%;
  position: relative;
  color: #fff;
  transition: box-shadow 150ms;
  font-size: 34px;
}
.dr1117B-extras-icon:before {
  position: absolute;
  transform: rotate(90deg);
  transition: .7s;
}
#extrasSection .order-configuration__perks-description > p:first-child {
  margin-bottom: 0;
}

#extrasSection .extras-selected {
  display: flex;
  align-items: center;
  gap: 10px;
  border: 2px solid #0a8a03;
  border-radius: 8px;
  padding: 21px 16px;
  position: relative;
}
#extrasSection .extras-desc p:first-child {
  font-size: 20px;
  font-weight: 600;
  text-align: left;
}
#extrasSection .extras-desc {
  display: flex;
  gap: 10px;
  flex-direction: column;
  align-items: flex-start;
}
#extrasSection .extras-text-selected {
  position: absolute;
  top: 0px;
  right: 0px;
  background-color: #0a8a03;
  color: #fff;
  padding: 2px 7px;
  border-bottom-left-radius: 4px;
  border-top-right-radius: 4px;
}

/* Extras Section Starts */

#extrasSection > button {
  z-index: 2;
}
#extrasSection {
  position: relative;
  /*border-top: unset;*/
  /*box-shadow: 0 3px 3px 0 rgb(0 0 0 / 5%), 0 0 12px 0 rgb(0 0 0 / 10%);*/
  padding-bottom: 127px;
}
.order-configuration__boltons-footer ._margin_top-l {
  margin-top: 10px;
}
#extrasSection > div._margin_bottom-s:nth-child(2){
  margin-bottom: 0;
}
#extrasSection .order-configuration__boltons-footer.h4 {
  display: none;
}
/* Extras Section Ends */

#extrasSection > button.view-all {
  position: absolute;
  bottom: 70px;
  background-color: #fff;
  color: #107ac0;
  border: 1px solid #107ac0;
  border-radius: 8px;
  width: 100%;
  z-index: 1;
  transition: all .7s ease-in;
}
#extrasSection > button.view-all {
  bottom: 60px;
}
#extrasSection .row.center {
  margin-right: 2px;
  margin-left: 2px;
}
@media only screen and (min-width: 1200px) {
  #extrasSection .order-configuration__item {
    margin: 0 auto;
  }
}

/*@media only screen and (min-width: 600px) {
  #extrasSection .row.center {
    margin-right: 2px;
    margin-left: 2px;
  }
}*/
@media only screen and (max-width: 599px) {
  #extrasSection .order-configuration__item {
    margin-top: 0;
  }
  #insurancesSection .order-configuration__item .row.center > div:first-child .insurance {
    min-height:	275px;
  }
  #insurancesSection .order-configuration__item .row.center > div:first-child .insurance .insurance__content {
    min-height: 165px;
  }
  /*#extrasSection .add-on:not(.add-on_not-focusable):focus, .add-on:not(.add-on_not-focusable):hover {
    margin-left: 7px;
    margin-right: 7px;
  }
  #extrasSection .row.center {
    margin-right: 2px;
    margin-left: 2px;
  }*/
}
@media only screen and (max-width: 478px) {
  #extrasSection > p {
    bottom: 9px;
  }
  #extrasSection.active .order-configuration__boltons-footer ._margin_top-l {
    margin-top: -9px;
  }
}
@media only screen and (max-width: 450px) {
  #extrasSection .extras-selected {
    padding: 35px 10px;
  }		
}
</style>`;
	}

	function executeExprience() {
    console.log('wafes');
    $("body").addClass("DR1117B");
		$("#o2uk-buble-loader")
    .removeClass("o2uk-buble-loader_fade-out")
    .addClass("o2uk-buble-loader_fade-in");
		$("#o2uk-buble-loader").css("background", "rgb(255, 255, 255, 0.8)");
		$("body").addClass("DR1117B");
		if (!$("body .dr1117B-style").length) $("body").append(includeStyleSheet());

		function extrasSection() {
			$('<button type="button" role="button" o2uk-primary-button="" manual_cm_re="VMO2AB-_-DR1117B-_-View-_-all-_-Extras" class="mat-button-base o2uk-primary-button view-all" style="display: inline-block;"><span class="mat-button-wrapper">View all Extras</span><div matripple="" aria-hidden="true" class="mat-ripple mat-button-ripple"></div><div aria-hidden="true" class="mat-button-focus-overlay"></div></button>'
			).insertAfter("#extrasSection .order-configuration__item");

			$(
				'<p class="DR1117B-extras">You have<strong> 1 Extra </strong>left to choose.</p>'
			).insertAfter("#extrasSection .order-configuration__item");
			$("#extrasSection .add-on__footer .mat-button-wrapper")
				.contents()
				.filter(function () {
					return this.nodeType == Node.TEXT_NODE;
				})
				.replaceWith("Pick this Extra");

			let extrasInitialHeight = getExtrasHeight();
			$("#extrasSection .order-configuration__item").css(
				"height",
				extrasInitialHeight + notificationHeight() + "px"
			);

			$("#extrasSection > button").click(function () {
				$("#extrasSection > button").css("pointer-events", "none");
				hideAdditionalSection();

				setTimeout(() => {
					$("#extrasSection").toggleClass("active");
					let extrasInitialHeight = getExtrasHeight();
					if (
						$("#extrasSection.active .order-configuration__item").length > 0
					) {
						let extraRow = 0;
						$(
							"#extrasSection .order-configuration__item > .row.center._margin_top-m"
						).each(function (i, v) {
							extraRow += $(v).height();
						});

						const height =
							extraRow +
							notificationHeight() +
							$(
								"#extrasSection .order-configuration__perks-description"
							).height() +
							($("#extrasSection .order-configuration__boltons-footer").length >
							0
								? $("#extrasSection .order-configuration__title").height() + 87
								: extrasInitialHeight) +
							"px";
						$("#extrasSection.active .order-configuration__item").css(
							"height",
							height
						);
						$("#extrasSection div._margin_bottom-s:nth-child(2)").show();
						$("#extrasSection > button .mat-button-wrapper").text(
							"Close Extras"
						);
					} else {
						document.querySelector("#extrasSection").scrollIntoView({
							behavior: "smooth",
							block: "start",
							inline: "start",
						});

						setTimeout(() => {
							$("#extrasSection .order-configuration__item").css(
								"height",
								extrasInitialHeight + notificationHeight() + "px"
							);
							//$("#extrasSection .extras-text").text("See Extras");
							$("#extrasSection > button .mat-button-wrapper").text(
								"View all Extras"
							);
							if ($("#extrasSection .add-on_checked").length > 0) {
								// addExtrasDiv();
								$("#extrasSection div._margin_bottom-s:nth-child(2)").hide();
							} else {
								$("#extrasSection div._margin_bottom-s:nth-child(2)").show();
							}
						}, 700);
					}
					$("#extrasSection > button").css("pointer-events", "auto");
				}, 500);
			});

			//Set dynamic height for extras section
			$(document).on(
				"click",
				"#extrasSection .order-configuration__item .mat-focus-indicator",
				function () {
					chooseExtras();
					setTimeout(() => {
						let extrasCount = 0;
						const extrasInterval = setInterval(() => {
							if (
								$("#o2uk-buble-loader").hasClass("o2uk-buble-loader_fade-out")
							) {
								let extrasInitialHeight = getExtrasHeight();
								let height = 0;
								if (
									$("#extrasSection.active .order-configuration__item").length >
									0
								) {
									let extraRow = 0;
									$(
										"#extrasSection .order-configuration__item > .row.center._margin_top-m"
									).each(function (i, v) {
										extraRow += $(v).height();
									});
									height =
										extraRow +
										notificationHeight() +
										$(
											"#extrasSection .order-configuration__perks-description"
										).height() +
										($("#extrasSection .order-configuration__boltons-footer")
											.length > 0
											? $(
													"#extrasSection .order-configuration__title"
											  ).height() + 87
											: extrasInitialHeight);
								} else height = extrasInitialHeight + notificationHeight();

								if (!$("#extrasSection").hasClass("active"))
									$("#extrasSection .order-configuration__item").css(
										"height",
										height + "px"
									);
								clearInterval(extrasInterval);
							} else if (extrasCount > 300) {
								clearInterval(extrasInterval);
							}
							extrasCount++;
						}, 300);
					}, 750);
				}
			);

			//Fire the click on extras notification
			// let extrasNotifyCount = 0;
			// const extrasNotify = setInterval(() => {
			// 	if($("#extrasSection .o2uk-notification-message").length > 0){
			// 		$('body').append('<div class="tracking-warning-message" manual_cm_re="DR1117-_-Challenger-_-Contain-_-Warning-_-Messages"></div>');
			// 		$("#extrasSection > button").trigger('click');
			// 		$(".tracking-warning-message").trigger('mousedown');
			// 		clearInterval(extrasNotify);
			// 	}
			// 	else if(extrasNotifyCount > 300){
			// 		clearInterval(extrasNotify);
			// 	}
			// 	extrasNotifyCount++;
			// }, 100);
		}

		//Dialog box edit your plan starts
		$(document).on("click", ".mat-focus-indicator", function () {
			hideAdditionalSection();
			if ($("#extrasSection").hasClass("active")) {
				let count2 = 0;
				const interval2 = setInterval(() => {
					if ($("#o2uk-buble-loader").hasClass("o2uk-buble-loader_fade-out")) {
						let extraRow1 = 0;
						$(
							"#extrasSection .order-configuration__item > .row.center._margin_top-m"
						).each(function (i, v) {
							extraRow1 += $(v).height();
						});
						let extrasInitialHeight = getExtrasHeight();
						const extrasHeight =
							extraRow1 +
							notificationHeight() +
							$(
								"#extrasSection .order-configuration__perks-description"
							).height() +
							($("#extrasSection .order-configuration__boltons-footer").length >
							0
								? $("#extrasSection .order-configuration__title").height() + 87
								: extrasInitialHeight) +
							"px";
						chooseExtras();
						$("#extrasSection.active .order-configuration__item").css(
							"height",
							extrasHeight
						);
						clearInterval(interval2);
					} else if (count2 > 1000) {
						clearInterval(interval2);
					}
					count2++;
				}, 100);
			}
		});
		//Dialog box edit your plan ends

		function getExtrasHeight() {
			let extrasInitialHeight =
				$("#extrasSection .order-configuration__title").height() +
				$("#extrasSection .order-configuration__perks-description").height() +
				92;

			if ($(document).width() > 599)
				extrasInitialHeight += $(
					"#extrasSection .order-configuration__item .row.center._margin_top-m > div:first-child"
				).height();
			else
				extrasInitialHeight +=
					$(
						"#extrasSection .order-configuration__item .row.center._margin_top-m > div:first-child"
					).height() +
					$(
						"#extrasSection .order-configuration__item .row > div:nth-child(2)"
					).height() +
					$(
						"#extrasSection .order-configuration__item .row > div:nth-child(3)"
					).height() +
					50;
			return extrasInitialHeight;
		}

		function notificationHeight() {
			let height = 0;
			if ($("#extrasSection .o2uk-notification-message").length) {
				if ($(document).width() > 599) height = 90;
				else height = 86;
				$("#extrasSection .o2uk-notification-message").each(function (i, v) {
					height += $(v).parent().height();
				});
			}
			return height;
		}

		function loadingImage() {
			add = 0;
			const intervalMain = setInterval(() => {
				if (
					$(".order-configuration__title")
						.text()
						.includes("Your device and plan")
				) {
					$("#o2uk-buble-loader")
						.removeClass("o2uk-buble-loader_fade-in")
						.addClass("o2uk-buble-loader_fade-out");
					$("#o2uk-buble-loader").css("background", "rgb(255, 255, 255)");
					if (
						$(".order-configuration-plan__container .amount-info-monthly")
							.length > 0
					) {
						$(
							".order-configuration-plan__container .amount-info-monthly"
						).insertAfter(
							".dr1117B-device-plan .order-configuration-cost-item"
						);
					}
					clearInterval(intervalMain);
				} else if (add > 200) {
					$("#o2uk-buble-loader")
						.removeClass("o2uk-buble-loader_fade-in")
						.addClass("o2uk-buble-loader_fade-out");
					$("#o2uk-buble-loader").css("background", "rgb(255, 255, 255)");
					clearInterval(intervalMain);
				}
				add++;
			}, 100);
		}

		function hideAdditionalSection() {
			count = 0;
			const interval = setInterval(() => {
				if ($("#o2uk-buble-loader").hasClass("o2uk-buble-loader_fade-out")) {
					$(
						"#insurancesSection > div.o2uk-container:last-child, .order-configuration__swap > div.o2uk-container:last-child, #accessSection + div.o2uk-container:contains('Subtotal for access'), #extrasSection + div:contains('Subtotal for Extras')"
					).hide();
					clearInterval(interval);
				} else if (count > 1000) {
					clearInterval(interval);
				}
				count++;
			}, 100);
		}

		function chooseExtras() {
			extras = 0;
			const intervalExtras = setInterval(() => {
				if ($("#o2uk-buble-loader").hasClass("o2uk-buble-loader_fade-out")) {
					setTimeout(() => {
						if (
							$("#extrasSection .order-configuration__boltons-footer.h4")
								.text()
								.includes("chosen all your Extras")
						)
							$(".DR1117B-extras").html("You've chosen all your Extras.");
						else
							$(".DR1117B-extras").html(
								"You have<strong> 1 Extra </strong>left to choose."
							);
					}, 500);
					clearInterval(intervalExtras);
				} else if (extras > 200) clearInterval(intervalExtras);
				extras++;
			}, 100);
		}

		if (!$("#extrasSection .dr1117B-extras-icon").length) extrasSection();
		loadingImage();
	}
})();