function appendJQueryScript(callback) {
  var script = document.createElement('script');
  script.src = 'https://code.jquery.com/jquery-3.6.0.min.js';
  script.addEventListener('load', callback);
  document.head.appendChild(script);
}

// Call the function to append jQuery script    
appendJQueryScript(function() {
  // Now that jQuery is loaded, use it in noConflict mode        
  var myJQuery = jQuery.noConflict(true);         
  // Now you can use 'myJQuery' instead of '$' for jQuery operations        
  myJQuery(document).ready(function () {             
  // Your jQuery code here, using 'myJQuery' instead of '$'            
  console.log('Script Added!!!');         
  });     
});


myJQuery(document).ready(function () {
  // Get the body element
  var bodyElement = myJQuery('body');
  
  // Check if the body element exists
  if (bodyElement.length > 0) {
    // Get the classes of the body element
    var bodyClasses = bodyElement.attr('class');
  
    // Check if classes are defined
    if (bodyClasses) {
        console.log('Body Classes:', bodyClasses);
    } else {
        console.log('Body has no classes.');
    }
  } else {
    console.error('Body element not found.');
  }
  
  // Your other jQuery code here, using 'myJQuery' instead of '$'
  // For example:
  // myJQuery('.some-element').doSomething();
  });