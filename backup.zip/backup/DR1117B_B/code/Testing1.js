console.log("VMO2AB_Version2 -  DR1117B Challenger");
(function () {
	// function loadGlassBox() {
	// 	try {
	// 		_detector.triggerABTestingEvent(
	// 			"Adobe",
	// 			"${campaign.id}",
	// 			"${campaign.name}",
	// 			"${campaign.recipe.name}",
	// 			"${campaign.recipe.name}"
	// 		);
	// 	} catch (error) {
	// 		console.log(error.message);
	// 	}
	// }
	function poll(fn, callback, errback, timeout, interval) {
		var endTime = Number(new Date()) + (timeout || 2000);
		interval = interval || 20000;
		(function p() {
			// If the condition is met, we’re done!
			if (fn()) {
				callback();
			}
			// If the condition isn’t met but the timeout hasn’t elapsed, go again
			else if (Number(new Date()) < endTime) {
				setTimeout(p, interval);
			}
			// Didn’t match and too much time, reject!
			else {
				errback(new Error("timed out for " + fn + ": " + arguments));
			}
		})();
	}
	poll(
		function () {
			return typeof jQuery == "function" && typeof $ == "function";
		},
		function () {
			// Done, success callback
			loadExperience();
		},
		function (err) {
			// Error, failure callback
			console.log("error: ", err);
		},
		20000
	);
	function loadExperience() {
		poll(
			function () {
				// if (
				// 	utag_data.page_page_name != "" &&
				// 	!utag_data.page_page_name.includes("phones")
				// ) {
				// 	$(".dr1117B-style").remove();
				// }
				return (
					document.querySelector("body .o2uk-header-curve__container") !== null &&
					!document.querySelector("body").classList.contains('DR1117B')
          // &&
					// utag_data.page_page_name.includes("phones")
				);
			},
			function () {
				// loadGlassBox();
				executeExprience();
			},
			function (err) {
				// Error, failure callback
				console.log("error: ", err);
			},
			20000
		);
	}

	function includeStyleSheet() {
		return `<style class="dr1117B-style">
      html {
scroll-behavior: smooth;
}

#extrasSection .order-configuration__item {
  transition: all .5s ease-in;
  overflow: hidden;
}
#extrasSection > p {
  position: absolute;
  bottom: 35px;
  left: 50%;
  transform: translateX(-50%);
  color: #107ac0;
  font-weight: 600;
}
#extrasSection > p {
  bottom: 22px;
  color: #006;
  font-weight: 500;
}
#extrasSection > button {
  position: absolute;
  bottom: -30px;
  left: 50%;
  transform: translateX(-50%);
  transition: .7s;
  background-color: #107ac0;
  border-radius: 50%;
  padding: 15px;
  width: 60px;
  height: 60px;
  z-index: 1;
}
#extrasSection.active .dr1117B-extras-icon:before {
  transform: rotate(-90deg);
}

.dr1117B-extras-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 85%;
  height: 30%;
  position: relative;
  color: #fff;
  transition: box-shadow 150ms;
  font-size: 34px;
}
.dr1117B-extras-icon:before {
  position: absolute;
  transform: rotate(90deg);
  transition: .7s;
}
#extrasSection .order-configuration__perks-description > p:first-child {
  margin-bottom: 0;
}

#extrasSection .extras-selected {
  display: flex;
  align-items: center;
  gap: 10px;
  border: 2px solid #0a8a03;
  border-radius: 8px;
  padding: 21px 16px;
  position: relative;
}
#extrasSection .extras-desc p:first-child {
  font-size: 20px;
  font-weight: 600;
  text-align: left;
}
#extrasSection .extras-desc {
  display: flex;
  gap: 10px;
  flex-direction: column;
  align-items: flex-start;
}
#extrasSection .extras-text-selected {
  position: absolute;
  top: 0px;
  right: 0px;
  background-color: #0a8a03;
  color: #fff;
  padding: 2px 7px;
  border-bottom-left-radius: 4px;
  border-top-right-radius: 4px;
}

/* Extras Section Starts */

#extrasSection > button {
  z-index: 2;
}
#extrasSection {
  position: relative;
  /*border-top: unset;*/
  /*box-shadow: 0 3px 3px 0 rgb(0 0 0 / 5%), 0 0 12px 0 rgb(0 0 0 / 10%);*/
  padding-bottom: 127px;
}
.order-configuration__boltons-footer ._margin_top-l {
  margin-top: 10px;
}
#extrasSection > div._margin_bottom-s:nth-child(2){
  margin-bottom: 0;
}
#extrasSection .order-configuration__boltons-footer.h4 {
  display: none;
}
/* Extras Section Ends */

#extrasSection > button.view-all {
  position: absolute;
  bottom: 70px;
  background-color: #fff;
  color: #107ac0;
  border: 1px solid #107ac0;
  border-radius: 8px;
  width: 100%;
  z-index: 1;
  transition: all .7s ease-in;
}
#extrasSection > button.view-all {
  bottom: 60px;
}
#extrasSection .row.center {
  margin-right: 2px;
  margin-left: 2px;
}
@media only screen and (min-width: 1200px) {
  #extrasSection .order-configuration__item {
    margin: 0 auto;
  }
}

/*@media only screen and (min-width: 600px) {
  #extrasSection .row.center {
    margin-right: 2px;
    margin-left: 2px;
  }
}*/
@media only screen and (max-width: 599px) {
  #extrasSection .order-configuration__item {
    margin-top: 0;
  }
  #insurancesSection .order-configuration__item .row.center > div:first-child .insurance {
    min-height:	275px;
  }
  #insurancesSection .order-configuration__item .row.center > div:first-child .insurance .insurance__content {
    min-height: 165px;
  }
  /*#extrasSection .add-on:not(.add-on_not-focusable):focus, .add-on:not(.add-on_not-focusable):hover {
    margin-left: 7px;
    margin-right: 7px;
  }
  #extrasSection .row.center {
    margin-right: 2px;
    margin-left: 2px;
  }*/
}
@media only screen and (max-width: 478px) {
  #extrasSection > p {
    bottom: 9px;
  }
  #extrasSection.active .order-configuration__boltons-footer ._margin_top-l {
    margin-top: -9px;
  }
}
@media only screen and (max-width: 450px) {
  #extrasSection .extras-selected {
    padding: 35px 10px;
  }		
}
</style>`;
	}

	function executeExprience() {
		document.querySelector("body").classList.add('DR1117B');
		document.querySelector("#o2uk-buble-loader").classList.remove('o2uk-buble-loader_fade-out');
		document.querySelector("#o2uk-buble-loader").classList.add('o2uk-buble-loader_fade-in');
		document.querySelector("#o2uk-buble-loader").style.backgroundColor = 'rgb(255, 255, 255, 0.8)';

		if (document.querySelector("body .dr1117B-style") == null){
			const styleSheet = document.createRange().createContextualFragment(includeStyleSheet());
			document.querySelector("body").append(styleSheet);
		}

		function extrasSection() {
			const button = document.createElement('button');
			button.className = "mat-button-base o2uk-primary-button view-all dr1117b-button";
			button.role = "button";
			button.manual_cm_re = "VMO2AB-_-DR1117B-_-View-_-all-_-Extras";

			const existingNode = document.querySelector("#extrasSection .order-configuration__item");
      console.log(existingNode)
			existingNode.parentNode.insertBefore(button, existingNode.nextSibling);
			const spanText = document.createElement('span');
			spanText.textContent = "View all Extras";
			document.querySelector("#extrasSection .dr1117b-button").appendChild(spanText);
			const extras = document.createElement("p");
			extras.className = "DR1117B-extras";
			extras.innerHTML = "You have<strong> 1 Extra </strong>left to choose.";
			document.querySelector("#extrasSection .order-configuration__item").parentNode.insertBefore(extras, document.querySelector("#extrasSection .order-configuration__item").nextSibling);
		}
    if (document.querySelector("#extrasSection .dr1117B-extras-icon") == null) {
      let extrasCount = 0;
      const extrasInterval = setInterval(()=>{
        if(document.querySelector("#extrasSection .order-configuration__item") !== null){
          extrasSection();
          clearInterval(extrasInterval);
        }
        else if(extrasCount > 300){
          clearInterval(extrasInterval);
        }
        extrasCount++;
      }, 300);
    } 
	}
})();