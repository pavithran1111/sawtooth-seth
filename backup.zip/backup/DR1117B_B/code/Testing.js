console.log("DR1117B Challenger");
(function () {
  function poll(fn, callback, errback, timeout, interval) {
    var endTime = Number(new Date()) + (timeout || 2000);
    interval = interval || 2000;
    (function p() {
        // If the condition is met, we're done! 
        if (fn()) {
            callback();
        }
        // If the condition isn't met but the timeout hasn't elapsed, go again
        else if (Number(new Date()) < endTime) {
            setTimeout(p, interval);
        }
        // Didn't match and too much time, reject!
        else {
            errback(new Error('timed out for ' + fn + ': ' + arguments));
        }
    })();
  }
  poll(
    function () {
        return typeof jQuery == "function" && typeof $ == "function";
    },
    function () {
      // Done, success callback
      var script = document.createElement('script');
      script.src = 'https://code.jquery.com/jquery-3.6.0.min.js';
      script.addEventListener('load', function() {
        var myJQuery = jQuery.noConflict(true);
        loadExperience(myJQuery);
        //Example of usage custom myJQuery variable
        // myJQuery('o2uk-global-footnote').parents('.o2uk-container');
      });
      document.head.appendChild(script);
    },
    function (err) {
        // Error, failure callback
        console.log("error: ", err);
    },
    20000
  );

  function loadExperience(myJQuery) {
    poll(
      function () {
        // console.log(!!$("body").find(".o2uk-header-curve__container").length > 0 + ' ggggggg')
        // return !!$("body").find(".o2uk-header-curve__container").length > 0 &&
        // !$("body").hasClass("DR1117B") ;
        return true;
      },
      function () {
        executeExprience(myJQuery);
      },
      function (err) {
        // Error, failure callback
        console.log("error: ", err);
      },
      20000
    );
  }

  function executeExprience(myJQuery) {
    console.log('asdf');
    alert('qwerty');
    myJQuery("body").addClass("DR1117B");
  }
})();