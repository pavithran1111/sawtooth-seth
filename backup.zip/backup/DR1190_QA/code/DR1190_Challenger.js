console.log("VMO2AB_DR1190V2 Version2");
(function () {
  function poll(conditionFn, successCallback, errorCallback, timeout = 12000, interval = 500) {
    const endTime = Number(new Date()) + timeout;

    (function checkCondition() {
      if (conditionFn()) {
        successCallback();
      } else if (Number(new Date()) < endTime) {
        setTimeout(checkCondition, interval);
      } else {
        errorCallback(new Error('Timed out'));
      }
    })();
  }

  poll(
    function () {
      return typeof jQuery === "function" && typeof $ === "function" && $('.device-customization__plan-picker-content').length && $('o2uk-device-tariff-cards .tariff-card').length && !$('body').hasClass('DR1190V2').length
    },
    function () {
      executeExperience();
    },
    function (err) {
      console.error("Error: ", err);
    },
    40000
  );


  function executeExperience() {
    function execute1190V2() {
      $('body').addClass('DR1190V2');
      // DropDown
      let dropDown1190V2 = `<div class="dropdown1190V2">
            <div class="dropdown1190V2-button close1190V2" manual_cm_re="DR1190V2-_-Challenger-_-Sort by">
              <span class="selected-option">Featured</span>
              <span class="o2uk-icon-font icon-chevron-down"></span>
            </div>
            <label class="dropdown1190V2-label">Sort by</label>
            <div class="dropdown1190V2-Container">
              <div class="dropdown1190V2-divider">
                <hr role="presentation" aria-hidden="true" class="o2uk-pseudo-dropdown__panel-separator ng-tns-c155-4">
              </div>
              <div class="dropdown1190V2-list">
                <div class="dropdown1190V2-list-item active" data-operation="topPicks" data-aria = "TopPicks" >
                  <div class="radio1190V2-container">
                    <div class="radio1190V2Outer">
                      <div class="radio1190V2ripple"></div>
                      <div class="radio1190V2Inner"></div>
                    </div>
                    <label for="option1">Top picks</label>
                  </div>
                </div>
                <div class="radioSubtitle">Monthly Cost</div>
                <div class="dropdown1190V2-list-item" data-operation="lowTohigh"  data-aria="MonthCost">
                  <div class="radio1190V2-container">
                    <div class="radio1190V2Outer">
                      <div class="radio1190V2ripple"></div>
                      <div class="radio1190V2Inner"></div>
                    </div>
                    <label for="option1">Low to high</label>
                  </div>
                </div>
                <div class="dropdown1190V2-list-item" data-operation="highTolow" data-aria = "MonthCost">
                  <div class="radio1190V2-container">
                    <div class="radio1190V2Outer">
                      <div class="radio1190V2ripple"></div>
                      <div class="radio1190V2Inner"></div>
                    </div>
                    <label for="option2">High to low</label>
                  </div>
                </div>
                <div class="radioSubtitle">Monthly Data</div>
                <div class="dropdown1190V2-list-item" data-operation="lowTohigh" data-aria = "MonthData">
                  <div class="radio1190V2-container">
                    <div class="radio1190V2Outer">
                      <div class="radio1190V2ripple"></div>
                      <div class="radio1190V2Inner"></div>
                    </div>
                    <label for="option3">Low to high</label>
                  </div>
                </div>
                <div class="dropdown1190V2-list-item" data-operation="highTolow" data-aria = "MonthData">
                  <div class="radio1190V2-container">
                    <div class="radio1190V2Outer">
                      <div class="radio1190V2ripple"></div>
                      <div class="radio1190V2Inner"></div>
                    </div>
                    <label for="option4">High to low</label>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="tracking1190V2"></div>`;

      if ($('body').find('.dropdown1190V2').length < 1) {
        $('body').find('.device-customization__plan-picker-content .o2uk-sort-and-filter__dropdown-wrapper .o2uk-sort-and-filter__dropdown-wrapper-inner').after(dropDown1190V2);
      }
      $('body').find('.o2uk-sort-and-filter__dropdown-wrapper').addClass('col-md-8').removeClass('col-md-4');
      $('body').find('.o2uk-sort-and-filter__dropdown-wrapper').addClass('col-lg-8').removeClass('col-lg-3');


      function openDropDown() {
        $('body').find(".dropdown1190V2-Container").show();
        $('body').find(".dropdown1190V2").removeClass("close1190V2");
        $('body').find(".dropdown1190V2").addClass("open1190V2");
        $('body').find(".dropdown1190V2-button").addClass("list-active");
        $('body').find(".dropdown1190V2 .o2uk-icon-font").removeClass("icon-chevron-down");
        $('body').find(".dropdown1190V2 .o2uk-icon-font").addClass("icon-chevron-up");
      }

      function closeDropDown() {
        $('body').find(".dropdown1190V2-Container").hide();
        $('body').find(".dropdown1190V2").removeClass("open1190V2");
        $('body').find(".dropdown1190V2").addClass("close1190V2");
        $('body').find(".dropdown1190V2-button").removeClass("list-active");
        $('body').find(".dropdown1190V2 .o2uk-icon-font").addClass("icon-chevron-down");
        $('body').find(".dropdown1190V2 .o2uk-icon-font").removeClass("icon-chevron-up");
      }

      sessionStorage.setItem("isThisNewClick1190V2", "true");

      // Open and close drop down
      $(document).off('mousedown').on('mousedown', '.dropdown1190V2-button', function () {
        $('body').find('.dropdown1190V2').hasClass('open1190V2') ? closeDropDown() : openDropDown();
        processTariffCards();
      });

      $(document).on('mouseleave', '.dropdown1190V2-list', function () {
        closeDropDown();
      });

      // Hover effects of list options
      $(document).on('mouseenter', '.dropdown1190V2-list-item:not(.active)', function () {
        $(this).find('.radio1190V2Outer .radio1190V2ripple').css({
          "box-shadow": "0 0 0px 4px #c9ecfd",
          "transform": "translate(-50%, -50%)  scale(1)",
          "opacity": "1"
        });
      });

      $(document).on('mouseleave', '.dropdown1190V2-list-item:not(.active)', function () {
        $(this).find('.radio1190V2Outer .radio1190V2ripple').css({
          "box-shadow": "0 0 0px 4px #c9ecfd",
          "transform": "translate(-50%, -50%)  scale(0.5)",
          "opacity": "0"
        });
      });


      $(document).on('mousedown', '.dropdown1190V2-list-item', function () {
        closeDropDown();
        $('body').find('.dropdown1190V2-list-item').removeClass('active');
        $(this).addClass('active');
        $(this).find('.radio1190V2Outer .radio1190V2ripple').css({
          "box-shadow": "0 0 0px 4px #c9ecfd",
          "transform": "translate(-50%, -50%)  scale(0.5)",
          "opacity": "0"
        });

        const selectedOption = $(this).text();
        $('.selected-option').text(selectedOption);

        sortTilesFunc($(this).attr('data-operation'), $(this).attr('data-aria'));

        $('o2uk-device-tariff-cards button[aria-label="See more pre-built plans"]').first().click();

        // adding tracking to the click of the selected option
        if ($(this).attr('data-aria') == "TopPicks") {
          clicked_info = $(this).attr('data-aria');
        } else {
          clicked_info = $(this).attr('data-aria') + '_' + $(this).attr('data-operation');
        }

        sessionStorage.setItem("isThisNewClick1190V2", "false");
        sessionStorage.setItem("isFilterSelected", "true");

        window['optimizely'] = window['optimizely'] || [];
        window['optimizely'].push({
          type: "event",
          eventName: `DR1190V2_${clicked_info}`
        });
      });


      // Adding Attributes to the tiles list
      function processTariffCards() {
        let count = 0;
        let maxChecks = 200;

        let checkInterval = setInterval(function () {
          let tariffCards = $('body').find(".device-customization o2uk-device-tariff-cards .tariff-card");

          if (tariffCards.length > 0) {
            tariffCards.each(function (index, item) {
              let dataAttrVal = $(this).find('.tariff-card__wrapper o2uk-data h2').text().trim();
              let costAttr = $(this).find('o2uk-price-new .o2uk-price__amount-integer').text().trim();
              let dataAttr = dataAttrVal.includes('Unlimited Plus') ? "999"
                : dataAttrVal.includes('Unlimited')
                  ? "998"
                  : $(this).find('.tariff-card__wrapper o2uk-data h2:contains(GB)').text().replace(/\D/g, '');

              $(this).parent('div').addClass('tilesTobeSorted');
              if (sessionStorage.getItem("isThisNewClick1190V2") == "true") {
                $(this).parent('div').attr('data-indexcount', index);
              }
              $(this).parent('div').attr('data-monthcost', costAttr);
              $(this).parent('div').attr('data-monthdata', dataAttr);
            });
            clearInterval(checkInterval);
          } else {
            count++;
            if (count >= maxChecks) {
              clearInterval(checkInterval);
            }
          }
        }, 100);
      }

      function sortTilesFunc(dataVal, operation) {
        let bigArray = [];
        let intervalIdCount = 0;
        let intervalId = setInterval(function () {
          let allHaveDataIndexCount = false;
          $('body').find(".tilesTobeSorted").each(function (index) {
            if ($(this).attr('data-indexcount')) {
              allHaveDataIndexCount = true;
            }
          });

          if (allHaveDataIndexCount) {
            clearInterval(intervalId);

            let $wrapper = $(document).find('o2uk-device-tariff-cards .o2uk-container .row');
            let $wrapper1 = $(document).find('o2uk-device-tariff-cards .o2uk-container .row').first();
            let $wrapper2 = $(document).find('o2uk-device-tariff-cards .o2uk-container .row').last();

            let $elements = $wrapper.find('.tilesTobeSorted');

            let operationAttribute = '';

            if (operation.toLowerCase() == 'monthcost') {
              operationAttribute = 'data-monthcost';
            } else if (operation.toLowerCase() == 'monthdata') {
              operationAttribute = 'data-monthdata';
            }
            else if (operation.toLowerCase() == 'toppicks' && $('.o2uk-sort-and-filter__condition .o2uk-chips').length < 1) {
              operationAttribute = 'data-indexcount';
            }

            bigArray = $elements.toArray().sort(function (a, b) {
              let aData = +$(a).attr(operationAttribute);
              let bData = +$(b).attr(operationAttribute);

              if (dataVal === "lowTohigh") {
                return aData - bData;
              } else if (dataVal === "highTolow") {
                return bData - aData;
              } else if (dataVal === "topPicks") {
                return +a.dataset.indexcount - +b.dataset.indexcount;
              } else {
                return 0;
              }

            });

            let firstArray = bigArray.slice(0, 3);
            let secondArray = bigArray.slice(3);

            firstArray.forEach(function (item) {
              $(item).appendTo($wrapper1);
            });

            secondArray.forEach(function (item) {
              $(item).appendTo($wrapper2);
            });
          } else if (++intervalIdCount > 100) {
            clearInterval(intervalId);
          }
        }, 100);
      }



      // Conrolling the filters
      let filterDropDownCount = 0;
      let filterDropDown = $('body').find('div[aria-label="Data Filter"] .o2uk-checkbox');
      let filterCover = '<div class="coverFilter"></div>';
      let findFilters = setInterval(function () {
        if (filterDropDown.length > 0 && $('body').find('.coverFilter').length < 1) {
          filterDropDown.each(function (index) {
            $(this).after(filterCover);
            let newClass = $(this).attr('id')
            $(this).next('.coverFilter').first().attr('data-filterTarget', newClass);
            clearInterval(findFilters);
          });
        }
        else if (++filterDropDownCount < 200) {
          clearInterval(findFilters);
        }
      }, 500);

      $(document).on('mousedown', '.coverFilter', function () {
        if (sessionStorage.getItem('isFilterSelected') == 'true') {
          $('body').find('.dropdown1190V2-list-item[data-operation="topPicks"]').mousedown();
        }
        $('body').find('.dropdown1190V2').addClass('inactive');
        sessionStorage.setItem("isThisNewClick1190V2", "true");

        let currentIdtobeClicked = $(this).attr('data-filterTarget');

        setTimeout(() => {
          $('body').find(`#${currentIdtobeClicked} .o2uk-checkbox-input`).trigger('click');
        }, 500);

        setTimeout(() => {
          $('body').find('.dropdown1190V2').removeClass('inactive');
        }, 2000);

        letsAddCoverForChip();
      });

      function letsAddCoverForChip() {
        letFindChipsCount1190V2 = 0;
        let chipCover = '<div class="coverChip"></div>';
        setTimeout(() => {
          letFindChips1190V2 = setInterval(() => {
            if ($('body').find('.o2uk-sort-and-filter__condition .o2uk-chips').length > 0) {
              $('body').find('.o2uk-sort-and-filter__condition .o2uk-chips').each(function () {
                if (!$(this).find('.coverChip').length) {
                  $(this).append(chipCover);
                }
              })
              clearInterval(letFindChips1190V2);
            }
            else if (++letFindChipsCount1190V2 > 100) {
              clearInterval(letFindChips1190V2);
            }
          }, 100)
        }, 500);
      }

      $(document).on('mousedown', '.coverChip', function (event) {
        if (sessionStorage.getItem('isFilterSelected') == 'true') {
          $('body').find('.dropdown1190V2-list-item[data-operation="topPicks"]').mousedown();
        }
        $('body').find('.dropdown1190V2').addClass('inactive');
        setTimeout(() => {
          $('body').find('.dropdown1190V2').removeClass('inactive');
        }, 2000);
        $(this).siblings('.o2uk-link__container').find('.o2uk-chips__item').trigger('click');
        sessionStorage.setItem("isThisNewClick1190V2", "true");
      });


      function letsAddCoverForSelectClear() {
        letFindChipsCount1190V2 = 0;
        let selectClearCover = '<div class="selectClearCover"></div>';
        setTimeout(() => {
          letFindChips1190V2 = setInterval(() => {
            if ($('body').find('.o2uk-sort-and-filter__filter-element .o2uk-filter__control .o2uk-filter__control-button').length > 0) {
              $('body').find('.o2uk-sort-and-filter__filter-element .o2uk-filter__control .o2uk-filter__control-button').each(function () {
                if (!$(this).find('.selectClearCover').length) {
                  $(this).append(selectClearCover);
                }
              })
              clearInterval(letFindChips1190V2);
            }
            else if (++letFindChipsCount1190V2 > 100) {
              clearInterval(letFindChips1190V2);
            }
          }, 100)
        }, 500);
      }


      $(document).on('mousedown', '.o2uk-sort-and-filter__filter-element', function () {
        letsAddCoverForSelectClear();
      });

      $(document).on('mousedown', '.selectClearCover', function () {
        if (sessionStorage.getItem('isFilterSelected') == 'true') {
          $('body').find('.dropdown1190V2-list-item[data-operation="topPicks"]').mousedown();
        }
        $('body').find('.dropdown1190V2').addClass('inactive');
        setTimeout(() => {
          $('body').find('.dropdown1190V2').removeClass('inactive');
        }, 2000);
        $(this).siblings('.o2uk-link').trigger('click');
        sessionStorage.setItem("isThisNewClick1190V2", "true");
      });


    }

    // Rerun script on device change    

    // Check if utils and utag_obj are available in the window object
    if (window.optimizely && window.optimizely.get && window.utag_obj) {
      let utils = window.optimizely.get("utils");

      // Check if observeSelector method is available in the utils object
      if (utils && utils.observeSelector) {
        utils.observeSelector(
          ".device-details-header__brand-name",
          function () {
            if (
              window.utag_obj.page_page_name.includes("shop:cfa|phones|devices|") ||
              window.utag_obj.page_page_name.includes("shop:cfu|phones|devices|")
            ) {
              execute1190V2();
            }
          },
          {
            once: false,
          }
        );
      } else {
        console.error("observeSelector method is not available in utils object.");
      }
    } else {
      console.error("utils or utag_obj is not available in the window object.");
    }
  } 
})();