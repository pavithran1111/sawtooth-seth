console.log("VMO2AB_DR1204Version2 - DR1204 Controller");
(function () {
  function loadGlassbox() {
    try {
      _detector.triggerABTestingEvent(
        'Optimizely',
        '28350400988',
        'DR1204',
        '28369970777',
        'Exp A'
      );
    } catch (error) {
      console.log(error.message);
    }
  }
  loadGlassbox();
 
  function GA4Integration(){
    if(typeof gtag !== "undefined"){
      gtag('event', 'optimizely_campaign', {
        'optimizely_experiment': "28350400988" ,
        'optimizely_experiment_name': "DR1204 Listings page from price​​",
        'optimizely_variant_name': "DR1195 Exp A"
      });
    }
  }
  GA4Integration();

  function poll(fn, callback, errback, timeout, interval) {
    var endTime = Number(new Date()) + (timeout || 6000);
    //interval = interval || 100;
    interval = 4000;
    (function p() {
      // If the condition is met, we're done! 
      if (fn()) {
        callback();
      }
      // If the condition isn't met but the timeout hasn't elapsed, go again
      else if (Number(new Date()) < endTime) {
        setTimeout(p, interval);
      }
      // Didn't match and too much time, reject!
      else {
        errback(new Error('timed out for ' + fn + ': ' + arguments));
      }
    })();
  }

  poll(
    function () {
      return typeof jQuery == "function" && typeof $ == "function";
    },
    function () {
      // Done, success callback
      loadExperience();
    },
    function (err) {
      // Error, failure callback
      console.log("error: ", err);
    },
    40000
  );

  function loadExperience() {
    poll(
      function () {
        return $('.o2uk-header-curve__wrapper-curve').length > 0;
      },
      function () {
        executeExperience();
      },
      function (err) {
        // Error, failure callback
        console.log("error: ", err);
    });
  }

  function executeExperience() {
    function executeDR1204(){
      if(!$('.DR1204tracking').length) triggerTracking();
      
      triggerLearnMore();
      addTracking();
    }


    function triggerTracking() {
      $(document).on('click', '.o2uk-sort__panel .radio-button, .os-viewport-native-scrollbars-invisible div[role="listbox"] .o2uk-checkbox', function(){
        let triggerText = '';
        if($(this).find('.mat-radio-label-content').length){
          triggerText = $(this).find('.mat-radio-label-content').parents('.o2uk-sort__fieldset').find('.o2uk-sort__option-title').text().trim()+'-_-'+$(this).find('.mat-radio-label-content').text().trim();
        }
        else {
          triggerText = $(this).closest('.ng-star-inserted').parents('.o2uk-filter__content').parents('.o2uk-expansion-panel-body').parents('.o2uk-expansion-panel-content').parents('.o2uk-expansion-panel').find('.mat-focus-indicator .o2uk-filter__expansion-title').text()+'-_-'+$(this).find('.o2uk-checkbox-label p').text().trim().split(' ')[0];
        }
        gtag('event', 'optimizely_campaign', {
          'optimizely_event_name': 'click',
          'optimizely_event_value': `DR1204-_-ExpA-_-${triggerText}`
        });
      });
    }

    function triggerLearnMore() {
      setTimeout(()=>{
        [...document.querySelectorAll('.device-card__promo-content > .o2uk-link__container > button')].forEach(function(item) {
          item.addEventListener('click', function(v) {
            const title = $(item).closest('.device-card__content').find('.device-card__name').text().replaceAll(' ','-_-');  
            gtag('event', 'optimizely_campaign', {
              'optimizely_event_name': 'click',
              'optimizely_event_value': `DR1204-_-ExpA-_-${title}-_-Learn-_-More`
            });
          });
        });
      }, 2500);
    }

    function addTracking() {
      if(!$('.DR1204tracking').length)
        $('body').append('<div class="DR1204tracking"></div>');
    }

    // Rerun script on device change    
    let utils = window.optimizely.get("utils");
    utils.observeSelector('.o2uk-header-curve__section', function () {
      if (utag_obj.page_page_name.includes('shop:cfa|phones|paymonthly:devices|listing')) {
        executeDR1204();
      }
    }, {
      "once": false
    });
  }
})();