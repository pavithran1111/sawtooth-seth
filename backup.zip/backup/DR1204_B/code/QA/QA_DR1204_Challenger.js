console.log("VMO2AB_DR1204Version2 - DR1204 Challenger");
(function () {
  function loadGlassbox() {
    try {
      _detector.triggerABTestingEvent(
        'Optimizely',
        '28350400988',
        'DR1204',
        '28407060875',
        'Exp B'
      );
    } catch (error) {
      console.log(error.message);
    }
  }
  loadGlassbox();
 
  function GA4Integration(){
    if(typeof gtag !== "undefined"){
      gtag('event', 'optimizely_campaign', {
        'optimizely_experiment': "28350400988" ,
        'optimizely_experiment_name': "DR1195 Listings page from price​​",
        'optimizely_variant_name': "DR1204 Exp B"
      });
    }
  }
  GA4Integration();

  function poll(fn, callback, errback, timeout, interval) {
    var endTime = Number(new Date()) + (timeout || 6000);
    //interval = interval || 100;
    interval = 4000;
    (function p() {
      // If the condition is met, we're done! 
      if (fn()) {
        callback();
      }
      // If the condition isn't met but the timeout hasn't elapsed, go again
      else if (Number(new Date()) < endTime) {
        setTimeout(p, interval);
      }
      // Didn't match and too much time, reject!
      else {
        errback(new Error('timed out for ' + fn + ': ' + arguments));
      }
    })();
  }

  poll(
    function () {
      return typeof jQuery == "function" && typeof $ == "function";
    },
    function () {
      // Done, success callback
      loadExperience();
    },
    function (err) {
      // Error, failure callback
      console.log("error: ", err);
    },
    40000
  );

  function loadExperience() {
    poll(
      function () {
        return $('.o2uk-header-curve__wrapper-curve').length > 0;
      },
      function () {
        executeExperience();
      },
      function (err) {
        // Error, failure callback
        console.log("error: ", err);
    });
  }

  function executeExperience() {
    function executeDR1204(){
      if(!$('.DR1204tracking').length) {
        triggerPhoneAirtime();
        triggerTracking();
      }
      triggerLearnMore();
      if(!window.location.href.includes('cnd=like-new') && !window.location.href.includes('sim-free')){
        addDesign();
      }
      addTracking();
    }

    function addDesign(timeout = 1000){
      let count = 0;
      const interval = setInterval(()=>{
        
        if($('#o2uk-buble-loader').hasClass('o2uk-buble-loader_fade-out') && !$('.tab-labels > :last-child').hasClass('tab-label-active') && !$('.device-plan-tab .o2uk-tabs div[role="tablist"] button:contains("Phone only")').hasClass('active')){
          clearInterval(interval);
          setTimeout(()=>{
            $('.portlet-boundary .portlet-body .row > div.device-card__item > :not(div)').each(function(i, v){
              $(v).find('.device-card__top-pick').text('Data From');
              $(v).find('.device-card__footer .h4').text('1GB');
              $(v).find('.device-card__promo-content .countdown-timer').hide();
              $(v).addClass('DR1204-device');
              //$(v).find('.device-card__image-wrapper').attr('src', $(v).find('.device-card__image-wrapper').attr('data-src'));
              updateNewData($(v).find('.device-card__name').text(), v);
            });
            if(window.location.href.includes('cnd=like-new') && !window.location.href.includes('sim-free'))
              $('.os-viewport-native-scrollbars-invisible .o2uk-sort__panel > .o2uk-radio-group:nth-child(2)').show();
            else
              $('.os-viewport-native-scrollbars-invisible .o2uk-sort__panel > .o2uk-radio-group:nth-child(2)').hide();
          }, timeout);
        }
        else if(++count > 300){
          clearInterval(interval);
        }
      }, 300);
    }

    function addDesignNewDevices(){
      let count = 0;
      const interval = setInterval(()=>{
        if($('#o2uk-buble-loader').hasClass('o2uk-buble-loader_fade-out')){
          clearInterval(interval);
          setTimeout(()=>{
            $('.portlet-boundary .portlet-body .row > div.device-card__item > :not(div):not(".DR1204-device")').each(function(i, v){
              $(v).find('.device-card__top-pick').text('Data From');
              $(v).find('.device-card__footer .h4').text('1GB');
              $(v).addClass('DR1204-device');
              updateNewData($(v).find('.device-card__name').text(), v);
            });
            if(window.location.href.includes('cnd=like-new') && !window.location.href.includes('sim-free'))
              $('.os-viewport-native-scrollbars-invisible .o2uk-sort__panel > .o2uk-radio-group:nth-child(2)').show();
            else 
            $('.os-viewport-native-scrollbars-invisible .o2uk-sort__panel > .o2uk-radio-group:nth-child(2)').hide();
          }, 500);
        }
        else if(++count > 300){
          clearInterval(interval);
        }
      }, 300);
    }

    function triggerPhoneAirtime(){
      $(document).on('click', '.tab-labels > :first-child, .o2uk-tabs > .o2uk-tabs__wrapper > button:contains("Phone and airtime"), .device-plan-paging__show-next, .device-plan-paging__button > button', function(){
        
          setTimeout(()=>{
            if(!$('.tab-labels > :last-child').hasClass('tab-label-active')){
              triggerLearnMoreNew();
              addDesign(100);
            }
          }, 1500);

          setTimeout(()=>{
            //Update newly created tiles
            if($(this).is('.device-plan-paging__button > button') && !$('.tab-labels > :last-child').hasClass('tab-label-active')){
              const deviceInterval = setInterval(()=>{
                if($('#o2uk-buble-loader').hasClass('o2uk-buble-loader_fade-out') && $('.o2uk-buble-loader').length == 0){
                  clearInterval(deviceInterval);
                  triggerLearnMoreNew();
                  addDesignNewDevices();
                }
              }, 300);
            }
          }, 1000);
      });

      //$(document).on('click', '.o2uk-sort-and-filter .o2uk-container > .row:last-child .o2uk-chips', function(){
      $(document).on('click', '.o2uk-sort-and-filter__condition .o2uk-chips', function(){
        triggerLearnMore();
        addDesign(100);
      })


      $(document).on('click', '.tab-labels > :first-child, .tab-labels > :last-child', function(){
        setTimeout(()=>{
        if($(this).is('.tab-labels > :first-child')){
          $('.os-viewport-native-scrollbars-invisible .o2uk-sort__panel > .o2uk-radio-group:nth-child(2)').hide();
        }
        else {
            $('.os-viewport-native-scrollbars-invisible .o2uk-sort__panel > .o2uk-radio-group:nth-child(2)').show();
        }
      }, 4500);
      });
    }

    function triggerTracking() {
      $(document).on('click', '.o2uk-sort__panel .radio-button, .os-viewport-native-scrollbars-invisible div[role="listbox"] .o2uk-checkbox', function(){
        let triggerText = '';
        if($(this).find('.mat-radio-label-content').length){
          triggerText = $(this).find('.mat-radio-label-content').parents('.o2uk-sort__fieldset').find('.o2uk-sort__option-title').text().trim()+'-_-'+$(this).find('.mat-radio-label-content').text().trim();
        }
        else {
          triggerText = $(this).closest('.ng-star-inserted').parents('.o2uk-filter__content').parents('.o2uk-expansion-panel-body').parents('.o2uk-expansion-panel-content').parents('.o2uk-expansion-panel').find('.mat-focus-indicator .o2uk-filter__expansion-title').text()+'-_-'+$(this).find('.o2uk-checkbox-label p').text().trim().split(' ')[0];
        }
        gtag('event', 'optimizely_campaign', {
          'optimizely_event_name': 'click',
          'optimizely_event_value': `DR1204-_-ExpB-_-${triggerText}`
        });
        triggerLearnMore();
        addDesign(100);
      });
    }

    function triggerLearnMore() {
      setTimeout(()=>{
        if(!$('.tab-labels > :last-child').hasClass('tab-label-active') && !$('.device-plan-tab .o2uk-tabs div[role="tablist"] button:contains("Phone only")').hasClass('active')){
        [...document.querySelectorAll('.device-card__promo-content > .o2uk-link__container > button:not(button-trigger)')].forEach(function(item) {
            $(item).addClass('button-trigger');
            item.addEventListener('click', function(v) {
              const title = $(item).closest('.device-card__content').find('.device-card__name').text().replaceAll(' ','-_-');
              // console.log('Learn More');
              gtag('event', 'optimizely_campaign', {
                'optimizely_event_name': 'click',
                'optimizely_event_value': `DR1204-_-ExpB-_-${title}-_-Learn-_-More`
              });
              setTimeout(()=>{
                $('.o2uk-dialog-title .o2uk-dialog-title__content .h3').text($(item).parents('.o2uk-link__container').parents('.device-card__promo-content').find('.device-card__promo-text').text());
                $('.o2uk-dialog-content.mat-dialog-content .os-content p').html($(item).parents('.o2uk-link__container').parents('.device-card__promo-content').find('.DR1204-overlayContent').html());
              }, 500);
            });
        });
      }
      }, 2500);
    }

    function triggerLearnMoreNew() {
      setTimeout(()=>{
        if(!$('.tab-labels > :last-child').hasClass('tab-label-active') && !$('.device-plan-tab .o2uk-tabs div[role="tablist"] button:contains("Phone only")').hasClass('active')){
          [...document.querySelectorAll('.portlet-boundary .portlet-body .row > div.device-card__item > :not(div):not(.DR1204-device) .device-card__promo-content > .o2uk-link__container > button')].forEach(function(item) {
            item.addEventListener('click', function(v) {
              // console.log('Learn More New');
              const title = $(item).closest('.device-card__content').find('.device-card__name').text().replaceAll(' ','-_-');   
              gtag('event', 'optimizely_campaign', {
                'optimizely_event_name': 'click',
                'optimizely_event_value': `DR1204-_-ExpB-_-${title}-_-Learn-_-More`
              });
              setTimeout(()=>{
                $('.o2uk-dialog-title .o2uk-dialog-title__content .h3').text($(item).parents('.o2uk-link__container').parents('.device-card__promo-content').find('.device-card__promo-text').text());
                $('.o2uk-dialog-content.mat-dialog-content .os-content p').html($(item).parents('.o2uk-link__container').parents('.device-card__promo-content').find('.DR1204-overlayContent').html());
              }, 500);
            });
          });
      }
      }, 2500);
    }

    function addTracking() {
      if(!$('.DR1204tracking').length)
        $('body').append('<div class="DR1204tracking"></div>');

      setTimeout(()=>{
        $('.portlet-boundary .portlet-body .row > div.device-card__item .device-card__name:contains(Galaxy S24 Ultra)').closest('.device-card__link').click(function(){
          setTimeout(()=>{
            window.location.href = 'https://www.o2.co.uk/shop/samsung/galaxy-s24-ultra-5g?code=1SAE32GN&device-type=packages';
          }, 500)
          // let count = 0;
          // const interval = setInterval(()=>{
          //   if($('#o2uk-buble-loader').hasClass('o2uk-buble-loader_fade-out')){
          //     clearInterval(interval);
          //     window.location.href = 'https://www.o2.co.uk/shop/samsung/galaxy-s24-ultra-5g?code=1SAE32GN&device-type=packages';
          //   }
          //   else if(++count > 300){
          //     clearInterval(interval);
          //   }
          // }, 300);
        });
      }, 1000);
    }

    function updateNewData(name, v) {
      const deviceData = getNewData();
      if(deviceData[name]){

        if(deviceData[name][0] !== ''){
          //Update upfront cost
          $(v).find('.device-card__prices > .o2uk-price:first-child .o2uk-price__amount-integer').text(deviceData[name][0].split('.')[0]);
          $(v).find('.device-card__prices > .o2uk-price:first-child .o2uk-price__amount-decimal').text('.'+deviceData[name][0].split('.')[1]);
        }
        if(name == 'Galaxy S24 Ultra 5G'){

          $(v).find('.device-card__link').attr('href', 'https://www.o2.co.uk/shop/samsung/galaxy-s24-ultra-5g?code=1SAE32GN&device-type=packages');
        }
        //Update monthly cost
        $(v).find('.device-card__prices > .o2uk-price:last-child .o2uk-price__amount-integer').text(deviceData[name][1].split('.')[0]);
        $(v).find('.device-card__prices > .o2uk-price:last-child .o2uk-price__amount-decimal').text('.'+deviceData[name][1].split('.')[1]);
        const footnote = $('.portlet-boundary .portlet-body .row > div.device-card__item .amount-info-monthly > div').html();
        const footnotenew = '£'+deviceData[name][2] +' Device + £'+deviceData[name][3]+'<s'+footnote.split('<s')[1];
        $(v).find('.amount-info-monthly > div').html(footnotenew);
        $(v).find('.badge__name-wrapper').text(deviceData[name][4]);
        if(deviceData[name][5] !== ''){
          $(v).find('.device-card__promo-text').text(deviceData[name][5]);
          if($(v).find('.device-card__promo-content .DR1204-overlayContent').length == 0)
          $(v).find('.device-card__promo-content').append(`<div class="DR1204-overlayContent">${deviceData[name][6]}</div>`);
        }
        else {
          //Hide the Promo (Learn More) content is not available
          $(v).find('.device-card__promo-content').parents('.o2uk-promo-block').hide();
        }
      }
    }

    function getNewData(){
      return {
        'iPhone 15': ['30.00',	'33.56',	'18.56',	'15.00',	'5G',	'Get from £33.56* a month, our lowest ever monthly cost. Ends 3 July.',	'<p><strong>*Monthly price of your Airtime Plan will increase each April from April 2025 by the Retail Price Index rate of inflation announced in February each year plus 3.9%. If RPI is negative, we\'ll only apply the 3.9%. See<a href="http://o2.co.uk/prices" target="_blank">o2.co.uk/prices</a>.</strong></p><p>&nbsp;</p><p>Data allowances must be used within the month and&nbsp;cannot be carried over. Our lowest ever price, ends 3 July&nbsp;2024.</p><p>&nbsp;</p><p><b>Apple iPhone 15&nbsp;128GB</b>:</p><p>1GB: £33.56* a month, £30 upfront.</p><p>5GB:&nbsp;£35.56* a month, £30 upfront.</p><p>25GB:&nbsp;£38.56* a month, £30 upfront.</p><p>30GB:&nbsp;£42.55* a month, £30 upfront.</p><p>125GB:&nbsp;£42.56* a month, £30 upfront.</p><p>150GB:&nbsp;£46.55* a month, £30 upfront.</p><p>Unlimited:&nbsp;£47.56* a month, £30 upfront.</p><p>Unlimited Plus: £51.55* a month, £30 upfront.</p><p>&nbsp;</p><p><b>Apple iPhone 15&nbsp;256GB</b>:</p><p>1GB: £36.36* a month, £30 upfront.</p><p>5GB:&nbsp;£38.36* a month, £30 upfront.</p><p>25GB:&nbsp;£41.36* a month, £30 upfront.</p><p>30GB:&nbsp;£45.35* a month, £30 upfront.</p><p>125GB:&nbsp;£45.36* a month, £30 upfront.</p><p>150GB:&nbsp;£49.35* a month, £30 upfront.</p><p>Unlimited:&nbsp;£50.36* a month, £30 upfront.</p><p>Unlimited Plus: £54.35* a month, £30 upfront.</p><p>&nbsp;</p><p><b>Apple iPhone 15&nbsp;512GB</b>:</p><p>1GB: £41.90* a month, £30 upfront.</p><p>5GB:&nbsp;£43.90* a month, £30 upfront.</p><p>25GB:&nbsp;£46.90* a month, £30 upfront.</p><p>30GB:&nbsp;£50.89* a month, £30 upfront.</p><p>125GB:&nbsp;£50.90* a month, £30 upfront.</p><p>150GB:&nbsp;£54.89* a month, £30 upfront.</p><p>Unlimited:&nbsp;£55.90* a month, £30 upfront.</p><p>Unlimited Plus: £59.89* a month, £30 upfront.</p><p>&nbsp;</p><p>O2 Refresh custom plans: Direct purchases only. Pay the cash price for your device or spread the cost over 3 to 36 months (excludes dongles). The device cost will be the same whatever you choose. There may be an upfront cost. You can pay off your Device Plan at any time and choose to keep your Airtime Plan, upgrade it, or leave. If you are in the first 24 months of your Device Plan and you cancel your Airtime Plan you will have to pay the remainder of your Device Plan in full. After 24 months you can keep your Airtime Plan, upgrade it, or end it without affecting your Device Plan.</p><p>&nbsp;</p><p>UK data only. Fair Usage policy applies. Devices are subject to availability. 0% APR. Finance subject to status and credit checks. 18+. Direct Debit. Credit provided by Telefonica UK Ltd, 500 Brook Drive, Reading, RG2 6UU, UK. Telefonica UK is authorised and regulated by the FCA for consumer credit and insurance. Terms apply,<a href="http://www.o2.co.uk/terms" target="_blank">o2.co.uk/terms</a>.</p>'],
        'iPhone 15 Pro Max': ['30.00',	'46.69',	'29.69',	'17.00',	'5G',	'Save up to £335. Ends 3 July.',	'<p><strong>*Monthly price of your Airtime Plan will increase each April from April 2025 by the Retail Price Index rate of inflation announced in February each year plus 3.9%. If RPI is negative, we\'ll only apply the 3.9%. See<a href="http://o2.co.uk/prices" target="_blank">o2.co.uk/prices</a>.</strong></p><p>&nbsp;</p><p><b>Apple iPhone 15 Pro Max 256GB</b>: £335 saving consists of £191 discount applied to device plan (total cost of device was £1,290 now £1,099) and further £144 saving achieve by £4 per month discount on the airtime plan over 36 months. Ends 3 July 2024. Data allowances must be used within the month and cannot be carried over. Subject to availability.</p><p>&nbsp;</p><p>O2 Refresh custom plans: Direct purchases only. Pay the cash price for your device or spread the cost over 3 to 36 months (excludes dongles). The device cost will be the same whatever you choose. There may be an upfront cost. You can pay off your Device Plan at any time and choose to keep your Airtime Plan, upgrade it, or leave. If you are in the first 24 months of your Device Plan and you cancel your Airtime Plan you will have to pay the remainder of your Device Plan in full. After 24 months you can keep your Airtime Plan, upgrade it, or end it without affecting your Device Plan.</p><p>&nbsp;</p><p>UK data only. Fair Usage policy applies. Devices are subject to availability. 0% APR. Finance subject to status and credit checks. 18+. Direct Debit. Credit provided by Telefonica UK Ltd, 500 Brook Drive, Reading, RG2 6UU, UK. Telefonica UK is authorised and regulated by the FCA for consumer credit and insurance. Terms apply,<a href="http://www.o2.co.uk/terms" target="_blank">o2.co.uk/terms</a>.</p>'],
        'Galaxy S24 Ultra 5G': ['30.00', '56.55', '35.55', '21.00', '5G', 'Claim a Samsung Galaxy Tab S6 Lite in grey, worth £349. Ends 30 April.', '<p>Promoter: Samsung Electronics (UK) Limited. UK, Isle of Man, Channel Islands or Republic of Ireland residents (18+) only or registered companies in the same.?Purchase a Samsung Galaxy S24, S24+, or S24 Ultra (Promotion Product) from a participating retailer between 03/04/2024 – 30/04/2024 and claim a Galaxy Tab S6 Lite in Grey by redemption. No cash alternative. To claim, Participants must visit <a href="https://samsungoffers.claims/sam/S24tab" target="_blank">samsungoffers.claims/S24tab</a>, upload proof of purchase and provide all other required information (Claim) within 30 days of purchase. Maximum 1 Claim per Promotion Product purchased (maximum 4 Claims per household) and a maximum of 10 Claims per company participant. See <a href="https://samsungoffers.claims/sam/S24tab" target="_blank">samsungoffers.claims/S24tab</a> for full Promotion terms.</p><p>&nbsp;</p><p>UK data only. Fair Usage policy applies. Devices are subject to availability. 0% APR. Finance subject to status and credit checks. 18+. Direct Debit. Credit provided by Telefonica UK Ltd, 500 Brook Drive, Reading, RG2 6UU, UK. Telefonica UK is authorised and regulated by the FCA for consumer credit and insurance. Terms apply, <a href="http://www.o2.co.uk/terms" target="_blank">o2.co.uk/terms</a>.</p>'],
        'Pixel 8 Pro': ['30.00', '44.03', '23.03', '21.00', '5G', '', ''],
        'iPhone 15 Pro': ['30.00', '39.11', '24.11', '15.00', '5G', 'Get from £39.11* a month, our lowest ever monthly cost. Ends 3 July.', '<p><strong>*Monthly price of your Airtime Plan will increase each April from April 2025 by the Retail Price Index rate of inflation announced in February each year plus 3.9%. If RPI is negative, we\'ll only apply the 3.9%. See<a href="http://o2.co.uk/prices" target="_blank">o2.co.uk/prices</a>.</strong></p><p>&nbsp;</p><p>Data allowances must be used within the month and&nbsp;cannot be carried over. Our lowest ever price, ends 3 July&nbsp;2024.</p><p>&nbsp;</p><p><b>Apple iPhone 15 Pro 128GB</b>:</p><p>1GB: £39.11* a month, £30 upfront.</p><p>5GB:&nbsp;£41.11* a month, £30 upfront.</p><p>25GB:&nbsp;£44.11* a month, £30 upfront.</p><p>30GB:&nbsp;£48.10* a month, £30 upfront.</p><p>125GB:&nbsp;£48.11* a month, £30 upfront.</p><p>150GB:&nbsp;£52.10* a month, £30 upfront.</p><p>Unlimited:&nbsp;£53.11* a month, £30 upfront.</p><p>Unlimited Plus: £57.10* a month, £30 upfront.</p><p>&nbsp;</p><p><b>Apple iPhone 15 Pro 256GB</b>:</p><p>1GB: £41.90* a month, £30 upfront.</p><p>5GB:&nbsp;£43.90* a month, £30 upfront.</p><p>25GB:&nbsp;£46.90* a month, £30 upfront.</p><p>30GB:&nbsp;£50.89* a month, £30 upfront.</p><p>125GB:&nbsp;£50.90* a month, £30 upfront.</p><p>150GB:&nbsp;£54.89* a month, £30 upfront.</p><p>Unlimited:&nbsp;£55.90* a month, £30 upfront.</p><p>Unlimited Plus: £59.89* a month, £30 upfront.</p><p>&nbsp;</p><p><b>Apple iPhone 15 Pro 512GB</b>:</p><p>1GB: £47.45* a month, £30 upfront.</p><p>5GB:&nbsp;£49.45* a month, £30 upfront.</p><p>25GB:&nbsp;£52.45* a month, £30 upfront.</p><p>30GB:&nbsp;£56.44* a month, £30 upfront.</p><p>125GB:&nbsp;£56.45* a month, £30 upfront.</p><p>150GB:&nbsp;£60.44* a month, £30 upfront.</p><p>Unlimited:&nbsp;£61.45* a month, £30 upfront.</p><p>Unlimited Plus: £65.44* a month, £30 upfront.</p><p>&nbsp;</p><p><b>Apple iPhone 15 Pro 1TB</b>:</p><p>1GB: £53* a month, £30 upfront.</p><p>5GB:&nbsp;£55* a month, £30 upfront.</p><p>25GB:&nbsp;£58* a month, £30 upfront.</p><p>30GB:&nbsp;£61.99* a month, £30 upfront.</p><p>125GB:&nbsp;£62* a month, £30 upfront.</p><p>150GB:&nbsp;£65.99* a month, £30 upfront.</p><p>Unlimited:&nbsp;£67* a month, £30 upfront.</p><p>Unlimited Plus: £70.99* a month, £30 upfront.</p><p>&nbsp;</p><p>O2 Refresh custom plans: Direct purchases only. Pay the cash price for your device or spread the cost over 3 to 36 months (excludes dongles). The device cost will be the same whatever you choose. There may be an upfront cost. You can pay off your Device Plan at any time and choose to keep your Airtime Plan, upgrade it, or leave. If you are in the first 24 months of your Device Plan and you cancel your Airtime Plan you will have to pay the remainder of your Device Plan in full. After 24 months you can keep your Airtime Plan, upgrade it, or end it without affecting your Device Plan.</p><p>&nbsp;</p><p>UK data only. Fair Usage policy applies. Devices are subject to availability. 0% APR. Finance subject to status and credit checks. 18+. Direct Debit. Credit provided by Telefonica UK Ltd, 500 Brook Drive, Reading, RG2 6UU, UK. Telefonica UK is authorised and regulated by the FCA for consumer credit and insurance. Terms apply,<a href="http://www.o2.co.uk/terms" target="_blank">o2.co.uk/terms</a>.</p>'],
        'iPhone 15 Plus': ['30.00',	'38.36',	'21.36',	'17.00',	'5G',	'Get from £38.36* a month, our lowest ever monthly cost. Ends 3 July.',	'<p><strong>*Monthly price of your Airtime Plan will increase each April from April 2025 by the Retail Price Index rate of inflation announced in February each year plus 3.9%. If RPI is negative, we\'ll only apply the 3.9%. See<a href="http://o2.co.uk/prices" target="_blank">o2.co.uk/prices</a>.</strong></p><p>&nbsp;</p><p>Data allowances must be used within the month and&nbsp;cannot be carried over. Our lowest ever price, ends 3 July&nbsp;2024.</p><p>&nbsp;</p><p><b>Apple iPhone 15 Plus 128GB</b>:</p><p>1GB: £38.36* a month, £30 upfront.</p><p>5GB:&nbsp;£40.36* a month, £30 upfront.</p><p>25GB:&nbsp;£43.36* a month, £30 upfront.</p><p>30GB:&nbsp;£47.35* a month, £30 upfront.</p><p>125GB:&nbsp;£47.36* a month, £30 upfront.</p><p>150GB:&nbsp;£51.35* a month, £30 upfront.</p><p>Unlimited:&nbsp;£52.36* a month, £30 upfront.</p><p>Unlimited Plus: £56.35* a month, £30 upfront.</p><p>&nbsp;</p><p><b>Apple iPhone 15 Plus 256GB</b>:</p><p>1GB: £41.11* a month, £30 upfront.</p><p>5GB:&nbsp;£43.11* a month, £30 upfront.</p><p>25GB:&nbsp;£46.11* a month, £30 upfront.</p><p>30GB:&nbsp;£50.10* a month, £30 upfront.</p><p>125GB:&nbsp;£50.11* a month, £30 upfront.</p><p>150GB:&nbsp;£54.10* a month, £30 upfront.</p><p>Unlimited:&nbsp;£55.11* a month, £30 upfront.</p><p>Unlimited Plus: £59.10* a month, £30 upfront.</p><p>&nbsp;</p><p><b>Apple iPhone 15 Plus 512GB</b>:</p><p>1GB: £46.69* a month, £30 upfront.</p><p>5GB:&nbsp;£48.69* a month, £30 upfront.</p><p>25GB:&nbsp;£51.69* a month, £30 upfront.</p><p>30GB:&nbsp;£55.68* a month, £30 upfront.</p><p>125GB:&nbsp;£55.69* a month, £30 upfront.</p><p>150GB:&nbsp;£59.68* a month, £30 upfront.</p><p>Unlimited:&nbsp;£60.69* a month, £30 upfront.</p><p>Unlimited Plus: £64.68* a month, £30 upfront.</p><p>&nbsp;</p><p>O2 Refresh custom plans: Direct purchases only. Pay the cash price for your device or spread the cost over 3 to 36 months (excludes dongles). The device cost will be the same whatever you choose. There may be an upfront cost. You can pay off your Device Plan at any time and choose to keep your Airtime Plan, upgrade it, or leave. If you are in the first 24 months of your Device Plan and you cancel your Airtime Plan you will have to pay the remainder of your Device Plan in full. After 24 months you can keep your Airtime Plan, upgrade it, or end it without affecting your Device Plan.</p><p>&nbsp;</p><p>UK data only. Fair Usage policy applies. Devices are subject to availability. 0% APR. Finance subject to status and credit checks. 18+. Direct Debit. Credit provided by Telefonica UK Ltd, 500 Brook Drive, Reading, RG2 6UU, UK. Telefonica UK is authorised and regulated by the FCA for consumer credit and insurance. Terms apply,<a href="http://www.o2.co.uk/terms" target="_blank">o2.co.uk/terms</a>.</p>'],
        'Galaxy S24 5G': ['30.00', '38.36', '21.36', '17.00', '5G', 'Claim a Samsung Galaxy Tab S6 Lite in grey, worth £349. Ends 30 April.', '<p>Promoter: Samsung Electronics (UK) Limited. UK, Isle of Man, Channel Islands or Republic of Ireland residents (18+) only or registered companies in the same.  Purchase a Samsung Galaxy S24, S24+, or S24 Ultra (Promotion Product) from a participating retailer between 03/04/2024 – 30/04/2024 and claim a Galaxy Tab S6 Lite in Grey by redemption. No cash alternative. To claim, Participants must visit <a href="https://samsungoffers.claims/sam/S24tab" target="_blank">samsungoffers.claims/S24tab</a>, upload proof of purchase and provide all other required information (Claim) within 30 days of purchase. Maximum 1 Claim per Promotion Product purchased (maximum 4 Claims per household) and a maximum of 10 Claims per company participant. See <a href="https://samsungoffers.claims/sam/S24tab" target="_blank">samsungoffers.claims/S24tab</a> for full Promotion terms.</p><p>&nbsp;</p><p>UK data only. Fair Usage policy applies. Devices are subject to availability. 0% APR. Finance subject to status and credit checks. 18+. Direct Debit. Credit provided by Telefonica UK Ltd, 500 Brook Drive, Reading, RG2 6UU, UK. Telefonica UK is authorised and regulated by the FCA for consumer credit and insurance. Terms apply, <a href="http://www.o2.co.uk/terms" target="_blank">o2.co.uk/terms</a>.</p>'],
        'Galaxy S24 Plus 5G': ['30.00', '49.27', '28.27', '21.00', '5G', 'Claim a Samsung Galaxy Tab S6 Lite in grey, worth £349. Ends 30 April.', '<p>Promoter: Samsung Electronics (UK) Limited. UK, Isle of Man, Channel Islands or Republic of Ireland residents (18+) only or registered companies in the same.? Purchase a Samsung Galaxy S24, S24+, or S24 Ultra (Promotion Product) from a participating retailer between 03/04/2024 – 30/04/2024 and claim a Galaxy Tab S6 Lite in Grey by redemption. No cash alternative. To claim, Participants must visit <a href="https://samsungoffers.claims/sam/S24tab" target="_blank">samsungoffers.claims/S24tab</a>, upload proof of purchase and provide all other required information (Claim) within 30 days of purchase. Maximum 1 Claim per Promotion Product purchased (maximum 4 Claims per household) and a maximum of 10 Claims per company participant. See <a href="https://samsungoffers.claims/sam/S24tab" target="_blank">samsungoffers.claims/S24tab</a> for full Promotion terms.</p><p>&nbsp;</p><p>UK data only. Fair Usage policy applies. Devices are subject to availability. 0% APR. Finance subject to status and credit checks. 18+. Direct Debit. Credit provided by Telefonica UK Ltd, 500 Brook Drive, Reading, RG2 6UU, UK. Telefonica UK is authorised and regulated by the FCA for consumer credit and insurance. Terms apply, <a href="http://www.o2.co.uk/terms" target="_blank">o2.co.uk/terms</a>.</p>'],
        'Galaxy Z Flip5': ['30.00', '39.31', '28.31', '11.00', '5G', 'Save up to £360. Ends 1 May.', '<p><strong>*Monthly price of your Airtime Plan will increase each April from April 2025 by the Retail Price Index rate of inflation announced in February each year plus 3.9%. If RPI is negative, we\'ll only apply the 3.9%. See <a href="http://o2.co.uk/prices" target="_blank">o2.co.uk/prices</a>.</strong></p><p>&nbsp;</p><p><strong>Samsung Galaxy Z Flip5</strong>: £360 saving achieved by £10 per month discount on the 1GB, 5GB, 25GB, 30GB, 125GB, 150GB, Unlimited and Unlimited Plus Airtime Plans over 36 months. Offer ends 1 May 2024.</p><p>&nbsp;</p><p>O2 Refresh custom plans: Direct purchases only. Pay the cash price for your device or spread the cost over 3 to 36 months (excludes dongles). The device cost will be the same whatever you choose. There may be an upfront cost. You can pay off your Device Plan at any time and choose to keep your Airtime Plan, upgrade it, or leave. If you are in the first 24 months of your Device Plan and you cancel your Airtime Plan you will have to pay the remainder of your Device Plan in full. After 24 months you can keep your Airtime Plan, upgrade it, or end it without affecting your Device Plan.</p><p>&nbsp;</p><p>UK data only. Fair Usage policy applies. Devices are subject to availability. 0% APR. Finance subject to status and credit checks. 18+. Direct Debit. Credit provided by Telefonica UK Ltd, 500 Brook Drive, Reading, RG2 6UU, UK. Telefonica UK is authorised and regulated by the FCA for consumer credit and insurance. Terms apply, <a href="http://www.o2.co.uk/terms" target="_blank">o2.co.uk/terms</a>.</p>'],
        'Galaxy Z Fold5': ['30.00', '58.75', '47.75', '11.00', '5G', 'Save up to £360. Ends 1 May.', '<p><strong>*Monthly price of your Airtime Plan will increase each April from April 2025 by the Retail Price Index rate of inflation announced in February each year plus 3.9%. If RPI is negative, we\'ll only apply the 3.9%. See <a href="http://o2.co.uk/prices" target="_blank">o2.co.uk/prices</a>.</strong></p><p>&nbsp;</p><p><strong>Samsung Galaxy Z Fold5</strong>: £360 saving achieved by £10 per month discount on the 1GB, 5GB, 25GB, 30GB, 125GB, 150GB, Unlimited and Unlimited Plus Airtime Plans over 36 months. Offer ends 1 May 2024.</p><p>&nbsp;</p><p>O2 Refresh custom plans: Direct purchases only. Pay the cash price for your device or spread the cost over 3 to 36 months (excludes dongles). The device cost will be the same whatever you choose. There may be an upfront cost. You can pay off your Device Plan at any time and choose to keep your Airtime Plan, upgrade it, or leave. If you are in the first 24 months of your Device Plan and you cancel your Airtime Plan you will have to pay the remainder of your Device Plan in full. After 24 months you can keep your Airtime Plan, upgrade it, or end it without affecting your Device Plan.</p><p>&nbsp;</p><p>UK data only. Fair Usage policy applies. Devices are subject to availability. 0% APR. Finance subject to status and credit checks. 18+. Direct Debit. Credit provided by Telefonica UK Ltd, 500 Brook Drive, Reading, RG2 6UU, UK. Telefonica UK is authorised and regulated by the FCA for consumer credit and insurance. Terms apply, <a href="http://www.o2.co.uk/terms" target="_blank">o2.co.uk/terms</a>.</p>'],
        'iPhone 14': ['30.00',	'32.81',	'15.81',	'17.00',	'5G',	'Get from £32.81* a month, our lowest ever monthly cost. Ends 3 July.',	'<p><strong>*Monthly price of your Airtime Plan will increase each April from April 2025 by the Retail Price Index rate of inflation announced in February each year plus 3.9%. If RPI is negative, we\'ll only apply the 3.9%. See<a href="http://o2.co.uk/prices" target="_blank">o2.co.uk/prices</a>.</strong></p><p>&nbsp;</p><p>Data allowances must be used within the month and&nbsp;cannot be carried over. Our lowest ever price, ends 3 July&nbsp;2024.</p><p>&nbsp;</p><p><b>Apple iPhone 14&nbsp;128GB</b>:</p><p>1GB: £32.81* a month, £30 upfront.</p><p>5GB:&nbsp;£34.81* a month, £30 upfront.</p><p>25GB:&nbsp;£37.81* a month, £30 upfront.</p><p>30GB:&nbsp;£41.80* a month, £30 upfront.</p><p>125GB:&nbsp;£41.81* a month, £30 upfront.</p><p>150GB:&nbsp;£45.80* a month, £30 upfront.</p><p>Unlimited:&nbsp;£46.81*&nbsp;a month, £30 upfront.</p><p>Unlimited Plus: £50.80* a month, £30&nbsp;upfront.</p><p>&nbsp;</p><p><b>Apple iPhone 14 256GB</b>:</p><p>1GB: £35.56* a month, £30 upfront.</p><p>5GB:&nbsp;£37.56* a month, £30 upfront.</p><p>25GB:&nbsp;£40.56* a month, £30 upfront.</p><p>30GB:&nbsp;£44.55* a month, £30 upfront.</p><p>125GB:&nbsp;£44.56* a month, £30 upfront.</p><p>150GB:&nbsp;£48.55* a month, £30 upfront.</p><p>Unlimited:&nbsp;£49.56*&nbsp;a month, £30 upfront.</p><p>Unlimited Plus: £53.55* a month, £30&nbsp;upfront.</p><p>&nbsp;</p><p><b>Apple iPhone 14 512GB</b>:</p><p>1GB: £41.11* a month, £30 upfront.</p><p>5GB:&nbsp;£43.11* a month, £30 upfront.</p><p>25GB:&nbsp;£46.11* a month, £30 upfront.</p><p>30GB: £50.10* a month, £30 upfront.</p><p>125GB:&nbsp;£50.11* a month, £30 upfront.</p><p>150GB:&nbsp;£54.10* a month, £30 upfront.</p><p>Unlimited:&nbsp;£55.11*&nbsp;a month, £30 upfront.</p><p>Unlimited Plus: £59.10* a month, £30&nbsp;upfront.</p><p>&nbsp;</p><p>O2 Refresh custom plans: Direct purchases only. Pay the cash price for your device or spread the cost over 3 to 36 months (excludes dongles). The device cost will be the same whatever you choose. There may be an upfront cost. You can pay off your Device Plan at any time and choose to keep your Airtime Plan, upgrade it, or leave. If you are in the first 24 months of your Device Plan and you cancel your Airtime Plan you will have to pay the remainder of your Device Plan in full. After 24 months you can keep your Airtime Plan, upgrade it, or end it without affecting your Device Plan.</p><p>&nbsp;</p><p>UK data only. Fair Usage policy applies. Devices are subject to availability. 0% APR. Finance subject to status and credit checks. 18+. Direct Debit. Credit provided by Telefonica UK Ltd, 500 Brook Drive, Reading, RG2 6UU, UK. Telefonica UK is authorised and regulated by the FCA for consumer credit and insurance. Terms apply,<a href="http://www.o2.co.uk/terms" target="_blank">o2.co.uk/terms</a>.</p>'],
        'iPhone 13': ['20.00', '30.30', '13.30', '17.00', '5G', '', ''],
        'iPhone 14 Plus': ['30.00',	'35.56',	'18.56',	'17.00',	'5G',	'Get from £35.56* a month, our lowest ever monthly cost. Ends 3 July.',	'<p><strong>*Monthly price of your Airtime Plan will increase each April from April 2025 by the Retail Price Index rate of inflation announced in February each year plus 3.9%. If RPI is negative, we\'ll only apply the 3.9%. See<a href="http://o2.co.uk/prices" target="_blank">o2.co.uk/prices</a>.</strong></p><p>&nbsp;</p><p>Data allowances must be used within the month and&nbsp;cannot be carried over. Our lowest ever price, ends 3 July&nbsp;2024.</p><p>&nbsp;</p><p><b>Apple iPhone 14 Plus 128GB</b>:</p><p>1GB: £35.56* a month, £30 upfront.</p><p>5GB:&nbsp;£37.56* a month, £30 upfront.</p><p>25GB:&nbsp;£40.56* a month, £30 upfront.</p><p>30GB:&nbsp;£44.55* a month, £30 upfront.</p><p>125GB:&nbsp;£44.56* a month, £30 upfront.</p><p>150GB:&nbsp;£48.55* a month, £30 upfront.</p><p>Unlimited:&nbsp;£49.56*&nbsp;a month, £30 upfront.</p><p>Unlimited Plus: £53.55* a month, £30&nbsp;upfront.</p><p>&nbsp;</p><p><b>Apple iPhone 14 Plus 256GB</b>:</p><p>1GB: £38.36* a month, £30 upfront.</p><p>5GB:&nbsp;£40.36* a month, £30 upfront.</p><p>25GB:&nbsp;£43.36* a month, £30 upfront.</p><p>30GB:&nbsp;£47.35* a month, £30 upfront.</p><p>125GB:&nbsp;£47.36* a month, £30 upfront.</p><p>150GB:&nbsp;£51.35* a month, £30 upfront.</p><p>Unlimited:&nbsp;£52.36*&nbsp;a month, £30 upfront.</p><p>Unlimited Plus: £56.35* a month, £30&nbsp;upfront.</p><p>&nbsp;</p><p><b>Apple iPhone 14 Plus 512GB</b>:</p><p>1GB: £43.90* a month, £30 upfront.</p><p>5GB:&nbsp;£45.90* a month, £30 upfront.</p><p>25GB:&nbsp;£48.90* a month, £30 upfront.</p><p>30GB: £52.89* a month, £30 upfront.</p><p>125GB:&nbsp;£52.90* a month, £30 upfront.</p><p>150GB:&nbsp;£56.89* a month, £30 upfront.</p><p>Unlimited:&nbsp;£57.90*&nbsp;a month, £30 upfront.</p><p>Unlimited Plus: £61.89*&nbsp;a month, £30&nbsp;upfront.</p><p>&nbsp;</p><p>O2 Refresh custom plans: Direct purchases only. Pay the cash price for your device or spread the cost over 3 to 36 months (excludes dongles). The device cost will be the same whatever you choose. There may be an upfront cost. You can pay off your Device Plan at any time and choose to keep your Airtime Plan, upgrade it, or leave. If you are in the first 24 months of your Device Plan and you cancel your Airtime Plan you will have to pay the remainder of your Device Plan in full. After 24 months you can keep your Airtime Plan, upgrade it, or end it without affecting your Device Plan.</p><p>&nbsp;</p><p>UK data only. Fair Usage policy applies. Devices are subject to availability. 0% APR. Finance subject to status and credit checks. 18+. Direct Debit. Credit provided by Telefonica UK Ltd, 500 Brook Drive, Reading, RG2 6UU, UK. Telefonica UK is authorised and regulated by the FCA for consumer credit and insurance. Terms apply,<a href="http://www.o2.co.uk/terms" target="_blank">o2.co.uk/terms</a>.</p>'],
        'Galaxy S23 FE 5G': ['30.00', '36.81', '15.81', '21.00', '5G', 'Claim a pair of Samsung Galaxy Buds FE in white, worth £99. Ends 30 May.', '<p>Promoter: Samsung Electronics (UK) Limited. UK, Isle of Man and Channel Islands residents (18+) only or registered companies in the same.?Purchase the Samsung Galaxy S23 FE, Tab S9 FE or Tab S9 FE+ (Promotion Product) from a participating retailer between 03/04/2024 – 30/05/2024 and claim Galaxy Buds FE in White by redemption. No cash alternative. Participants must visit <a href="https://samsung-offers.claims/feduo" target="_blank">https://samsung-offers.claims/feduo</a> to upload proof of purchase and provide all other required information (Claim). All Participants must claim within 30 days of purchase. Claim period closes on 29/06/2024.?Maximum 1 Claim per Promotion Product purchased (maximum 4 Claims per household) and a maximum of 10 Claims per company participant. See <a href="https://samsung-offers.claims/feduo" target="_blank">https://samsung-offers.claims/feduo</a> for full Promotion terms.</p><p>&nbsp;</p><p>UK data only. Fair Usage policy applies. Devices are subject to availability. 0% APR. Finance subject to status and credit checks. 18+. Direct Debit. Credit provided by Telefonica UK Ltd, 500 Brook Drive, Reading, RG2 6UU, UK. Telefonica UK is authorised and regulated by the FCA for consumer credit and insurance. Terms apply, <a href="http://www.o2.co.uk/terms" target="_blank">o2.co.uk/terms</a>.</p>'],
        'Pixel 7a': ['10.00', '31.48', '10.48', '21.00', '5G', '', ''],
        'Pixel 8': ['30.00', '39.59', '18.59', '21.00', '5G', '', ''],
        'Razr 40': ['30.00', '42.37', '21.37', '21.00', '5G', 'Claim a pair of Bose Quiet Comfort Earbuds 2, worth £239.99. Ends 1 May.', '<p>This offer is open to UK (England, Scotland, Wales and Northern Ireland) legal residents aged 18 or over, who purchase a Motorola Razr 40 in-store or online, either outright or as part of a monthly contract (“Qualifying Device”); from 00:01 on 04/04/24 and 23:59 on 01/05/24 inclusive (“Promotional Period”); from O2: unless all 600 gifts are claimed before this date. Please note availability of Qualifying Devices is subject to change and may differ across sales channels. Purchase and internet access required. Retain proof of purchase. 600 x Bose Quiet Comfort Earbuds 2 (total value £239.99 RRP taken on 06/02/2024), available to claim, one gift per Qualifying Device. To claim, purchase a Qualifying Device then visit <a href="https://motorolabosemarchapril2024.promo.uk.com/" target="_blank">motorolabosemarchapril2024.promo.uk.com/</a> between 00:01 on 04/04/24 and 23:59 on 16/05/24 inclusive ("Redemption Period")for O2; and provide their full name, email address, shipping address for delivery and upload their proof of purchase ("Claim"). Claim must be made by 16/05/24. Proof of purchase must be dated between 00:01 on 04/04/24 and 01/05/24 inclusive for O2; and prior to date of claim. Customers who return their mobile device during the cooling off period because of a change of mind are not eligible. Exclusions apply. For full Terms and Conditions please visit <a href="https://motorolabosemarchapril2024.promo.uk.com/" target="_blank">motorolabosemarchapril2024.promo.uk.com/</a></p><p>&nbsp;</p><p>UK data only. Fair Usage policy applies. Devices are subject to availability. 0% APR. Finance subject to status and credit checks. 18+. Direct Debit. Credit provided by Telefonica UK Ltd, 500 Brook Drive, Reading, RG2 6UU, UK. Telefonica UK is authorised and regulated by the FCA for consumer credit and insurance. Terms apply, see <a href="https://www.o2.co.uk/termsandconditions">o2.co.uk/terms.</a></p>'],
        'Galaxy A25 5G': ['30.00', '27.92', '6.92', '21.00', '5G', '', ''],
        'Galaxy A35 5G': ['10.00',	'27.37',	'8.37',	'19.00',	'5G',	'Introductory offer. Save up to £72. Ends 1 May.',	'<p><strong>*Monthly price of your Airtime Plan will increase each April from April 2025 by the Retail Price Index rate of inflation announced in February each year plus 3.9%. If RPI is negative, we\'ll only apply the 3.9%. See<a href="http://o2.co.uk/prices" target="_blank">o2.co.uk/prices</a>.</strong></p><p>&nbsp;</p><p>Introductory Offer: £72 saving achieved by £2 per month discount on the 1GB, 5GB, 25GB, 30GB, 125GB, 150GB, Unlimited and Unlimited Plus&nbsp;Airtime Plans over 36 months. Discount applies until you change tariff, leave or upgrade. Data allowances must be used within the month and cannot be carried over. Subject to availability. Ends 1 May 2024.</p><p>&nbsp;</p><p>O2 Refresh custom plans: Direct purchases only. Pay the cash price for your device or spread the cost over 3 to 36 months (excludes dongles). The device cost will be the same whatever you choose. There may be an upfront cost. You can pay off your Device Plan at any time and choose to keep your Airtime Plan, upgrade it, or leave. If you are in the first 24 months of your Device Plan and you cancel your Airtime Plan you will have to pay the remainder of your Device Plan in full. After 24 months you can keep your Airtime Plan, upgrade it, or end it without affecting your Device Plan.</p><p>&nbsp;</p><p>UK data only. Fair Usage policy applies. Devices are subject to availability. 0% APR. Finance subject to status and credit checks. 18+. Direct Debit. Credit provided by Telefonica UK Ltd, 500 Brook Drive, Reading, RG2 6UU, UK. Telefonica UK is authorised and regulated by the FCA for consumer credit and insurance. Terms apply,<a href="http://www.o2.co.uk/terms" target="_blank">o2.co.uk/terms</a>.</p>'],
        'Galaxy A55 5G': ['10.00', '32.14', '11.14', '21.00', '5G', '', ''],
        'Galaxy A15': ['', '25.42', '4.42', '21.00', '4G', '', ''],
        'Xperia 5 V': ['30.00', '43.75', '22.75', '21.00', '5G', '', ''],
        'Xperia 1 V': ['30.00', '56.25', '35.25', '21.00', '5G', '', ''],
        'Xperia 10 V': ['30.00', '31.25', '10.25', '21.00', '5G', '', ''],
        'Galaxy A23 5G': ['', '29.00', '8.00', '21.00', '5G', '', ''],
        'Galaxy A34 5G': ['', '30.42', '9.42', '21.00', '5G', '', ''],
        'Galaxy A54 5G': ['10.00', '33.20', '12.20', '21.00', '5G', '', ''],
        'iPhone 14 Pro': ['30.00', '50.25', '29.25', '21.00', '5G', '', ''],
        'iPhone 14 Pro Max': ['30.00', '54.12', '33.12', '21.00', '5G', '', ''],
        'iPhone 12 5G': ['20.00',	'28.92',	'11.92',	'17.00',	'5G',	'Save up to £231. Ends 3 July.',	'<p><strong>*Monthly price of your Airtime Plan will increase each April from April 2025 by the Retail Price Index rate of inflation announced in February each year plus 3.9%. If RPI is negative, we\'ll only apply the 3.9%. See<a href="http://o2.co.uk/prices" target="_blank">o2.co.uk/prices</a>.</strong></p><p>&nbsp;</p><p><b>Apple iPhone 12 64GB</b>: £231.99 saving consists of £87.99 discount applied to&nbsp;device plan (total cost of device was £537 now&nbsp;£449.01) and further £144 saving achieve by £4 per&nbsp;month discount on the airtime plan over 36 months.&nbsp;Ends 3 July 2024. Data allowances must be used&nbsp;within the month and cannot be carried over.&nbsp;Subject to availability.</p><p>&nbsp;</p><p>O2 Refresh custom plans: Direct purchases only. Pay the cash price for your device or spread the cost over 3 to 36 months (excludes dongles). The device cost will be the same whatever you choose. There may be an upfront cost. You can pay off your Device Plan at any time and choose to keep your Airtime Plan, <p>upgrade it, or leave. If you are in the first 24 months of your Device Plan and you cancel your Airtime Plan you will have to pay the remainder of your Device Plan in full. After 24 months you can keep your Airtime Plan, upgrade it, or end it without affecting your Device Plan.</p><p>&nbsp;</p><p>UK data only. Fair Usage policy applies. Devices are subject to availability. 0% APR. Finance subject to status and credit checks. 18+. Direct Debit. Credit provided by Telefonica UK Ltd, 500 Brook Drive, Reading, RG2 6UU, UK. Telefonica UK is authorised and regulated by the FCA for consumer credit and insurance. Terms apply,<a href="http://www.o2.co.uk/terms" target="_blank">o2.co.uk/terms</a>.</p>'],
        'Pixel Fold': ['30.00', '68.75', '47.75', '21.00', '5G', '', ''],
        'Redmi Note 12 Pro 5G': ['30.00', '30.14', '9.14', '21.00', '5G', '', ''],
        'Galaxy S23': ['30.00', '40.50', '19.50', '21.00', '5G', '', ''],
        'Galaxy S23 Ultra': ['30.00', '56.95', '35.95', '21.00', '5G', 'Get £300 off the upfront cost. Use code NCS23ULT. While stocks last.', '<p><strong>*Monthly price of your Airtime Plan will increase each April from April 2025 by the Retail Price Index rate of inflation announced in February each year plus 3.9%. If RPI is negative, we\'ll only apply the 3.9%. See <a href="http://o2.co.uk/prices" target="_blank">o2.co.uk/prices</a>.</strong></p><p>&nbsp;</p><p>Get a £300 voucher code on the <strong>Samsung Galaxy S23 Ultra</strong>when purchased on an O2 Refresh tariff directly from O2. £300 discount applied to upfront cost of Device Plan. While stocks last. To apply the full discount, for online purchases, set your upfront cost to at least £300 and select your desired Device Plan length and tariff. Paste voucher code “<strong>NCS23ULT</strong>” into the ‘Got a promo code?’ section. For in store and telephone purchases, provide the code to the advisor. Code must be applied at time of purchase and cannot be applied retrospectively. Code can only be used once in any single transaction. One voucher code per transaction. Offer may be withdrawn at any time.</p><p>&nbsp;</p><p>O2 Refresh custom plans: Direct purchases only. Pay the cash price for your device or spread the cost over 3 to 36 months (excludes dongles). The device cost will be the same whatever you choose. There may be an upfront cost. You can pay off your Device Plan at any time and choose to keep your Airtime Plan, upgrade it, or leave. If you are in the first 24 months of your Device Plan and you cancel your Airtime Plan you will have to pay the remainder of your Device Plan in full. After 24 months you can keep your Airtime Plan, upgrade it, or end it without affecting your Device Plan.</p><p>&nbsp;</p><p>UK data only. Fair Usage policy applies. Devices are subject to availability. 0% APR. Finance subject to status and credit checks. 18+. Direct Debit. Credit provided by Telefonica UK Ltd, 500 Brook Drive, Reading, RG2 6UU, UK. Telefonica UK is authorised and regulated by the FCA for consumer credit and insurance. Terms apply, see <a href="http://o2.co.uk/terms" target="_blank">o2.co.uk/terms</a>.</p>'],
        'Pixel 7': ['30.00', '36.81', '15.81', '21.00', '5G', '', ''],
        'Pixel 7 Pro': ['30.00', '43.75', '22.75', '21.00', '5G', '', ''],
        'Galaxy S23 Plus': ['30.00', '51.06', '30.06', '21.00', '5G', 'Get £200 off the upfront cost. Use code NCO2S23P200. While stocks last.', '<p><strong>*Each year your Airtime Plan will be increased by the Retail Price Index (RPI) rate of inflation announced in February plus 3.9%. If RPI is negative, we’ll only apply the 3.9%. You’ll see this increase on your April 2024 bill onwards. See <a href="http://o2.co.uk/prices" target="_blank">o2.co.uk/prices</a>.</strong></p><p>&nbsp;</p><p>£200 Voucher Code: New or existing O2 customers only. £200 off the upfront cost of a Samsung S23 Plus when purchased online on an O2 Refresh tariff. £200 discount applied to cost of device. Discount applied to upfront cost of Device Plan. To apply the discount, set your upfront cost to at least £200 and select your desired device plan length and tariff. Within the basket paste code <strong>NCO2S23P200</strong> into the ‘Got a promo code?’ section. Code must be applied at time of purchase and cannot be applied retrospectively. Voucher code can only be used once, in a single transaction. One voucher code per transaction. While stocks last.</p><p>&nbsp;</p><p>O2 Refresh custom plans: Direct purchases only. Pay the cash price for your device or spread the cost over 3 to 36 months (excludes dongles). The device cost will be the same whatever you choose. There may be an upfront cost. You can pay off your Device Plan at any time and choose to keep your Airtime Plan, upgrade it, or leave. If you are in the first 24 months of your Device Plan and you cancel your Airtime Plan you will have to pay the remainder of your Device Plan in full. After 24 months you can keep your Airtime Plan, upgrade it, or end it without affecting your Device Plan.</p><p>&nbsp;</p><p>UK data only. Fair Usage policy applies. Devices are subject to availability. 0% APR. Finance subject to status and credit checks. 18+. Direct Debit. Credit provided by Telefonica UK Ltd, 500 Brook Drive, Reading, RG2 6UU, UK. Telefonica UK is authorised and regulated by the FCA for consumer credit and insurance. Terms apply, see <a href="http://www.o2.co.uk/terms" target="_blank">o2.co.uk/terms</a>.</p>'],
        'Galaxy S22': ['30.00', '42.37', '21.37', '21.00', '5G', 'Get £200 off the upfront cost. Use code NCO2S22200. While stocks last.', '<p><strong>*Monthly price of your Airtime Plan will increase each April from April 2025 by the Retail Price Index rate of inflation announced in February each year plus 3.9%. If RPI is negative, we\'ll only apply the 3.9%. See <a href="http://o2.co.uk/prices" target="_blank">o2.co.uk/prices</a>.</strong></p><p>&nbsp;</p><p>£200 Voucher Code: New or existing O2 customers only. £200 off the upfront cost of a Samsung S22 128GB when purchased online on an O2 Refresh tariff. £200 discount applied to cost of device. Discount applied to upfront cost of Device Plan. To apply the discount, set your upfront cost to at least £200 and select your desired device plan length and tariff. Within the basket paste code <strong>NCO2S22200</strong> into the ‘Got a promo code?’ section. Code must be applied at time of purchase and cannot be applied retrospectively. Voucher code can only be used once, in a single transaction. One voucher code per transaction. While stocks last.</p><p>&nbsp;</p><p>O2 Refresh custom plans: Direct purchases only. Pay the cash price for your device or spread the cost over 3 to 36 months (excludes dongles). The device cost will be the same whatever you choose. There may be an upfront cost. You can pay off your Device Plan at any time and choose to keep your Airtime Plan, upgrade it, or leave. If you are in the first 24 months of your Device Plan and you cancel your Airtime Plan you will have to pay the remainder of your Device Plan in full. After 24 months you can keep your Airtime Plan, upgrade it, or end it without affecting your Device Plan.</p><p>&nbsp;</p><p>UK data only. Fair Usage policy applies. Devices are subject to availability. 0% APR. Finance subject to status and credit checks. 18+. Direct Debit. Credit provided by Telefonica UK Ltd, 500 Brook Drive, Reading, RG2 6UU, UK. Telefonica UK is authorised and regulated by the FCA for consumer credit and insurance. Terms apply, <a href="http://www.o2.co.uk/terms" target="_blank">o2.co.uk/terms</a>.</p>'],
        'Galaxy Z Fold4': ['30.00', '68.73', '47.73', '21.00', '5G', '', ''],
        '2660 Flip': ['', '22.81', '1.81', '21.00', '4G', '', ''],
        '6880': ['', '23.50', '2.50', '21.00', '4G', '', ''],
        '8100': ['', '25.70', '4.70', '21.00', '4G', '', ''],
        'A17': ['', '24.17', '3.17', '21.00', '4G', '', ''],
        'A78': ['', '26.25', '5.25', '21.00', '5G', '', ''],
        'C12': ['', '23.75', '2.75', '21.00', '4G', '', ''],
        'G22': ['10.00', '24.59', '3.59', '21.00', '4G', '', ''],
        'Galaxy A04s 4G': ['', '25.42', '4.42', '21.00', '4G', '', ''],
        'Galaxy A05s': ['', '24.59', '3.59', '21.00', '4G', '', ''],
        'Galaxy A13 5G': ['', '27.25', '6.25', '21.00', '5G', '', ''],
        'Galaxy A14': ['10.00', '25.70', '4.70', '21.00', '4G', '', ''],
        'Galaxy A14 5G': ['10.00', '27.09', '6.09', '21.00', '5G', '', ''],
        'Galaxy A15 5G': ['', '26.25', '5.25', '21.00', '5G', '', ''],
        'Galaxy S22 Plus': ['30.00', '47.56', '26.56', '21.00', '5G', '', ''],
        'Galaxy Z Flip4': ['30.00', '49.59', '28.59', '21.00', '5G', '', ''],
        'Redmi 12 5G': ['10.00', '24.87', '3.87', '21.00', '5G', '', ''],
        'Redmi 13C': ['30.00', '22.95', '1.95', '21.00', '4G', '', ''],
        'Redmi A2': ['', '24.03', '3.03', '21.00', '4G', '', ''],
        'Xperia 10 IV': ['10.00', '32.50', '11.50', '21.00', '5G', '', ''],
        'Xperia 5 IV': ['30.00', '45.00', '24.00', '21.00', '5G', '', ''],
        'iPhone 11': ['20.00', '33.00', '12.00', '21.00', '4G', '', ''],
        'iPhone SE 3rd Generation': ['20.00',	'26.97',	'9.97',	'17.00',	'5G',	'Save up to £213. Ends 3 July.',	'<p><strong>*Monthly price of your Airtime Plan will increase each April from April 2025 by the Retail Price Index rate of inflation announced in February each year plus 3.9%. If RPI is negative, we\'ll only apply the 3.9%. See<a href="http://o2.co.uk/prices" target="_blank">o2.co.uk/prices</a>.</strong></p><p>&nbsp;</p><p><b>Apple iPhone SE 3rd Generation 64GB</b>: £213.95 saving consists of £69.95 discount applied to device plan (total cost of device was £449 now £379.05) and further £144 saving achieve by £4 per month discount on the airtime plan over 36 months. Ends 3 July 2024. Data allowances must be used within the month and cannot be carried over. Subject to availability.</p><p>&nbsp;</p><p>O2 Refresh custom plans: Direct purchases only. Pay the cash price for your device or spread the cost over 3 to 36 months (excludes dongles). The device cost will be the same whatever you choose. There may be an upfront cost. You can pay off your Device Plan at any time and choose to keep your Airtime Plan, upgrade it, or leave. If you are in the first 24 months of your Device Plan and you cancel your Airtime Plan you will have to pay the remainder of your Device Plan in full. After 24 months you can keep your Airtime Plan, upgrade it, or end it without affecting your Device Plan.</p><p>&nbsp;</p><p>UK data only. Fair Usage policy applies. Devices are subject to availability. 0% APR. Finance subject to status and credit checks. 18+. Direct Debit. Credit provided by Telefonica UK Ltd, 500 Brook Drive, Reading, RG2 6UU, UK. Telefonica UK is authorised and regulated by the FCA for consumer credit and insurance. Terms apply,<a href="http://www.o2.co.uk/terms" target="_blank">o2.co.uk/terms</a>.</p>'],
        'moto g04': ['', '23.50', '2.50', '21.00', '4G', '', ''],
        'moto g13': ['30.00', '24.31', '3.31', '21.00', '4G', '', ''],
        'moto g14': ['30.00', '24.31', '3.31', '21.00', '4G', '', ''],
        'moto g34 5G': ['', '25.17', '4.17', '21.00', '5G', '', ''],
        'Redmi A3':['', '23.19', '2.19', '21.00','5G', '', '']
      };
    }
    
    // Rerun script on device change    
    let utils = window.optimizely.get("utils");
    utils.observeSelector('.o2uk-header-curve__section', function () {
      if (utag_obj.page_page_name.includes('shop:cfa|phones|paymonthly:devices|listing')) {
        executeDR1204();
      }
    }, {
      "once": false
    });
  }
})();