(() => {
  try {
    function sendOptiEvent(eventName) {
      console.log('eventName', eventName);
      window["optimizely"] = window["optimizely"] || [];
      window["optimizely"].push({
        type: "event",
        eventName: eventName,
      });
    }

    function pushstateActivation(callback) {
      // setup pushstate
      if (!window.isPushstateUrlDetectionOn) {
        window.isPushstateUrlDetectionOn = true;
        var oldPushState = window.history.pushState;

        window.history.pushState = function (data) {
          try {
            oldPushState.apply(this, arguments);
            const currUrl = window.location.href;
            console.log('push state activation');
            callback(currUrl);
          } catch (e) {
            console.log("error in pushstate event url detection: ", e);
          }
        };
      }
    }

    // setup pushstate
    function onURLChange(callback) {
      let currentURL = window.location.href;

      function handleURLChange() {
        let newURL = window.location.href;
        if (newURL !== currentURL) {
          currentURL = newURL;
          callback(currentURL);
        }
      }
      window.addEventListener("popstate", handleURLChange);
      pushstateActivation(handleURLChange);
    }

    // Wait for utag data in the basket
    function waitForProductAndPageAndSendEvent(product, page, event) {
      let count = 0;
      let maxCount = 100;
      const delay = 500;
      const phoneAndBasketInterval = setInterval(() => {
        if (
          window &&
          window.utag_data_copy.basket_contract_product_type &&
          window.utag_data_copy.basket_contract_product_type.includes(
            product
          ) &&
          window.utag_data_copy &&
          window.utag_data_copy.page_page_name.startsWith(page)
        ) {
          clearInterval(phoneAndBasketInterval);
          sendOptiEvent(event);
        }

        if (count > maxCount) {
          clearInterval(phoneAndBasketInterval);
        }
        count++;
      }, delay);
    }

    function urlChecks(url) {

      if (url.indexOf("https://www.o2.co.uk/shop/checkout/delivery") > -1) {
        console.log('CFU Delivery');
        waitForProductAndPageAndSendEvent(
          "paymonthly phones",
          "shop:cfu|checkout|delivery|address",
          "CFU PHONE DELIVERY"
        );
      }
      if (window.location.href.indexOf("https://www.o2.co.uk/shop/checkout/payment") > -1) {
        console.log('CFU Payment');
        waitForProductAndPageAndSendEvent(
          "paymonthly phones",
          "shop:cfu|checkout|payment",
          "CFU PHONE PAYMENT"
        );
      }
      if (window.location.href.indexOf("https://www.o2.co.uk/shop/checkout/confirmation") > -1) {
        console.log('CFU Order');
        waitForProductAndPageAndSendEvent(
          "paymonthly phones",
          "shop:cfu|checkout|confirmation",
          "CFU PHONE ORDER"
        );
      }
    }

    // Check for URL changes and run logic on certain pages
    onURLChange(function (newURL) {
      console.log("PHONE CFU URL changed to:", newURL);

      urlChecks(newURL);
    });

    // Run on initial
    const url = window.location.href;
    urlChecks(url);
  } catch (error) {
    console.log("error in pushstate event url detection: ", error);
  }
})();