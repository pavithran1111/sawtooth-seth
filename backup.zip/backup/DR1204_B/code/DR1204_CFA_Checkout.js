const url = window.location.href;
if(url.indexOf('https://www.o2.co.uk/shop/checkout/delivery') === -1 && url.indexOf('https://www.o2.co.uk/shop/checkout/payment') === -1 && url.indexOf('https://www.o2.co.uk/shop/checkout/confirmation') === -1) return;
let count = 0;
const maxCount = 50;
const interval = setInterval(() => {
  // Check for PHONE Product
  if(window && window.utag_data_copy && window.utag_data_copy.basket_contract_product_type) {
    const isPhone = window.utag_data_copy.basket_contract_product_type.includes("paymonthly phones") && (utag_data_copy.page_page_name.includes('shop:cfa|checkout|delivery|address') || utag_data_copy.page_page_name.includes('shop:cfa|checkout|payment') || utag_data_copy.page_page_name.includes('shop:cfa|checkout|confirmation') );
    if(isPhone) {
      activate();
      clearInterval(interval);
    }
  }
  count++;
  if(count > maxCount) {
     clearInterval(interval) ;
  }
}, 500);