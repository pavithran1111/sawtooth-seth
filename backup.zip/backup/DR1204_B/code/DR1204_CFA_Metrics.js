(() => {
  try {
    function sendOptiEvent(eventName) {
      console.log('eventName', eventName);
      window["optimizely"] = window["optimizely"] || [];
      window["optimizely"].push({
        type: "event",
        eventName: eventName,
      });
    }

    function pushstateActivation(callback) {
      // setup pushstate
      if (!window.isPushstateUrlDetectionOn) {
        window.isPushstateUrlDetectionOn = true;
        var oldPushState = window.history.pushState;

        window.history.pushState = function (data) {
          try {
            oldPushState.apply(this, arguments);
            const currUrl = window.location.href;
            console.log('push state activation');
            callback(currUrl);
          } catch (e) {
            console.log("error in pushstate event url detection: ", e);
          }
        };
      }
    }

    // setup pushstate
    function onURLChange(callback) {
      let currentURL = window.location.href;

      function handleURLChange() {
        let newURL = window.location.href;
        if (newURL !== currentURL) {
          currentURL = newURL;
          callback(currentURL);
        }
      }
      window.addEventListener("popstate", handleURLChange);
      pushstateActivation(handleURLChange);
    }

    // Wait for utag data in the basket
    function waitForProductAndPageAndSendEvent(product, page, event) {
      let count = 0;
      let maxCount = 100;
      const delay = 500;
      const phoneAndBasketInterval = setInterval(() => {
        if (
          window &&
          window.utag_data_copy.basket_contract_product_type &&
          window.utag_data_copy.basket_contract_product_type.includes(
            product
          ) &&
          window.utag_data_copy &&
          window.utag_data_copy.page_page_name.startsWith(page)
        ) {
          clearInterval(phoneAndBasketInterval);
          sendOptiEvent(event);
        }

        if (count > maxCount) {
          clearInterval(phoneAndBasketInterval);
        }
        count++;
      }, delay);
    }

    function urlChecks(url) {
      const pattern =
      /(https:\/\/www\.o2\.co\.uk\/shop)\/(apple|samsung|google|sony|oppo|nothing|motorola|nokia|xiaomi|doro)\/(\.*)/g;

      // Phone Listing Page
      if (url.indexOf("https://www.o2.co.uk/shop/phones") > -1) {
        // waitForProductAndPageAndSendEvent(
        //   "paymonthly phones",
        //   "shop:cfa|phones|paymonthly:devices|listing",
        //   "CFA PHONE LISTING"
        // );
        sendOptiEvent("CFA PHONE LISTING");
        console.log("phone listing page");
      }

      //Device Page      
      if (pattern.test(url)) {
        waitForProductAndPageAndSendEvent(
          "paymonthly phones",
          "shop:cfa|phones|devices|",
          "CFA PHONE PRODUCT"
        );
        console.log("phone product page");
      }
      if (url.indexOf("https://www.o2.co.uk/shop/device/configuration") > -1
      ) {
        //sendOptiEvent("CFA PHONE CONFIGURATION");
        waitForProductAndPageAndSendEvent(
          "paymonthly phones",
          "shop:cfa|phones|paymonthly|configuration",
          "CFA PHONE CONFIGURATION"
        );
        console.log("CFA configuration page");
      }
      // Basket Page
      if (url.indexOf("https://www.o2.co.uk/shop/basket") > -1) {
        waitForProductAndPageAndSendEvent(
          "paymonthly phones",
          "shop:cfa|basket",
          "CFA PHONE BASKET"
        );
        console.log("CFA basket page");
      }
      if (url.indexOf("https://www.o2.co.uk/shop/basket") > -1) {
        waitForProductAndPageAndSendEvent(
          "paymonthly phones",
          "shop:cfu|basket",
          "CFU PHONE BASKET"
        );
        console.log("CFA basket page");
      }
      if (url.indexOf("https://www.o2.co.uk/shop/checkout/delivery") > -1) {
        console.log('CFA Delivery');
        waitForProductAndPageAndSendEvent(
          "paymonthly phones",
          "shop:cfa|checkout|delivery|address",
          "CFA PHONE DELIVERY"
        );
      }
      if (window.location.href.indexOf("https://www.o2.co.uk/shop/checkout/payment") > -1) {
        console.log('CFA Payment');
        waitForProductAndPageAndSendEvent(
          "paymonthly phones",
          "shop:cfa|checkout|payment",
          "CFA PHONE PAYMENT"
        );
      }
      if (window.location.href.indexOf("https://www.o2.co.uk/shop/checkout/confirmation") > -1) {
        console.log('CFA Order');
        waitForProductAndPageAndSendEvent(
          "paymonthly phones",
          "shop:cfa|checkout|confirmation",
          "CFA PHONE ORDER"
        );
      }
    }

    // Check for URL changes and run logic on certain pages
    onURLChange(function (newURL) {
      console.log("URL changed to:", newURL);

      urlChecks(newURL);
    });

    // Run on initial
    const url = window.location.href;
    urlChecks(url);
  } catch (error) {
    console.log("error in pushstate event url detection: ", error);
  }
})();