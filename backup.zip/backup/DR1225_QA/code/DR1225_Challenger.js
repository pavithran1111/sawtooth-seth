console.log("VMO2AB_DR1225 Version2");
(function () {
    function poll(conditionFn, successCallback, errorCallback, timeout = 15000, interval = 500) {
        const endTime = Number(new Date()) + timeout;

        (function checkCondition() {
            if (conditionFn()) {
                successCallback();
            } else if (Number(new Date()) < endTime) {
                setTimeout(checkCondition, interval);
            } else {
                errorCallback(new Error('Timed out'));
            }
        })();
    }

    poll(
        function () {
            return typeof jQuery === "function" && typeof $ === "function" && ($('body').find('.start-saving-banner__content').length || $('body').find('o2uk-commercial-tariff-card').length) && !$('body').hasClass('DR1225').length;
            //condition to check the element is loaded in DOM or not; along with the statement ---> !$('body').hasClass('DR1225').length 
        },
        function () {
            executeExperience();
        },
        function (err) {
            console.error("Error: ", err);
        },
        40000
    );

    function executeExperience() {
        console.log("Executed DR1225");
        $('body').addClass('DR1225');

        // Code to execute on My O2 Page
        $('body').find('.start-saving-banner__content .start-saving-banner__content-header').html(`40GB for £12, just for you<sup class="o2uk-price__amount-decimal-footnote o2uk-price__amount-decimal-footnote_small ng-star-inserted"><a footnotelink="" tabindex="0" href="#rpi-footnote" id="c35c858f-7e59-4ce8-a513-8d138e8e7e5e" aria-label="See footnote below for conditions" style="color: #fff;">†</a></sup>`);
        $('body').find('.start-saving-banner__content p').text('Bag yours for 12 months when you buy an additional SIM Only connection.');
        $('body').find('.start-saving-banner__content .o2uk-link-text').text('Get this deal');
        $('body').find('.start-saving-banner__content .o2uk-link__container').wrap('<a href="https://www.o2.co.uk/shop/alreadywitho2?plan-offering-id=2024SOHA12P1.02%3A40GB%3A1" class="DR1225-account-page-link"></a>');
        $('body').find('.start-saving-banner__content a.o2uk-link').css('pointer-events', 'none');



        // Code to execute on SIMO Page

        let newTariffTile1225 = `<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 _margin_bottom-l _margin_top-xs _margin_top-xl ng-star-inserted newTariffTileCont1225">
    <o2uk-commercial-tariff-card class="tariff-card newTariffTile1225">
        <div class="tariff-card__roof">
            <div class="tariff-card__roof-inner ng-star-inserted"><o2uk-svg-resolver role="row"
                    classlist="tariff-card__roof-icon o2uk-svg_size_m"
                    class="svg-resolver o2uk-svg o2uk-svg_size_m ng-star-inserted" aria-hidden="true">
                    <div class="tariff-card__roof-icon o2uk-svg_size_m"><span
                            class="o2uk-icon-font icon-rewards-ribbon"></span></div>
                    <title></title>
                </o2uk-svg-resolver>
                <p class="tariff-card__roof-inner-text ng-star-inserted">Just for you</p>
            </div>
        </div>
        <div class="tariff-card__label tariff-card__label_color font font_bold"
            style="background-color: rgb(243, 243, 245); color: rgb(0, 80, 255);"> CLASSIC
        </div>
        <div class="tariff-card__container">
            <div class="tariff-card__wrapper"><o2uk-data class="tariff-card__data text _centered">
                    <h2 class="ng-star-inserted">
                        <h2 aria-hidden="true" class="font_bold _padding_bottom-xs ng-star-inserted tariffValueDR1225"> 40GB </h2><span
                            aria-hidden="true" class="text _small font font_regular ng-star-inserted tariffDescDR1225"> DATA </span><span
                            class="sr-only ng-star-inserted"> 40GB, DATA tariff </span>
                    </h2>
                    <div class="_margin_top-m _margin_bottom-m ng-star-inserted">
                        <p class="tariff-card__info_text text _standard"> 12 Month Airtime Plan</p>
                        <p class="text _standard">Unlimited UK Minutes &amp; Texts</p>
                    </div>
                </o2uk-data><o2uk-tariff-card-promo-block class="tariff-card-promo-block"><o2uk-card-title
                        class="o2uk-card-title _margin_bottom-m ng-star-inserted">
                        <hr role="presentation" aria-hidden="true" class="o2uk-card-title__line">
                        <div o2ukmultilineellipsis="" class="o2uk-card-title__text ng-star-inserted"><span
                                class="sr-only ng-star-inserted">Offers included</span><multi-line-ellipsis
                                role="presentation" aria-hidden="true" class="ng-star-inserted">
                                <div class="ng-star-inserted">
                                    <div class="multi-line-ellipsis" title="Offers included"
                                        style="word-break: initial;">Offers included</div>
                                </div>
                            </multi-line-ellipsis></div>
                    </o2uk-card-title>
                    <div class="tariff-promos__wrapper _margin_top-s ng-star-inserted">
                        <div class="tariff-promos__offer ng-star-inserted voltOfferStrip1225">
                            <div class="tariff-promos__offer-icon tariff-promos__offer-icon_medium"><img loading="lazy"
                                    role="presentation" aria-hidden="true"
                                    src="https://econtent.o2.co.uk/o/econtent/media/get/9116464b-62a8-4414-94ca-9d209b3e0a96"
                                    class="ng-star-inserted"></div>
                            <div class="tariff-promos__offer-wrapper">
                                <p class="tariff-promos__offer-info">Get double data when your household also has Virgin
                                    Media broadband.</p><o2uk-link svgid="icon-info-roundel"
                                    wrapperclass="tariff-promos__wrapper-button" svgclass="o2uk-link-svg_no_margin"
                                    class="o2uk-link__container ng-star-inserted"><button type="button"
                                        class="o2uk-link o2uk-link-svg_margin_right o2uk-link-svg_right o2uk-link_size_large tariff-promos__wrapper-button ng-star-inserted getDoubleData1225"
                                        aria-label="Show offer info" aria-haspopup="dialog"><o2uk-svg-resolver
                                            role="row"
                                            class="o2uk-link-svg o2uk-link-svg_l o2uk-link-svg_no_margin ng-star-inserted"
                                            aria-hidden="true">
                                            <div class="o2uk-link-svg o2uk-link-svg_l"><span
                                                    class="o2uk-icon-font icon-info-roundel"></span></div>
                                            <title></title>
                                        </o2uk-svg-resolver></button></o2uk-link>
                            </div>
                        </div>
                        <div class="tariff-promos__offer ng-star-inserted">
                            <div class="tariff-promos__offer-icon tariff-promos__offer-icon_medium"><img loading="lazy"
                                    role="presentation" aria-hidden="true"
                                    src="https://econtent.o2.co.uk/o/econtent/media/get/92465c20-a256-48ba-8da6-e0431c14eb59"
                                    class="ng-star-inserted"></div>
                            <div class="tariff-promos__offer-wrapper">
                                <p class="tariff-promos__offer-info">Roam freely in the EU. Only on O2. Up to 25GB.</p>
                                <o2uk-link svgid="icon-info-roundel" wrapperclass="tariff-promos__wrapper-button"
                                    svgclass="o2uk-link-svg_no_margin"
                                    class="o2uk-link__container ng-star-inserted"><button type="button"
                                        class="o2uk-link o2uk-link-svg_margin_right o2uk-link-svg_right o2uk-link_size_large tariff-promos__wrapper-button ng-star-inserted roamFreelyEU1225"
                                        aria-label="Show offer info" aria-haspopup="dialog"><o2uk-svg-resolver
                                            role="row"
                                            class="o2uk-link-svg o2uk-link-svg_l o2uk-link-svg_no_margin ng-star-inserted"
                                            aria-hidden="true">
                                            <div class="o2uk-link-svg o2uk-link-svg_l"><span
                                                    class="o2uk-icon-font icon-info-roundel"></span></div>
                                            <title></title>
                                        </o2uk-svg-resolver></button></o2uk-link>
                            </div>
                        </div>
                        <div class="tariff-promos__offer ng-star-inserted">
                            <div class="tariff-promos__offer-icon tariff-promos__offer-icon_medium"><img loading="lazy"
                                    role="presentation" aria-hidden="true"
                                    src="https://econtent.o2.co.uk/o/econtent/media/get/42b54310-efa1-41dc-8ffe-94df80564674"
                                    class="ng-star-inserted"></div>
                            <div class="tariff-promos__offer-wrapper">
                                <p class="tariff-promos__offer-info">Choose 3 months of Disney+ Standard, Amazon Prime,
                                    or more.</p><o2uk-link svgid="icon-info-roundel"
                                    wrapperclass="tariff-promos__wrapper-button" svgclass="o2uk-link-svg_no_margin"
                                    class="o2uk-link__container ng-star-inserted"><button type="button"
                                        class="o2uk-link o2uk-link-svg_margin_right o2uk-link-svg_right o2uk-link_size_large tariff-promos__wrapper-button ng-star-inserted chooseDisEU1225"
                                        aria-label="Show offer info" aria-haspopup="dialog"><o2uk-svg-resolver
                                            role="row"
                                            class="o2uk-link-svg o2uk-link-svg_l o2uk-link-svg_no_margin ng-star-inserted"
                                            aria-hidden="true">
                                            <div class="o2uk-link-svg o2uk-link-svg_l"><span
                                                    class="o2uk-icon-font icon-info-roundel"></span></div>
                                            <title></title>
                                        </o2uk-svg-resolver></button></o2uk-link>
                            </div>
                        </div>
                    </div>
                </o2uk-tariff-card-promo-block>
                <hr role="presentation" aria-hidden="true" class="divider _margin_top-s">
                <div class="tariff-card__info-content _margin_top-s"><o2uk-commercial-tariff-card-price-block
                        class="commercial-tariff-card__price-block">
                        <div class="commercial-tariff-card__price-wrapper_base ng-star-inserted"><o2uk-price-new
                                class="o2uk-price ng-star-inserted">
                                <div class="o2uk-price__amount ng-star-inserted"><span class="sr-only ng-star-inserted">
                                        £12.00† monthly </span>
                                    <div aria-hidden="true" role="presentation" class="o2uk-price__amount-sign"> £
                                    </div>
                                    <div aria-hidden="true" role="presentation" class="o2uk-price__amount-integer"> 12
                                    </div>
                                    <div class="o2uk-price__amount-decimal o2uk-price__amount-decimal_medium"><span aria-hidden="true" role="presentation" class="font font_light"> .00
                                        </span><sup class="o2uk-price__amount-decimal-footnote ng-star-inserted"><a footnotelink="" tabindex="0" href="#rpi-footnote"
                                                id="2060dcc8-5f64-4c86-ad63-b0fe22988713"
                                                aria-label="See footnote below for conditions"> †
                                            </a></sup></div>
                                </div>
                                <div aria-hidden="true" role="presentation"
                                    class="o2uk-price__hint o2uk-price__hint_uppercase ng-star-inserted">Monthly</div>

                            </o2uk-price-new></div><o2uk-link svgid="icon-info-roundel"
                            class="commercial-tariff-card__info-text o2uk-link__container ng-star-inserted">
                            <button type="button" class="commercial-tariff-card__info-text-wrapper o2uk-link o2uk-link_size_large ng-star-inserted" aria-label="Plan details for 40GB" aria-haspopup="dialog"><o2uk-svg-resolver role="row" class="o2uk-link-svg o2uk-link-svg_l o2uk-link-svg_margin_left ng-star-inserted" aria-hidden="true"> <div class="o2uk-link-svg o2uk-link-svg_l"><span class="o2uk-icon-font icon-info-roundel"></span></div> <title></title> </o2uk-svg-resolver><span class="ng-star-inserted"><span class="o2uk-link-text o2uk-link_size_bold ng-star-inserted">Price rises each
                                        April<sup>†</sup><br>See plan
                                        information</span></span></button></o2uk-link>
                    </o2uk-commercial-tariff-card-price-block>
                    <a class ="add-to-basket-button-1225" href="https://www.o2.co.uk/shop/alreadywitho2?plan-offering-id=2024SOHA12P1.02%3A40GB%3A1">
                    <button type="button" role="button" o2uk-primary-button=""
                        autotest-target="sim-add-to-basket-at-id"
                        class="mat-focus-indicator tariff-card__add-button mat-button-base o2uk-primary-button ng-star-inserted"
                        aria-label="Choose this plan 40GB" aria-haspopup="dialog"><span
                            class="mat-button-wrapper"> Choose this plan </span>
                        <div matripple="" aria-hidden="true" class="mat-ripple mat-button-ripple"></div>
                        <div aria-hidden="true" class="mat-button-focus-overlay"></div>
                    </button>
                    </a>
                </div>
            </div>
        </div>
    </o2uk-commercial-tariff-card>
</div>`;



        $('body').find('.newTariffTile1225').length < 1 ? $('body').find('tariff-cards-wrapper > o2uk-plan-list-wrapper > div > div > div:nth-child(1)').before(newTariffTile1225) : 0;

        $(document).off('mousedown').on('mousedown', '.getDoubleData1225', function () {
            $('body').find('.tariff-promos__offer-wrapper:contains(Get double data when your household) .tariff-promos__wrapper-button').eq(1).click();
        })
        $(document).on('mousedown', '.roamFreelyEU1225', function () {
            $('body').find('.tariff-promos__offer-wrapper:contains(Roam freely in the EU) .tariff-promos__wrapper-button').eq(1).click();
        })
        $(document).on('mousedown', '.chooseDisEU1225', function () {
            if ($('body').find('.tariff-promos__offer-wrapper:contains(Choose 3 months of Disney+ Standard, Amazon Prime, or more.) .tariff-promos__wrapper-button').lengh) {
                $('body').find('.tariff-promos__offer-wrapper:contains(Choose 3 months of Disney+ Standard, Amazon Prime, or more.) .tariff-promos__wrapper-button').eq(1).click();
            } else {
                $('body').find('.o2uk-inline-accordion__text:contains(See all offers)').click();
                $('body').find('.tariff-promos__offer-wrapper:contains(Choose 3 months of Disney+ Standard, Amazon Prime, or more.) .tariff-promos__wrapper-button').eq(1).click();

            }
        })

        $(document).on('mousedown', '.newTariffTile1225 .commercial-tariff-card__info-text', function () {
            $('body').find('.commercial-tariff-card__info-text button').eq(1).click();
        });

        $(document).on('mousedown', '.DR1225 .o2uk-dialog-title__button ', function () {
            $('body').find('.o2uk-inline-accordion__text:contains(Hide offers)').click();
        });

        $(document).on('mousedown', '.newTariffTile1225 .tariff-card__add-button', function () {
            window['optimizely'] = window['optimizely'] || [];
            window['optimizely'].push({
                type: "event",
                eventName: "DR1225-Click Event-Choose this plan",
            });
        });


        $(document).on('mousedown', '.DR1225 .o2uk-contract-length__panel o2uk-radio-button', function () {
            if ($(this).find('.mat-radio-label-content').text().includes('12 Month') || $(this).find('.mat-radio-label-content').text().includes('Featured')) {
                $('body').find('.newTariffTileCont1225').show();
            }
            else {
                $('body').find('.newTariffTileCont1225').hide();
            }
        });

        // Handelling the tile aapearance on the filter buttons
        $(document).on('mousedown', '.DR1225 .o2uk-filter__content .o2uk-checkbox, .DR1225 .o2uk-sort-and-filter__condition .o2uk-chips__item', function () {
            setTimeout(() => {
                if ($('body').find('.o2uk-sort-and-filter__condition .o2uk-chips__item').length > 0) {
                    var itemWith30GB = false;
                    var itemWithUltimatePlans = false;
                    var itemWith30DayOr24Month = false;

                    $('body').find('.o2uk-sort-and-filter__condition .o2uk-chips__item').each(function (index, item) {
                        var ariaLabel = $(item).attr('aria-label');
                        if (ariaLabel) {
                            if (ariaLabel.includes('30GB')) {
                                itemWith30GB = true;
                            }
                            if (ariaLabel.includes('Ultimate Plans')) {
                                itemWithUltimatePlans = true;
                            }
                            if (ariaLabel.includes('30 Day') || ariaLabel.includes('24 Month')) {
                                itemWith30DayOr24Month = true;
                            }
                        }
                    });

                    if (itemWithUltimatePlans || itemWith30DayOr24Month) {
                        $('body').find('.newTariffTileCont1225').hide();
                    } else if (itemWith30GB) {
                        $('body').find('.newTariffTileCont1225').show();
                    } else {
                        $('body').find('.newTariffTileCont1225').hide();
                    }
                }
                else {
                    $('body').find('.newTariffTileCont1225').show();
                }
            }, 2000);
        });

        // Volt banner adjustments

        $('body').find('.volt-notification-card__card').length > 0 ? $('body').find('.newTariffTile1225 .voltOfferStrip1225').hide() : $('body').find('.voltOfferStrip1225').show(); // Hiding the volt strip if the Volt banner in the top is present

        // Double the data when Volt toggle is on
        let lookForVoltBannerCounter = 0;
        let lookForVoltBanner = setInterval(function () {

            if ($('body').find('.volt-notification-card__toggle').length > 0) {
                if ($('body').find('.volt-notification-card__toggle').hasClass('mat-checked')) {
                    $('body').find('.tariffValueDR1225').addClass('_pink');
                    $('body').find('.tariffValueDR1225').html('80GB');
                    $('body').find('.tariffDescDR1225').removeClass('font_regular').addClass('_pink font_bold');
                    $('body').find('.tariffDescDR1225').html('DATA BOOSTED FROM 40GB Plus');
                    $('body').find('.newTariffTile1225 .o2uk-price__amount').addClass('o2uk-price_discount');
                }
                else {
                    $('body').find('.tariffValueDR1225').removeClass('_pink');
                    $('body').find('.tariffDescDR1225').addClass('font_regular').removeClass('_pink font_bold');
                    $('body').find('.tariffValueDR1225').html('40GB');
                    $('body').find('.tariffDescDR1225').html('DATA');
                    $('body').find('.newTariffTile1225 .o2uk-price__amount').removeClass('o2uk-price_discount');

                }
                clearInterval(lookForVoltBanner);
            } else if (++lookForVoltBannerCounter > 200) {
                clearInterval(lookForVoltBanner);
            }
        }, 500);


        // $(document).on('mousedown', '.DR1225 o2uk-volt-notification-card o2uk-toggle-button', function () {
        //     console.log('Toggle clicked 1225');
        //     // setTimeout(() => {
        //         if ($(this).hasClass('mat-checked')) {
        //             $('body').find('.tariffValueDR1225').addClass('_pink');
        //             $('body').find('.tariffValueDR1225').html('80GB');
        //             $('body').find('.tariffDescDR1225').removeClass('font_regular').addClass('_pink font_bold');
        //             $('body').find('.tariffDescDR1225').html('DATA BOOSTED FROM 40GB Plus');
        //             $('body').find('.newTariffTile1225 .o2uk-price__amount').addClass('o2uk-price_discount');
        //         }
        //         else {
        //             $('body').find('.tariffValueDR1225').removeClass('_pink');
        //             $('body').find('.tariffValueDR1225').html('40GB');
        //             $('body').find('.tariffDescDR1225').removeClass('_pink font_bold').addClass('font_regular');
        //             $('body').find('.tariffDescDR1225').html('DATA');
        //             $('body').find('.newTariffTile1225 .o2uk-price__amount').removeClass('o2uk-price_discount');

        //         }
        //     // }, 100);
        // });

        $(document).on('mousedown', '.DR1225 o2uk-volt-notification-card o2uk-toggle-button', function () {
            console.log('Toggle clicked 1225');
            let count1225 = 0;
            let intervalId1225 = setInterval(() => {
                count1225++;
                if ($('.tariff-card__data h2').hasClass('_pink')) {
                    if ($(this).hasClass('mat-checked')) {
                        console.log('If------- asas', $(this).hasClass('mat-checked'));

                        $('body').find('.tariffValueDR1225').addClass('_pink');
                        $('body').find('.tariffValueDR1225').html('80GB');
                        $('body').find('.tariffDescDR1225').removeClass('font_regular').addClass('_pink font_bold');
                        $('body').find('.tariffDescDR1225').html('DATA BOOSTED FROM 40GB Plus');
                        $('body').find('.newTariffTile1225 .o2uk-price__amount').addClass('o2uk-price_discount');
                    } else {
                        console.log('Else------- asas', $(this).hasClass('mat-checked'));

                        $('body').find('.tariffValueDR1225').removeClass('_pink');
                        $('body').find('.tariffValueDR1225').html('40GB');
                        $('body').find('.tariffDescDR1225').removeClass('_pink font_bold').addClass('font_regular');
                        $('body').find('.tariffDescDR1225').html('DATA');
                        $('body').find('.newTariffTile1225 .o2uk-price__amount').removeClass('o2uk-price_discount');
                        
                    }
                    clearInterval(intervalId1225);
                }
                else if (++count1225 > 200) {
                    clearInterval(intervalId1225);
                }
            }, 100);
        });


        $(document).on('mousedown', '.DR1225 o2uk-device-plan-tab .o2uk-tabs__tab', function () {
            if ($(this).attr('aria-label') !== 'Phones') {
                $('body').find('.newTariffTileCont1225').hide();
            } else {
                $('body').find('.newTariffTileCont1225').show();
            }
        });

        $(document).on('mousedown', '.DR1225 .start-saving-banner__content .DR1225-account-page-link', function () {
            window['optimizely'] = window['optimizely'] || [];
            window['optimizely'].push({
                type: "event",
                eventName: "DR1225-Click Event-Account Page",
            });
        });
    }
})();