console.log("VMO2AB_DR1224Version2 shared code");
(function () {

  function poll(fn, callback, errback, timeout, interval) {
    let endTime = Number(new Date()) + (timeout || 2000);
    interval = 1000;
    (function p() {
      // If the condition is met, we're done! 
      if (fn()) {
        callback();
      }
      // If the condition isn't met but the timeout hasn't elapsed, go again
      else if (Number(new Date()) < endTime) {
        setTimeout(p, interval);
      }
      // Didn't match and too much time, reject!
      else {
        errback(new Error('timed out for ' + fn + ': ' + arguments));
      }
    })();
  }
  poll(
    function () {
      return typeof jQuery == "function" && typeof $ == "function" && typeof window.optimizely !== "undefined" && ($("body").find('.globalNav').length > 0 || $("body").find('.global-header__main').length > 0);
    },
    function () {
      // Done, success callback
        executeExprience();
    },
    function (err) {
      // Error, failure callback
      console.log("error: ", err);
    },
    40000
  );

  function executeExprience() {
  if (window.optimizely && window.optimizely.get) {
    let utils = window.optimizely.get("utils");
    console.log('Optiizely should started');
    deactivateChallenger('DR1224_basket_remainder');
    // Check if observeSelector method is available in the utils object
    if (utils && utils.observeSelector) {
      const selector = $('.globalNavlinksWrapper').length >0 ? '.globalNavlinksWrapper': 'div[role="navigation"].o2uk-container.global-header__breadcrumb-wrapper.ng-star-inserted o2uk-breadcrumbs';
      //const selector = $('.globalNavlinksWrapper').length >0 ? '.globalNavlinksWrapper': '.o2uk-logo__wrapper .global-header__logo';
      // const selector = $('.globalNavlinksWrapper').length >0 ? '.globalNavlinksWrapper': '.o2uk-header-curve__text-title';
      utils.observeSelector(
          `${selector}`,
          function () {
            console.log('ttt observer', selector);
            if (window.location.href.startsWith('https://www.o2.co.uk/shop') && $('.DR1224-modal').length == 0) {
              console.log('ttt Fire the Dialog box');
              visitingPage();
            }            
            if(window.location.href.includes('https://www.o2.co.uk/shop/basket')){
              captureBasketPage();
            }
          }, {
            "timeout": 500,
            "once": true,
            "onTimeout": function() {
              console.log("Stopped observing");
            }}
        );
    } else {
        console.error("observeSelector method is not available in utils object.");
    }
  } else {
      console.error("utils or utag_obj is not available in the window object.");
  }
  }

  function captureBasketPage() {
    console.log('ttt captureBasketPage', window.sessionStorage.getItem('DR1224_count'));
    console.log('ttt page overlay', window.sessionStorage.getItem('DR1224_overlay'));
    let count = 0;
    const interval = setInterval(()=>{

      let deviceName = $('body').find('.device-info__brand-name').text().trim().includes('Apple iPhone')?true: utag_data.basket_contract_product_type.includes('paymonthly phones')
      console.log('ttt deviceName', deviceName);
      if(($('.o2uk-buble-loader_fade-out').length>0 || $('.globalNav').length>0) && window.location.href.includes('https://www.o2.co.uk/shop/basket') && window.sessionStorage.getItem('DR1224_count') ==null && $('.o2uk-header-curve__text-title:not(:contains("empty"))').length>0 && deviceName ) {
        window.sessionStorage.setItem('DR1224_count', 0);
        console.log('ttt initialized')
        clearInterval(interval);
      }
      else if(++count>100){
        clearInterval(interval);
      }
    }, 300);
  }

  function visitingPage() {
    let count = 0;
    const interval = setInterval(()=>{
      if(($('.o2uk-buble-loader_fade-out').length>0 || $('.globalNav').length>0) && !window.location.href.includes('https://www.o2.co.uk/shop/basket') && window.sessionStorage.getItem('DR1224_count') !==null && window.sessionStorage.getItem('DR1224_overlay') == null){
        clearInterval(interval);
        let pageCount = parseInt(window.sessionStorage.getItem('DR1224_count')); 
        window.sessionStorage.setItem('DR1224_count', pageCount+1);

        if(window.sessionStorage.getItem('DR1224_count')>=3){
          setTimeout(()=>{
            console.log('ttt appendOverlay');
            fireChallenger('DR1224_basket_remainder');
          }, 2500);
        }
        console.log('ttt DR1224 count', window.sessionStorage.getItem('DR1224_count'), 'count', count);
      }
      else if(++count>100){
        clearInterval(interval);
      }
    }, 300);
  }

  function deactivateChallenger(pageName){
    console.log("ttt Disable page event remainder", pageName);
    window.optimizely = window.optimizely || [];
    window.optimizely.push({
      type: "page",
      pageName: pageName,
      isActive: false
    });
  }

  function fireChallenger(pageName){
    console.log("ttt Enable page event remainder", pageName);
    window.optimizely = window.optimizely || [];
    window.optimizely.push({
      type: "page",
      pageName: pageName,
    });
  }

})();