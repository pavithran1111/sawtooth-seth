console.log('Sample URL DR1224 change test - test');

(function () {
  "use strict";
  const handleError = (experimentId, storyNumber, error) => {
    console.log(`${storyNumber} Error: ${error}`);
    document.documentElement.classList.add(`${storyNumber}-error`);
  }
  const contentPagesPolling = (subjectsSelectors, experimentID, storyNumber, callback) => {
    let count = 0;
    const maxCalls = 50, delay = 500;
    const pollingInterval = setInterval(() => {
      try {
        let elementsYetToLoadArray = subjectsSelectors.filter(selector => 0 === document.querySelectorAll(selector).length),
          angularLoaded = window.getAllAngularRootElements,
          optimizelyWindow = window.optimizely,
          $ = window.$;
        if (0 === elementsYetToLoadArray.length && "function" === typeof angularLoaded && $ && optimizelyWindow) {
          clearInterval(pollingInterval);
          callback($);
        }
        if (count > maxCalls) clearInterval(pollingInterval);
        count++;
      } catch (error) {
        handleError(experimentID, storyNumber, error);
      }
    }, delay);
  }
  const storyNumber = "remainder", experimentId = "DR1224";
  const subjectsSelectors = ["body"];

  contentPagesPolling(subjectsSelectors, experimentId, storyNumber, $ => {
    try {
      document.documentElement.classList.add(storyNumber);
      console.log('first 111')
      const makeChanges = () => {
        $(".global-header__upper").addClass("o2uk-changed");
        console.log('testing 111')
        $(".global-header__upper-tab:contains('Personal')").text("Test 111");
      }

      makeChanges();

      const observer = new MutationObserver(function (mutations) {
        if (!$(".global-header__upper").hasClass("o2uk-changed")) {
          console.log("doesn't have class - repeat changes");
          makeChanges();
        }

      });
      const config = { subtree: true, childList: true };
      observer.observe(document, config);



    } catch (error) {
      handleError(experimentId, storyNumber, error);
    }
  });
})();