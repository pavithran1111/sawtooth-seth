console.log("VMO2AB_DR1224Version2 Challenger");
(function () {

  function poll(fn, callback, errback, timeout, interval) {
    let endTime = Number(new Date()) + (timeout || 2000);
    interval = 1000;
    (function p() {
      // If the condition is met, we're done! 
      if (fn()) {
        callback();
      }
      // If the condition isn't met but the timeout hasn't elapsed, go again
      else if (Number(new Date()) < endTime) {
        setTimeout(p, interval);
      }
      // Didn't match and too much time, reject!
      else {
        errback(new Error('timed out for ' + fn + ': ' + arguments));
      }
    })();
  }
  poll(
    function () {
      return typeof jQuery == "function" && typeof $ == "function" && typeof window.optimizely !== "undefined" && ($("body").find('.globalNav').length > 0 || $("body").find('.global-header__main').length > 0);
    },
    function () {
      // Done, success callback
        executeExprience();
    },
    function (err) {
      // Error, failure callback
      console.log("error: ", err);
    },
    40000
  );

  function executeExprience() {
    //console.log('ttt first')
    //console.log('ttt first ', $('.o2uk-buble-loader_fade-out').length, 'gg', $('.globalNav').length)

    $(document).on('click', '.DR1224-overlay .DR1224-button', function () {
      closeDialogBox();
      sendEventDR1224('dr1224_expb_view_basket');
      gtag('event', 'optimizely_campaign', {
        'optimizely_event_name': 'click',
        'optimizely_event_value': `DR1224 ExpB View basket`
      });
    });

    $(document).on('click', '.DR1224-overlay .DR1224-close', function () {

      closeDialogBox();
      sendEventDR1224('dr1224_expb_close_dialog_box');
      gtag('event', 'optimizely_campaign', {
        'optimizely_event_name': 'click',
        'optimizely_event_value': `DR1224 ExpB Close Dialog Box`
      });
    });

    if (window.optimizely && window.optimizely.get) {
      let utils = window.optimizely.get("utils");
      // console.log('Optiizely should started');
      // Check if observeSelector method is available in the utils object
      if (utils && utils.observeSelector) {

        const selector = $('.globalNavlinksWrapper').length >0 ? '.globalNavlinksWrapper': 'div[role="navigation"].o2uk-container.global-header__breadcrumb-wrapper.ng-star-inserted o2uk-breadcrumbs';
        utils.observeSelector(
          `${selector}`,
          function () {
            //console.log('ttt observer');
            if (window.location.href.startsWith('https://www.o2.co.uk/shop') && $('.DR1224-modal').length == 0 && !window.location.href.includes('https://www.o2.co.uk/shop/basket') && window.sessionStorage.getItem('DR1224_overlay') == null) {
              //console.log('ttt Fire the Dialog box');
              //visitingPage();
                appendOverlay();
            }
            //captureBasketPage();
          },
          {
            once: false,
          }
        );
      } else {
          console.error("observeSelector method is not available in utils object.");
      }
    } else {
        console.error("utils or utag_obj is not available in the window object.");
    }
  }

  function sendEventDR1224(eventName) {
    // console.log('DR1224 Exp', eventName)
    window["optimizely"] = window["optimizely"] || [];
    window["optimizely"].push({
      type: "event",
      eventName: eventName,
    });
  }

  function closeDialogBox(){
    deactivatePage('DR1224_basket_remainder');
    $('.DR1224-modal-content').addClass('close-overlay');
    let count = 0;
    const interval = setInterval(()=>{
      if(count > 0){
        clearInterval(interval);
        $(".DR1224-overlay").remove();
        $('html').css('overflow-y', 'scroll');
      }
      else if(++count>100){
        clearInterval(interval);
      }
    }, 200);
  }

  /*function captureBasketPage() {
    let count = 0;
    const interval = setInterval(()=>{
      if(($('.o2uk-buble-loader_fade-out').length>0 || $('.globalNav').length>0) && window.location.href.includes('https://www.o2.co.uk/shop/basket') && window.sessionStorage.getItem('DR1224_count') ==null && $('.o2uk-header-curve__text-title:not(:contains("empty"))').length>0 && utag_data && utag_data.basket_contract_product_type.includes('paymonthly phones')){
        window.sessionStorage.setItem('DR1224_count', 0);
        clearInterval(interval);
      }
      else if(++count>100){
        clearInterval(interval);
      }
    }, 300);
  }

  function visitingPage() {
    const pageCount1 = window.sessionStorage.getItem('DR1224_count');
    let count = 0;
    const interval = setInterval(()=>{
      if(($('.o2uk-buble-loader_fade-out').length>0 || $('.globalNav').length>0) && !window.location.href.includes('https://www.o2.co.uk/shop/basket') && window.sessionStorage.getItem('DR1224_count') !==null && window.sessionStorage.getItem('DR1224_overlay') == null){
        clearInterval(interval);
        let pageCount = parseInt(window.sessionStorage.getItem('DR1224_count')); 
        window.sessionStorage.setItem('DR1224_count', pageCount+1);

        if(window.sessionStorage.getItem('DR1224_count')>=3){
          setTimeout(()=>{
            appendOverlay();
          }, 2500);
        }
      }
      else if(++count>100){
        clearInterval(interval);
      }
    }, 300);
  }*/

  function appendOverlay() {
    const overlayModal = `<div id="myModal" class="DR1224-overlay DR1224-modal"><div class="DR1224-modal-content"><div class="DR1224-modal-header"><span class="DR1224-close">&times;</span><h2>Hey, you left something behind</h2></div><div class="DR1224-modal-body"><p>Complete your purchase now and get free next working day delivery.</p></div><div class="DR1224-modal-footer"><p class="DR1224-button"><a href="https://www.o2.co.uk/shop/basket" type="button" role="button" class="mat-focus-indicator mat-button-base o2uk-primary-button ng-star-inserted" aria-label="View your basket"><span class="mat-button-wrapper">View your basket</span><div aria-hidden="true" class="mat-ripple mat-button-ripple"></div><div aria-hidden="true" class="mat-button-focus-overlay"></div></a></p></div></div></div>`;
    $('body').append(overlayModal);
    window.sessionStorage.setItem('DR1224_overlay', 'done');
    $(".DR1224-overlay").show();
    $('html').css('overflow-y', 'hidden');
  }

  function deactivatePage(pageName){
    window.optimizely = window.optimizely || [];
    window.optimizely.push({
      type: "page",
      pageName: pageName,
      isActive: false
    });
  }
})();