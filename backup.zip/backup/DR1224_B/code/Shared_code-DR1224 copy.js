console.log("Basket Remainder activity");
(() => {
  try {
    function sendProductPage(eventName) {
      console.log("Enable page event", eventName);
      window["optimizely"] = window["optimizely"] || [];
      window["optimizely"].push({
        type: "page",
        pageName: eventName,
      });     
    }

    function deactivatePageEvent(eventName) {
      console.log("Disable page event", eventName);
      window["optimizely"] = window["optimizely"] || [];
      window["optimizely"].push({
        type: "page",
        pageName: eventName,
        isActive: false
      });     
    }

    function pushstateActivation(callback) {
      // setup pushstate
      if (!window.isPushstateUrlDetectionOn) {
        window.isPushstateUrlDetectionOn = true;
        var oldPushState = window.history.pushState;

        window.history.pushState = function (data) {
          try {
            oldPushState.apply(this, arguments);
            const currUrl = window.location.href;

            callback(currUrl);
          } catch (e) {
            console.log("error in pushstate event url detection: ", e);
          }
        };
      }
    }

    // setup pushstate
    function onURLChange(callback) {
      let currentURL = window.location.href;

      function handleURLChange() {
        let newURL = window.location.href;
        if (newURL !== currentURL) {
          currentURL = newURL;
          callback(currentURL);
        }
      }

      window.addEventListener("popstate", handleURLChange);
      pushstateActivation(handleURLChange);
    }

    function urlChecks(url) {
      if ( url.startsWith('https://www.o2.co.uk/shop') && !window.location.href.includes('https://www.o2.co.uk/shop/checkout/delivery') ) {

        sendProductPage("24104221017_url_targeting_for_ab_dr1224_basket_reminder");
      }
      else {
        deactivatePageEvent('24104221017_url_targeting_for_ab_dr1224_basket_reminder');
      }
    }

    // Check for URL changes and run logic on certain pages
    onURLChange(function (newURL) {
      console.log("URL remainder changed to:", newURL);
      urlChecks(newURL);
    });

    // Run on initial
    const url = window.location.href;
    urlChecks(url);
  } catch (error) {
    console.log("error in pushstate event url detection:  ", error);
  }
})();