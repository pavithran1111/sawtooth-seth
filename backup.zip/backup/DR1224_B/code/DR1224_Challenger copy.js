console.log("VMO2AB_DR1224Version2 Challenger");
(function () {

  function poll(fn, callback, errback, timeout, interval) {
    let endTime = Number(new Date()) + (timeout || 2000);
    interval = 1000;
    (function p() {
      // If the condition is met, we're done! 
      if (fn()) {
        callback();
      }
      // If the condition isn't met but the timeout hasn't elapsed, go again
      else if (Number(new Date()) < endTime) {
        setTimeout(p, interval);
      }
      // Didn't match and too much time, reject!
      else {
        errback(new Error('timed out for ' + fn + ': ' + arguments));
      }
    })();
  }
  poll(
    function () {
      return typeof jQuery == "function" && typeof $ == "function" && typeof window.optimizely !== "undefined" && ($("body").find('.globalNav').length > 0 || $("body").find('.global-header__main').length > 0);
    },
    function () {
      // Done, success callback
        executeExprience();
    },
    function (err) {
      // Error, failure callback
      console.log("error: ", err);
    },
    40000
  );

  function executeExprience() {
    console.log('ttt first')
    console.log('ttt first ', $('.o2uk-buble-loader_fade-out').length, 'gg', $('.globalNav').length)
    console.log('ttt executeExprience ')
    captureBasketPage();
    visitingPage();

    $(document).on('click', '.DR1224-overlay .o2uk-dialog-title__button, .DR1224-overlay .DR1224-button, .DR1224-overlay .DR1224-close', function () {
      console.log('ttt close')
      $('.DR1224-modal-content').addClass('close-overlay');

      setTimeout(()=>{
        $(".DR1224-overlay").remove();
      }, 400);
      $('html').css('overflow-y', 'scroll');
  });

  }

  function captureBasketPage() {
    console.log('ttt captureBasketPage', window.localStorage.getItem('DR1224_count'));
    console.log('ttt page overlay', window.localStorage.getItem('DR1224_overlay'));
    let count = 0;
    const interval = setInterval(()=>{
      if(($('.o2uk-buble-loader_fade-out').length>0 || $('.globalNav').length>0) && window.location.href.includes('https://www.o2.co.uk/shop/basket') && window.localStorage.getItem('DR1224_count') ==null && $('.o2uk-header-curve__text-title:not(:contains("empty"))').length>0 && utag_data.basket_contract_product_type.includes('paymonthly phones')){
        window.localStorage.setItem('DR1224_count', 0);
        console.log('ttt initialized')
        clearInterval(interval);
      }
      else if(+count>100){
        clearInterval(interval);
      }
    }, 300);
  }

  function visitingPage() {
    console.log('ttt visitingPage')
    console.log('ttt cc', window.localStorage.getItem('DR1224_count'));
    console.log('ttt visit overlay', window.localStorage.getItem('DR1224_overlay'));
    let count = 0;
    const interval = setInterval(()=>{
      if(($('.o2uk-buble-loader_fade-out').length>0 || $('.globalNav').length>0) && !window.location.href.includes('https://www.o2.co.uk/shop/basket') && window.localStorage.getItem('DR1224_count') !==null && window.localStorage.getItem('DR1224_overlay') == null){
        let pageCount = parseInt(window.localStorage.getItem('DR1224_count')); 
        window.localStorage.setItem('DR1224_count', pageCount+1);

        if(window.localStorage.getItem('DR1224_count')>=3){

          setTimeout(()=>{
            console.log('ttt appendOverlay');
            const liferay = $('body').find('[class*="liferay"]').length ? true:false;
            appendOverlay(liferay);
          }, 2000);
        }
        console.log('ttt DR1224 count', window.localStorage.getItem('DR1224_count'));
        clearInterval(interval);
      }
      else if(+count>100){
        clearInterval(interval);
      }
    }, 300);
  }

  function appendOverlay(flag) {

    const liferayModal = `<div id="myModal" class="DR1224-overlay DR1224-modal"><div class="DR1224-modal-content"><div class="DR1224-modal-header"><span class="DR1224-close">&times;</span><h2>Hey, you left something behind</h2></div><div class="DR1224-modal-body"><p>Complete your purchase now and get free next working day delivery.</p></div><div class="DR1224-modal-footer"><p class="DR1224-button"><a href="https://www.o2.co.uk/shop/basket" type="button" role="button" class="mat-focus-indicator mat-button-base o2uk-primary-button ng-star-inserted" aria-label="View your basket"><span class="mat-button-wrapper">View your basket</span><div aria-hidden="true" class="mat-ripple mat-button-ripple"></div><div aria-hidden="true" class="mat-button-focus-overlay"></div></a></p></div></div></div>`;

    const appenOverlay1224 = `<div class="DR1224-overlay cdk-overlay-container"><div class="cdk-overlay-backdrop cdk-overlay-dark-backdrop cdk-overlay-backdrop-showing"></div><div class="cdk-global-overlay-wrapper" dir="ltr"><div id="cdk-overlay-4" class="cdk-overlay-pane" ><o2uk-dialog-container tabindex="-1" aria-modal="true" class="o2uk-dialog-container mat-dialog-container ng-tns-c51-56 ng-trigger ng-trigger-dialogContainer ng-star-inserted" id="o2uk-dialog-4" role="dialog" ><div class="o2uk-container no-gutters-xs o2uk-container_height ng-tns-c51-56"><div class="row o2uk-container_height ng-tns-c51-56"><div class="ng-tns-c51-56 col-xs-4 col-sm-8 col-md-skip-2 col-md-8"><div tabindex="0" class="cdk-visually-hidden cdk-focus-trap-anchor" aria-hidden="true"></div><div class="o2uk-dialog-content-parent ng-tns-c51-56"><o2uk-promo-dialog class="ng-star-inserted"><div class="o2uk-dialog-title" id="o2uk-dialog-title-4"><div class="o2uk-dialog-title__content"><h1 tabindex="-1" class="h3">Hey, you left something behind</h1><o2uk-dialog-cross><button type="button" role="button" class="o2uk-dialog-title__button "><o2uk-svg-resolver role="row" classlist="o2uk-svg o2uk-svg_size_m o2uk-dialog-title__button-svg" svgid="icon-cross" class="svg-resolver o2uk-svg o2uk-svg_size_m" aria-hidden="true"><div class="o2uk-svg o2uk-svg_size_m o2uk-dialog-title__button-svg"><span class="o2uk-icon-font icon-cross"></span></div><title></title></o2uk-svg-resolver><span class="sr-only">Close Dialog</span></button></o2uk-dialog-cross></div></div><o2uk-dialog-content class="o2uk-dialog-content mat-dialog-content"><o2uk-scroll-wrapper id="dialogScrollWrapper" class="o2uk-scroll-wrapper"><overlay-scrollbars class="os-host os-host-flexbox os-host-foreign scroll os-host-resize-disabled os-host-scrollbar-horizontal-hidden ng-star-inserted os-host-transition os-host-scrollbar-vertical-hidden"><div  class="os-resize-observer-host observed"><div class="os-resize-observer" style="left: 0px; right: auto;"></div></div><div class="os-content-glue"></div><div  class="os-padding"><div class="os-viewport os-viewport-native-scrollbars-invisible"><div  class="os-content"><p class="ng-star-inserted"><p>Complete your purchase now and get free next working day delivery.</p><p class="DR1224-button"><a href="https://www.o2.co.uk/shop/basket" type="button" role="button" class="mat-focus-indicator mat-button-base o2uk-primary-button ng-star-inserted" aria-label="View your basket"><span class="mat-button-wrapper">View your basket</span><div aria-hidden="true" class="mat-ripple mat-button-ripple"></div><div aria-hidden="true" class="mat-button-focus-overlay"></div></a></p></p></div></div></div><div  class="os-scrollbar os-scrollbar-horizontal os-scrollbar-unusable os-scrollbar-auto-hidden"><div  class="os-scrollbar-track"><div class="os-scrollbar-handle" style="width: 100%; transform: translate(0px, 0px);"></div></div></div><div class="os-scrollbar os-scrollbar-vertical os-scrollbar-auto-hidden os-scrollbar-unusable"><div class="os-scrollbar-track"><div class="os-scrollbar-handle" style="height: 100%; transform: translate(0px, 0px);"></div></div></div><div class="os-scrollbar-corner"></div></overlay-scrollbars></o2uk-scroll-wrapper></o2uk-dialog-content></o2uk-promo-dialog></div><div tabindex="0" class="cdk-visually-hidden cdk-focus-trap-anchor" aria-hidden="true"></div></div></div></div></o2uk-dialog-container></div></div></div>`;


    $('body').append(flag?liferayModal:appenOverlay1224);
  
    // window.localStorage.setItem('DR1224_overlay', 'done');

    $(".DR1224-overlay").show();
    $('html').css('overflow-y', 'hidden');

  }

})();