console.log("VMO2AB_DR1224Version2 shared code");
(function () {

  function poll(fn, callback, errback, timeout, interval) {
    let endTime = Number(new Date()) + (timeout || 2000);
    interval = 1000;
    (function p() {
      // If the condition is met, we're done! 
      if (fn()) {
        callback();
      }
      // If the condition isn't met but the timeout hasn't elapsed, go again
      else if (Number(new Date()) < endTime) {
        setTimeout(p, interval);
      }
      // Didn't match and too much time, reject!
      else {
        errback(new Error('timed out for ' + fn + ': ' + arguments));
      }
    })();
  }
  poll(
    function () {
      return typeof jQuery == "function" && typeof $ == "function" && typeof window.optimizely !== "undefined" && ($("body").find('.globalNav').length > 0 || $("body").find('.global-header__main').length > 0);
    },
    function () {
      // Done, success callback
        executeExprience();
    },
    function (err) {
      // Error, failure callback
      console.log("error: ", err);
    },
    40000
  );

  function executeExprience() {
  if (window.optimizely && window.optimizely.get) {
    let utils = window.optimizely.get("utils");
    // console.log('Optiizely should started');
    deactivateChallenger('DR1224_basket_remainder');
    // Check if observeSelector method is available in the utils object
    if (utils && utils.observeSelector) {
      const selector = $('.globalNavlinksWrapper').length >0 ? '.globalNavlinksWrapper': 'div[role="navigation"].o2uk-container.global-header__breadcrumb-wrapper.ng-star-inserted o2uk-breadcrumbs';
      //const selector = $('.globalNavlinksWrapper').length >0 ? '.globalNavlinksWrapper': '.o2uk-header-curve__text-title';
      utils.observeSelector(
          `${selector}`,
          function () {
            if (!$(".global-header__upper").hasClass("o2uk-changed")) {
              // console.log("ttt doesn't have class - repeat changes");
              $(".global-header__upper").addClass("o2uk-changed");
              makeChanges(selector, true);
              triggerRemoveBasket();
            }
          },{
          once: false,
          }
        );
    } else {
        console.error("observeSelector method is not available in utils object.");
    }
  } else {
      console.error("utils or utag_obj is not available in the window object.");
  }
  }

  function makeChanges(selector, flag = false){
    // console.log('ttt observer', selector);
    if (window.location.href.startsWith('https://www.o2.co.uk/shop') && $('.DR1224-modal').length == 0 && !window.location.href.includes('https://www.o2.co.uk/shop/basket')) {
      // console.log('ttt Fire the Dialog box');
      visitingPage(flag);
    }
    if(window.location.href.includes('https://www.o2.co.uk/shop/basket')){
      captureBasketPage();
    }
  }

  function triggerRemoveBasket(){
    $(document).on('click','.main-cta-remove-button', function(){
      // console.log('ttt remove basket')
      let count = 0;
      const interval = setInterval(()=>{
        if(($('.o2uk-buble-loader_fade-out').length>0 || $('.globalNav').length>0) && window.location.href.includes('https://www.o2.co.uk/shop/basket') && window.sessionStorage.getItem('DR1224_count') !==null && $('.o2uk-header-curve__text-title:contains("empty")').length>0 ){
          clearInterval(interval);
          window.sessionStorage.removeItem('DR1224_count');
        }
        else if(++count>100){
          clearInterval(interval);
        }
      }, 300);
    });
  }

  function captureBasketPage() {
    // console.log('ttt captureBasketPage', window.sessionStorage.getItem('DR1224_count'));
    // console.log('ttt page overlay', window.sessionStorage.getItem('DR1224_overlay'));
    let count = 0;
    const interval = setInterval(()=>{
      //let deviceName = $('body').find('.device-info__brand-name').text().trim().includes('Apple iPhone')?true: window.utag_data.basket_contract_product_type.includes('paymonthly phones');
      //console.log('ttt deviceName', deviceName)
      if(($('.o2uk-buble-loader_fade-out').length>0 || $('.globalNav').length>0) && window.location.href.includes('https://www.o2.co.uk/shop/basket') && (window.sessionStorage.getItem('DR1224_count') ==null || (window.sessionStorage.getItem('DR1224_count') !==null && window.sessionStorage.getItem('DR1224_overlay') == null)) && $('.o2uk-header-curve__text-title:not(:contains("empty"))').length>0 && window.utag_data_copy && window.utag_data_copy.basket_contract_product_type.includes('paymonthly phones') ) {
        window.sessionStorage.setItem('DR1224_count', 0);
        // console.log('ttt initialized')

        clearInterval(interval);
      }
      else if(++count>100){
        clearInterval(interval);
      }
    }, 300);
  }

  function visitingPage(flag=false) {
    let count = 0;
    const interval = setInterval(()=>{
      if(($('.o2uk-buble-loader_fade-out').length>0 || $('.globalNav').length>0) && !window.location.href.includes('https://www.o2.co.uk/shop/basket') && window.sessionStorage.getItem('DR1224_count') !==null && window.sessionStorage.getItem('DR1224_overlay') == null && flag){
        clearInterval(interval);
        let pageCount = parseInt(window.sessionStorage.getItem('DR1224_count'));
        if(count<30){
          window.sessionStorage.setItem('DR1224_count', (pageCount+1));
        }
        if(window.sessionStorage.getItem('DR1224_count')==2){
          setTimeout(()=>{
            fireChallenger('DR1224_basket_remainder');
          }, 2000);
        }
        // console.log('ttt DR1224 count', window.sessionStorage.getItem('DR1224_count'), 'count', count);
      }
      else if(++count>100){
        clearInterval(interval);
      }
    }, 300);
  }

  function deactivateChallenger(pageName){
    window.optimizely = window.optimizely || [];
    window.optimizely.push({
      type: "page",
      pageName: pageName,
      isActive: false
    });
  }

  function fireChallenger(pageName){
    window.optimizely = window.optimizely || [];
    window.optimizely.push({
      type: "page",
      pageName: pageName,
    });
  }
})();