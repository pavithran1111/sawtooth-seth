(function () {
	console.log("VMO2AB_Version2 DR1126C Challenger");
	function poll(fn, callback, errback, timeout, interval) {
		let endTime = Number(new Date()) + (timeout || 2000);
		// interval = interval || 100;
		interval = 3000;
		(function p() {
			// If the condition is met, we're done! 
			if (fn()) {
					callback();
			}
			// If the condition isn't met but the timeout hasn't elapsed, go again
			else if (Number(new Date()) < endTime) {
					setTimeout(p, interval);
			}
			// Didn't match and too much time, reject!
			else {
					errback(new Error('timed out for ' + fn + ': ' + arguments));
			}
		})();
	}
	poll(
		function () {
			return typeof jQuery == "function" && typeof $ == "function";
		},
		function () {
			// Done, success callback
			loadExperience();
		},
		function (err) {
			// Error, failure callback
			console.log("error: ", err);
		},
		40000
	);

	function loadExperience() {
		poll(
			function () {
				return (!!$('.product-background').length || $('.portlet-content').length > 0) && (utag_obj.page_page_name.startsWith("shop:cfa|tablets|devices|") || utag_obj.page_page_name.startsWith("shop:cfu|tablets|devices|")) && $('#senna_surface').length > 0 && document.querySelector('.device-customization')!==null;
			},
			function () {
				// Done, success callback
				executeExprience();
			},
			function (err) {
				// Error, failure callback
				console.log("error: ", err);
			}
		);
	}

	function executeExprience(flag=true) {
		function executeDR1126C() {
		let observerCounter = 0;

		let observer = new MutationObserver((mutationRecords) => {
		++observerCounter;
			if($('.product-background').length>0)
				customizeMultiSavePlan();
			if($('#senna_surface').length > 0 && $('.device-customization__plan-picker-calculator').length > 0)
				customizeMultiSavePlan360();

			if (observerCounter > 2500) {
				observer.disconnect();
			}
		});

		observer.observe(document.querySelector('.device-customization'), {
			childList: true,
			subtree: true,
			attributes: true,
			characterData: true,
		});

		$('body').addClass('DR1126C');
		let newColorBox = `<div class="o2uk-container"><div class="row center">
				<div class="DR1126C-multisave">
					<div class="align-tabs-left">
						<div class="multiSaveBoxImage">
								<img src="https://static-www.o2.co.uk/sites/default/files/Sim_Outline.png" class="SimoOutlineIcon1126C"/>
						</div>
						<div class="multiSaveContent">
						<div class="multiSaveBoxHead">Save 20% when you add a new line</div>
						<div class="multiSaveBoxPara"> If you’re already with O2, you can get a 20% discount on additional lines with Multisave. Don’t forget to claim your discount as soon as you activate your new line. <div manual_cm_re = 'DR1126C-_-Challenger-_-More details' class="multiSaveBoxLink" target="_blank">More details.</div>
						</div>

						<div class="BoldText1126C">Are you already an O2 customer?</div>
						<div class="toggleDiv1126C">
								<div class="toggle1126CPath let-active">
										<div class="toggle1126CNotch">
										</div>
								</div>
						</div>
				</div>
				</div></div></div></div></div></div>`;

		let thisInteger, thisDecimal, thisAirtime, finalNumber, thisDiscount, discountedPrice, displayInteger, displayDecimal;

		function getValues() {
			setTimeout(function () {
        $('body').find('.total-cost-section-col-1').each(function () {
          // if (!$(this).parents('.tariff-plan-wrapper').find('.ribbon-additional-heading').text().includes('Summer Sale')) {
          if(!$(this).parent().next().text().includes('Choose') && $(this).parent().find('.discountDisplay').length == 0){
            thisInteger = $(this).find('.total-cost-price-int').text().replace(/\D/g, "");
            thisDecimal = $(this).find('.total-cost-price-decimal').text().replace(/\D/g, "");
            thisAirtime = $(this).parent().next().text().split('+')[1].split('A')[0].replace('£', '').trim();

            finalNumber = parseFloat(thisInteger + "." + thisDecimal);
            thisDiscount = ((thisAirtime * 20) / 100);
            discountedPrice = (finalNumber - thisDiscount).toFixed(2);
            displayInteger = Math.floor(discountedPrice);
            displayDecimal = Math.round((discountedPrice % 1) * 100);
            if (displayDecimal == 0)
              displayDecimal = "00";

            $(this).addClass('switchDiscount');
            $(this).after('<div class="discountDisplay usemetoHide"><span class="dicountInteger">£' + displayInteger + '.</span><span class=dicountDecimal>' + displayDecimal + '<sup data-v-35c4c4e9="" class="disclaimer-star">*</sup></span><div class="discountText"><span class="smallMonthly">MONTHLY</span><br/> with Multisave <a data-v-35c4c4e9="" tabindex="0" data-qa-i-icon="" data-toggle="modal" class="discountInformation" manual_cm_re = "DR1126C-_-Challenger-_-information icon"></a><br/> WAS <span class="forStrike">£' + finalNumber + '</span></div></div>');
          }
        });
        customizeMultiSavePlan();
			}, 500);
		}

		function getValues360(flag1=false){
			setTimeout(function () {
				const priceBlock = $('.tariff-card__price-block .tariff-card__price >:last-child').length > 0 ? '.tariff-card__price-block .tariff-card__price >:last-child' : '.tariff-card__price-block .o2uk-price';
				
				$(priceBlock).each(function () {
				if($(this).parent().find('.discountDisplay').length == 0 || flag1){
					thisInteger = $(this).find('.o2uk-price__amount-integer').text().replace(/\D/g, "");
					thisDecimal = $(this).find('.o2uk-price__amount-decimal').text().replace(/\D/g, "");
					thisAirtime = $('.tariff-card__price-block .tariff-card__price >:last-child').length > 0 ? $(this).parent().parent().next().text().split('+')[1].split('A')[0].replace('£', '').trim().slice(0, -1) : $(this).parent().next().text().split('+')[1].split('A')[0].replace('£', '').trim().slice(0, -1);
					finalNumber = parseFloat(thisInteger + "." + thisDecimal);
					thisDiscount = ((thisAirtime * 20) / 100);
					discountedPrice = (finalNumber - thisDiscount).toFixed(2);
					displayInteger = Math.floor(discountedPrice);
					displayDecimal = Math.round((discountedPrice % 1) * 100);
					if (displayDecimal == 0)
						displayDecimal = "00";
					displayDecimal = (displayDecimal.length==1?displayDecimal+'0':displayDecimal);
					$(this).addClass('switchDiscount');
					console.log('discountDisplay', $(this).find('.discountDisplay').length)
					$('.tariff-card__price-block .tariff-card__price >:last-child').length > 0?
					$(this).after('<div class="discountDisplay DR1126C-wrapper '+(flag1?'':'usemetoHide')+'"><div class="o2uk-price__amount ng-star-inserted purplePrice"><span class="sr-only ng-star-inserted"> £'+displayInteger+'.'+displayDecimal +'† monthly </span><div aria-hidden="true" role="presentation" class="o2uk-price__amount-sign"> £ </div><div aria-hidden="true" role="presentation" class="o2uk-price__amount-integer"> '+displayInteger+' </div><div class="o2uk-price__amount-decimal o2uk-price__amount-decimal_medium"><span aria-hidden="true" role="presentation" class="font font_light"> .'+displayDecimal+'</span><sup class="o2uk-price__amount-decimal-footnote ng-star-inserted"><a class="purplePrice" footnotelink="" tabindex="0" href="#rpi-footnote" id="792b8537-30e3-44fe-ab9f-69ae81dbf22e" aria-label="See footnote below for conditions"> † </a></sup></div></div><div class="discountText"><div aria-hidden="true" role="presentation" class="o2uk-price__hint ng-star-inserted">Monthly</div><div class="DR1126Ctext">with Multisave <br/> WAS <span class="forStrike">£' + (finalNumber.toString().length==4? finalNumber+'0':finalNumber) + '</span></div></div></div>'):
					$(this).after('<div class="discountDisplay usemetoHide"><div class="o2uk-price__amount ng-star-inserted purplePrice"><span class="sr-only ng-star-inserted"></span><div aria-hidden="true" role="presentation" class="o2uk-price__amount-sign"> £ </div><div aria-hidden="true" role="presentation" class="o2uk-price__amount-integer"> '+displayInteger+' </div><div class="o2uk-price__amount-decimal o2uk-price__amount-decimal_medium"><span aria-hidden="true" role="presentation" class="font font_light">.'+displayDecimal+'</span><sup class="o2uk-price__amount-decimal-footnote ng-star-inserted"><a class="purplePrice" footnotelink="" tabindex="0" href="#rpi-footnote" id="1c104a7c-aa7b-4555-9cc1-0910865ec2c6" aria-label="See footnote below for conditions"> † </a></sup></div></div><div class="discountText"><div aria-hidden="true" role="presentation" class="o2uk-price__hint ng-star-inserted">Monthly</div><div class="DR1126Ctext">with Multisave <br/> WAS <span class="forStrike">£' + finalNumber + '</span></div></div></div>');
         //<a data-v-35c4c4e9="" tabindex="0" data-qa-i-icon="" data-toggle="modal" class="discountInformation" manual_cm_re = "DR1126C-_-Challenger-_-information icon"></a>
				}
			});

			$('.multiSaveBoxPara, .BoldText1126C').css('font-size', '17px');
      $('.overlayTermsApply1126C .box-header h3').css('font-family', 'sans-serif');
			$('.overlayTermsApply1126C p').css({'font-family': 'sans-serif','font-size': '16px'});
			$('.overlayTermsApply1126C a').css({'font-family': 'sans-serif','font-weight': '600'});
			if($('#senna_surface').length > 0 && $('.device-customization__plan-picker-calculator').length > 0)
				customizeMultiSavePlan360();
			}, 100);
		}

		function customizeMultiSavePlan(){
			let deviceData, airtimeData, monthlyDecimal = '';
			deviceData = $(".pay-monthly-wrapper div[data-qa-calculator-totalcost-device-airtime] .device").text();
			airtimeData = $(".pay-monthly-wrapper div[data-qa-calculator-totalcost-device-airtime] .airtime").text().trim();
			if($('.toggle1126CPath').hasClass('is-active')){
				let deviceInt = deviceData.split(".")[0];
				let deviceDecimal = deviceData.split(".")[1];
				let monthlyInt = $(".pay-monthly-wrapper div[data-qa-calculator-totalcost-monthly] .big").text().trim();
				monthlyDecimal = $(".pay-monthly-wrapper div[data-qa-calculator-totalcost-monthly] .small").contents().filter(
						function () {
							return this.nodeType == Node.TEXT_NODE;
						}).text();

				if ($(".monthlyContainer .title").text().includes('Multisave'))
					monthlyDecimal = $(".monthlyContainer .title").text().split(".")[1].substr(0, 2);

				let total = (parseFloat(deviceInt +'.'+ deviceDecimal) + parseFloat(airtimeData)).toFixed(2);
				//let devicePrice = parseFloat(deviceInt +'.'+ deviceDecimal);
				let thisDiscount = ((airtimeData * 20) / 100);
				let custdiscountedPrice = (total - thisDiscount).toFixed(2);
				let custdisplayInteger = Math.floor(custdiscountedPrice);
				let custdisplayDecimal = Math.round((custdiscountedPrice % 1) * 100);
				if (custdisplayDecimal == 0)
					custdisplayDecimal = "00";
				if (deviceInt && monthlyInt && (deviceInt !== monthlyInt)) {
					$(".pay-monthly-wrapper div[data-qa-calculator-totalcost-monthly] .big").text(deviceInt);
					addDeviceandAirtime(total, custdisplayInteger, custdisplayDecimal);
				}
				if (deviceDecimal && monthlyDecimal && (deviceDecimal !== monthlyDecimal)) {
					addDeviceandAirtime(total, custdisplayInteger, custdisplayDecimal);
					$(".pay-monthly-wrapper div[data-qa-calculator-totalcost-monthly] .small").contents().filter(
						function () {
							return this.nodeType == Node.TEXT_NODE;
						}).text(deviceDecimal);					
				}
			} else if($(".pay-monthly-wrapper div[data-qa-calculator-totalcost-device-airtime]").length > 0){
				$('.monthlyContainer .DR1126CPrice').remove();
				$('.monthlyContainer .cost > div:first-child').show();
				if (deviceData.length > 0 && airtimeData.length > 0) {
					let deviceInt = deviceData.split(".")[0];
					let deviceDecimal = deviceData.split(".")[1];

					let airtimeInt = airtimeData.split(".")[0];
					let airtimeDecimal = airtimeData.split(".")[1];

					let totalInt = (parseInt(deviceInt) + parseInt(airtimeInt)).toString();
					let totalDecimal = (parseInt(deviceDecimal) + parseInt(airtimeDecimal)).toString();
					if (totalDecimal.length < 2) {
						totalDecimal = "0" + totalDecimal;
					} else if (totalDecimal.length > 2) {
						totalInt = (parseInt(totalInt) + parseInt(totalDecimal[0])).toString();
						totalDecimal = totalDecimal.substring(1);
					}

					let monthlyInt = $(".pay-monthly-wrapper div[data-qa-calculator-totalcost-monthly] .big").text();
					let monthlyDecimal = $(".pay-monthly-wrapper div[data-qa-calculator-totalcost-monthly] .small")
						.contents()
						.filter(function () {
							return this.nodeType == Node.TEXT_NODE;
						}).text();

					if (totalInt && monthlyInt && totalInt !== monthlyInt) {
						$(".pay-monthly-wrapper div[data-qa-calculator-totalcost-monthly]").removeClass("purplePrice");
						$(".pay-monthly-wrapper .monthlyContainer .title").html(
							'MONTHLY <div data-v-55d62eca="" tabindex="0" aria-label="Refresh plan link, opens in a popup window" data-qa-tariff-monthly-info="" class="i-icon"></div>');
						$(".pay-monthly-wrapper div[data-qa-calculator-totalcost-monthly] .big").text(totalInt);
					}

					if (totalDecimal && monthlyDecimal && totalDecimal !== monthlyDecimal) {
						$(".pay-monthly-wrapper div[data-qa-calculator-totalcost-monthly]").removeClass("purplePrice");
						$(".pay-monthly-wrapper div[data-qa-calculator-totalcost-monthly] .small")
							.contents()
							.filter(function () {
								return this.nodeType == Node.TEXT_NODE;
							})
							.replaceWith(totalDecimal);
					}
				}

				if (!!$(".pay-monthly-wrapper div[data-qa-calculator-totalcost-device-airtime] .airtime-offer-text").length) {
					$(".pay-monthly-wrapper div[data-qa-calculator-totalcost-device-airtime] .airtime-offer-text").remove();
				}
			}
		}

		function customizeMultiSavePlan360() {
			let deviceData, airtimeData, monthlyDecimal = '';
			deviceData = $('.device-customization__plan-picker-calculator .device-calculator .amount-info-monthly').text() ? $('.device-customization__plan-picker-calculator .device-calculator .amount-info-monthly').text().split('+')[0].replace(/[^\d.]/g, ""):'';
			airtimeData = $('.device-customization__plan-picker-calculator .device-calculator .amount-info-monthly').text() ? $('.device-customization__plan-picker-calculator .device-calculator .amount-info-monthly').text().split('+')[1].replace(/[^\d.]/g, ""):'';
			if($('.toggle1126CPath').hasClass('is-active')){

				let deviceInt = deviceData.split(".")[0];
				let deviceDecimal = deviceData.split(".")[1];
				//let monthlyInt = $(".device-customization__plan-picker-calculator .device-calculator .o2uk-price__amount-integer:nth-child(3)").eq(0).text().trim();
				let monthlyInt = $(".device-customization__plan-picker-calculator .device-calculator__price-value > :nth-child(3) .o2uk-price__amount-integer").eq(0).text().trim();
				//monthlyDecimal = $('.device-customization__plan-picker-calculator .device-calculator .o2uk-price__amount-decimal:nth-child(4)').eq(0).text().replace(/\D/g, "");
				monthlyDecimal = $(".device-customization__plan-picker-calculator .device-calculator__price-value > :nth-child(3) .o2uk-price__amount-decimal").eq(0).text().replace(/\D/g, "");

				if ($(".device-customization__plan-picker-calculator .device-calculator__price-value > :nth-child(3) .o2uk-price__hint").text().includes('Multisave'))
					monthlyDecimal = $(".device-customization__plan-picker-calculator .device-calculator__price-value > :nth-child(3) .o2uk-price__hint").text().split(".")[1].substr(0, 2);

				let total = (parseFloat(deviceInt +'.'+ deviceDecimal) + parseFloat(airtimeData)).toFixed(2);
				//let devicePrice = parseFloat(deviceInt +'.'+ deviceDecimal);
				let thisDiscount = ((airtimeData * 20) / 100);
				let custdiscountedPrice = (total - thisDiscount).toFixed(2);
				let custdisplayInteger = Math.floor(custdiscountedPrice);
				let custdisplayDecimal = Math.round((custdiscountedPrice % 1) * 100);
				if (custdisplayDecimal == 0)
					custdisplayDecimal = "00";
					//console.log(deviceInt+' FFFFFF '+ monthlyInt);
				if (deviceInt && monthlyInt && (deviceInt !== monthlyInt)) {
					$(".device-customization__plan-picker-calculator .device-calculator__price-value > :nth-child(3) .o2uk-price__amount-integer").eq(0).text(deviceInt);
					addDeviceandAirtime(total, custdisplayInteger, custdisplayDecimal);
				}
				// console.log(deviceDecimal+' SSSSSS '+ monthlyDecimal);

				if (deviceDecimal && monthlyDecimal && (deviceDecimal !== monthlyDecimal)) {
					addDeviceandAirtime(total, custdisplayInteger, custdisplayDecimal);
						$('.device-customization__plan-picker-calculator .device-calculator__price-value > :nth-child(3) .o2uk-price__amount-decimal').eq(0).text('.'+deviceDecimal);
				}
			} else if($('.device-customization__plan-picker-calculator').length > 0) {
					$('.device-customization__plan-picker-calculator .device-calculator .DR1126CPrice').remove();
					$('.device-customization__plan-picker-calculator .device-calculator__price-value > :nth-child(3) .o2uk-price__amount').eq(0).show();
				if (deviceData.length > 0 && airtimeData.length > 0) {
					let deviceInt = deviceData.split(".")[0];
					let deviceDecimal = deviceData.split(".")[1];

					let airtimeInt = airtimeData.split(".")[0];
					let airtimeDecimal = airtimeData.split(".")[1];

					let totalInt = (parseInt(deviceInt) + parseInt(airtimeInt)).toString();
					let totalDecimal = (parseInt(deviceDecimal) + parseInt(airtimeDecimal)).toString();
					if (totalDecimal.length < 2) {
						totalDecimal = "0" + totalDecimal;
					} else if (totalDecimal.length > 2) {
						totalInt = (parseInt(totalInt) + parseInt(totalDecimal[0])).toString();
						totalDecimal = totalDecimal.substring(1);
					}
					// let monthlyInt = $(".device-customization__plan-picker-calculator .device-calculator .o2uk-price__amount-integer:nth-child(3)").eq(0).text();
					let monthlyInt = $(".device-customization__plan-picker-calculator .device-calculator__price-value > :nth-child(3) .o2uk-price__amount-integer").text();
					//let monthlyDecimal = $('.device-customization__plan-picker-calculator .device-calculator .o2uk-price__amount-decimal:nth-child(4)').eq(0).text().replace(/\D/g, "");
					let monthlyDecimal = $(".device-customization__plan-picker-calculator .device-calculator__price-value > :nth-child(3) .o2uk-price__amount-decimal").text().replace(/\D/g, "");
					// console.log(totalInt+' ELSE FFFFFF '+ monthlyInt);
					if (totalInt && monthlyInt && totalInt !== monthlyInt) {
						$(".device-customization__plan-picker-calculator .device-calculator .device-calculator__price-value > div:nth-child(3) .o2uk-price__amount").eq(0).removeClass("purplePrice");

						$(".device-customization__plan-picker-calculator .device-calculator__price-value > :nth-child(3) .o2uk-price__hint").html('MONTHLY <div data-v-55d62eca="" tabindex="0" aria-label="Refresh plan link, opens in a popup window" data-qa-tariff-monthly-info="" class="i-icon"></div>');
						$('.device-customization__plan-picker-calculator .device-calculator .o2uk-price__amount-integer:nth-child(3)').text(totalInt);
					}
					// console.log(totalDecimal+' ELSE SSSSSS '+ monthlyDecimal);
					if (totalDecimal && monthlyDecimal && totalDecimal !== monthlyDecimal) {
						$(".device-customization__plan-picker-calculator .device-calculator .device-calculator__price-value > div:nth-child(3) .o2uk-price__amount").eq(0).removeClass("purplePrice");

						$('.device-customization__plan-picker-calculator .device-calculator .device-calculator__price-value > div:nth-child(3) .o2uk-price__amount-decimal span').text(totalDecimal);
					}
				}

				if (!!$(".device-customization__plan-picker-calculator .device-calculator .device-calculator__price-value .airtime-offer-text").length) {
					$(".device-customization__plan-picker-calculator .device-calculator .device-calculator__price-value .airtime-offer-text").remove();
				}
			}
		}

		function addDeviceandAirtime(total, custInt, custDeci) {
			$('.monthlyContainer .cost > div:first-child, .device-customization__plan-picker-calculator .device-calculator__price-value > :nth-child(3) .o2uk-price__amount').eq(0).hide();
			let decimal = custDeci.toString().length==1? custDeci+'0':custDeci;
			if(!$('.monthlyContainer .DR1126CPrice, .device-customization__plan-picker-calculator .device-calculator__price-value > :nth-child(3) .DR1126CPrice').length){
				if($('#senna_surface').length > 0)
					$('<div class="o2uk-price__amount ng-star-inserted DR1126CPrice purplePrice"><span class="sr-only ng-star-inserted"> £'+custInt+'.'+decimal+'† monthly </span><div aria-hidden="true" role="presentation" class="o2uk-price__amount-sign"> £ </div><div aria-hidden="true" role="presentation" class="o2uk-price__amount-integer custInt">'+custInt+'</div><div class="o2uk-price__amount-decimal o2uk-price__amount-decimal_medium">.<span aria-hidden="true" role="presentation" class="font font_light custDeci">'+decimal+'</span><sup class="o2uk-price__amount-decimal-footnote ng-star-inserted"><a footnotelink="" class="purplePrice" tabindex="0" href="#rpi-footnote" id="b4a7849e-a5ca-48a5-9f0f-7d0c5065e773" aria-label="See footnote below for conditions"> † </a></sup></div></div>').insertBefore('.device-customization__plan-picker-calculator .device-calculator__price-value > :nth-child(3) .o2uk-price__hint');
				else
					$('<div data-qa-calculator-totalcost-monthly="" data-v-161b6153="" class="DR1126CPrice purplePrice">£<span class="custInt" data-v-161b6153="">'+custInt+'</span>.<span class="custDeci" data-v-161b6153="">'+custDeci+'<sup class="disclaimer-star" data-v-000ff515="">*</sup></span></div>').insertBefore('.monthlyContainer .title');
			}
			$('.DR1126CPrice .custInt').text(custInt);
			let title, discountInfo = '';
			if($('#senna_surface').length > 0){
				$('.DR1126CPrice .custDeci').text(decimal);
				$(".device-customization__plan-picker-calculator .device-calculator .device-calculator__price-value > div:nth-child(3) .o2uk-price__amount").eq(0).addClass('purplePrice');
				title = $(".device-customization__plan-picker-calculator .device-calculator__price-value > :nth-child(3) .o2uk-price__hint");
			}
			else {
				$('.DR1126CPrice .custDeci').contents().filter(
					function () {
						return this.nodeType == Node.TEXT_NODE;
				}).replaceWith(custDeci);
				$(".pay-monthly-wrapper div[data-qa-calculator-totalcost-monthly]").addClass('purplePrice');
				title = $(".pay-monthly-wrapper .monthlyContainer .title");
        discountInfo = '<a data-v-35c4c4e9="" tabindex="0" data-qa-i-icon="" data-toggle="modal" class="discountInformation" manual_cm_re = "DR1126C-_-Challenger-_-information icon"></a>';
			}

			let text = 'MONTHLY<br/>with Multisave'+discountInfo+'<br/>WAS £<span class="forStrike">'+total+'</span>';
			title.html(text);
		}

		function addBanner1126C() {
			if (!$('.DR1126C-multisave').length) {
				if($('#senna_surface').length > 0) {
					// $('.tab-list-container').append(newColorBox);
					$(newColorBox).insertBefore('.tab-body-wrapper');
				}
				else {
					$('.prePackageTabs').append(newColorBox);
				}
			}
		}

		// if ((window.location.hash).includes('contractType=paymonthly') && !(window.location.hash).includes('contractLength=P30D') ) {

		addBanner1126C();

			if($('#senna_surface').length > 0)
				getValues360();
			else	
				getValues();
		// }
		//Click function starts 
		if(flag && !$('.toggle1126CNotchTracking').length){
			$(document).on('click', '.first-offer-dd .dropdown-list .dp-list-item, .second-offer-dd .dropdown-list .dp-list-item', function () {
				setTimeout(()=>{
					let count = 0;
					$('body').find('.total-cost-section-col-1, .tariff-card__price-block .o2uk-price').parent().find('.discountDisplay').remove();
					const interval = setInterval(()=>{
						if($('body').find('.total-cost-section-col-1, .tariff-card__price-block .o2uk-price').length > 1){
							getValues();
							$('.toggle1126CPath').addClass('let-active').removeClass('is-active');
							$('.switchDiscount ').removeClass('usemetoHide');
							clearInterval(interval);
						}
						else if(count > 300){
							clearInterval(interval);
						}
						count++;
					}, 300);
				}, 900);
			});

			$(document).on('click', '.toggle1126CPath', function () {
				$('.toggle1126CPath').toggleClass('is-active');
				$('.toggle1126CPath').toggleClass('let-active');
			});

			$(document).on('click', '.let-active', function () {
				//$('body').find('.discountDisplay').css('display', 'block');
				$('body').find('.discountDisplay').removeClass('usemetoHide');
				// $('body').find('.switchDiscount').toggleClass('usemetoHide');
				$('body').find('.switchDiscount').addClass('usemetoHide');
				$('body').find('.toggle1126COn').click();
				sessionStorage.setItem('discountDisplay', 'true');
			});
			$(document).on('click', '.is-active', function () {
				// $('body').find('.discountDisplay').css('display', 'none');
				$('body').find('.discountDisplay').addClass('usemetoHide');
				// $('body').find('.switchDiscount').toggleClass('usemetoHide');
				$('body').find('.switchDiscount').removeClass('usemetoHide');
				$('body').find('.toggle1126COff').click();
				customizeMultiSavePlan();
				sessionStorage.setItem('discountDisplay', 'false');
			});

			$(document).on('click','div[role="tablist"] .tab-labels > div:first-child', function(){
				//On choosing Pick a pre-built plan
				if($('.toggle1126CPath').attr('class').includes('is-active')){
					// $('body').find('.discountDisplay').show();
					$('body').find('.discountDisplay').removeClass('usemetoHide');
					$('body').find('.switchDiscount').addClass('usemetoHide');
					$('body').find('.toggle1126COff').click();
				}
				else {
					// $('body').find('.discountDisplay').hide();
					$('body').find('.discountDisplay').addClass('usemetoHide');
					$('body').find('.switchDiscount').removeClass('usemetoHide');
					$('body').find('.toggle1126COn').click();
				}
				updatePreBuildPlan();
			});

			$(document).on('click', 'button[aria-label="Choose this plan"]', function () {
				sessionStorage.setItem('discountDisplay', 'false');
				toReruntheChanges();
			});
			$(document).on('click', '.edit-icon, .pagination-control', function () {
				toReruntheChanges();
			});

			$(document).on('click', '.multiSaveBoxLink, .discountInformation', function () {
				$(".overlayTermsApply1126C, .overlayGreyDR").show();
				$('html').css('overflow-y', 'hidden');
				$('body').addClass('overlayView');
			});
			$(document).on('click', '.overlayTermsApply1126C a.boxclose,.overlayGreyDR, .closest, .linktoMSPage', function () {
				$(".overlayTermsApply1126C, .overlayGreyDR").hide();
				$('body').removeClass('overlayView').attr("style", "");
				$('html').css('overflow-y', 'scroll');
			});

			$(document).on('click', '.mat-select-panel__scroll-wrapper div[role="listbox"] .o2uk-option', function(){
				updatePreBuildPlan();
			});
		}
		//Click function ends

		let targetElm = document.querySelector('#rpi-footnote');
		$(document).on('click', '.discountDisplay .o2uk-price__amount-decimal-footnote, .DR1126CPrice a[tabindex="0"]', function(e){
			e.preventDefault();
			targetElm.scrollIntoView();
		});

		// Handling Tab Clicks
		function toReruntheChanges() {
			$('body').find('.discountDisplay').remove();
			$('body').find('.total-cost-section-col-1, .tariff-card__price-block .o2uk-price').removeClass('usemetoHide switchDiscount');
			if ((window.location.hash).includes('contractType=paymonthly') /*&& !(window.location.hash).includes('contractLength=P30D')*/ ) {
				addBanner1126C();
				getValues();
				if (sessionStorage.getItem('discountDisplay') == 'true') {
					setTimeout(function () {
						// $('body').find('.discountDisplay').css('display', 'block');
						$('body').find('.discountDisplay').removeClass('usemetoHide');
						$('body').find('.switchDiscount').addClass('usemetoHide');
					}, 1000);
				}
			}
			else {
				sessionStorage.setItem('discountDisplay', 'false');
				$('.DR1126C-multisave').remove();
				$('.discountDisplay').remove();
				$('body').find('.switchDiscount').removeClass('usemetoHide');
				$('body').find('.total-cost-section-col-1, .tariff-card__price-block .o2uk-price').css('display', 'block');
			}
		}

		$(window).on('hashchange', function (e) {
			toReruntheChanges();
		});
	
		function updatePreBuildPlan(){
		//	setTimeout(()=>{
				let count = 0;
				$('.discountDisplay').remove();
				const interval = setInterval(()=>{
					if($('.o2uk-buble-loader_fade-out').length > 0){
						//setTimeout(()=>{
							getValues360(true);
							if($('.toggle1126CPath').hasClass('is-active')){
								setTimeout(()=>{
									// $('body').find('.discountDisplay').css('display', 'block');
									$('body').find('.discountDisplay').removeClass('usemetoHide');
								}, 150);
							}
							else if(!$('body').find('.discountDisplay').hasClass('usemetoHide')) {
								setTimeout(()=>{
									$('body').find('.discountDisplay').addClass('usemetoHide');
								}, 150);
							}
						//}, 500);
						clearInterval(interval);
					}
					else if(++count > 300){
						clearInterval(interval);
					}
				}, 10);
			//}, 100);
		}
		// popup
		// Legal Amend popup box
		let newLegalamendpop = `<div id="newLegalamendpop"><div class="overlayTermsApply1126C newLegalamendpop"><div class="box-header"><h3>Save 20% when you add a new line with Multisave</h3><a class="boxclose"></a></div><div class="box-content scroll-bar"><p>If you’re already with O2, you can get a 20% discount on additonal lines with Multisave.</p><p>This discount will not be shown in your basket - you’ll need to claim it after you activate your new line. Simply text LOYALTY to 21500 from your new number within 28 days and we’ll apply your 20% discount.</p><p>Exclusions apply - check out our <a manual_cm_re = "DR1126C-_-Challenger-_- Multisave page link" class = "linktoMSPage" href="https://www.o2.co.uk/multisave" target="_blank"> Multisave page </a> for details.</p></div></div></div><div class="overlayGreyDR"></div>`;
		$('body').append(newLegalamendpop);

		$('.family-links .o2uk-link__container .o2uk-link').click(function(){
			setTimeout(()=>{
				executeExprience(false);
			}, 3000);
		});
		if(!$('.toggle1126CNotchTracking').length)
			$('body').append(`<div class="toggle1126CNotchTracking"><div class="toggle1126COn" manual_cm_re = 'DR1126C-_-Challenger-_-toggle on'></div><div class="toggle1126COff" manual_cm_re = 'DR1126C-_-Challenger-_-toggle off'></div></div>`);
}
 
	// Rerun script on device change    
	let utils = window.optimizely.get("utils");
	utils.observeSelector('.device-details-header__brand-name', function () {
		if (utag_obj.page_page_name.startsWith("shop:cfa|tablets|devices|") || utag_obj.page_page_name.startsWith("shop:cfu|tablets|devices|")) {
			executeDR1126C();
		}
	}, {
		"once": false
	});
}
})();