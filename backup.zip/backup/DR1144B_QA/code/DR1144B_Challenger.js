console.log("VMO2AB_Version2 - DR1144B challenger"); // if 360 test

(function () {
	function poll(fn, callback, errback, timeout, interval) {
		var endTime = Number(new Date()) + (timeout || 2000);
		interval = interval || 4000;

		(function p() {
			if (fn()) {
				callback();
			} else if (Number(new Date()) < endTime) {
				setTimeout(p, interval);
			} else {
				errback(new Error(`timed out for ${fn}: ${arguments}`));
			}
		})();
	}

	poll(
		function () {
			return typeof jQuery == "function" && typeof $ == "function";
		},
		function () {
			loadExperience();
		},
		function (err) {
			console.log("error: ", err);
		},
		40000
	);

	function loadExperience() {
		poll(
			function () {
				if (typeof utag_data === "object") {
					let dr1144B_status =
						utag_data.customer_vm_life_cycle_status ||
						utag_data_copy.customer_vm_life_cycle_status;

					let flag = false;
					if (dr1144B_status == "eligible") {
						if (!document.body.querySelector(".onLoadTrackClick1144B")) {
							let onLoadTrackClick1144B = document.createElement("div");
							onLoadTrackClick1144B.className = "onLoadTrackClick1144B";
							onLoadTrackClick1144B.setAttribute(
								"manual_cm_re",
								"DR1144B-_-Challenger-_-onLoad"
							);
							document.body.appendChild(onLoadTrackClick1144B);
							onLoadTrackClick1144B.dispatchEvent(new Event("mousedown"));
						}
					} else {
						flag = true;
					}
					return (
						!!document.body.querySelectorAll(
							"tariff-cards-wrapper .tariff-card"
						).length &&
						(document.body.querySelector(
							".device-plan-tab o2uk-tabs .o2uk-tabs__tab"
						) ||
							document.body
								.querySelector(".o2uk-tabs o2uk-select")
								.getAttribute("aria-label").length) &&
						!document.body.classList.contains("DR1144B")
					);
				}
			},
			function () {
				// Done, success callback
				executeExprience();
			},
			function (err) {
				// Error, failure callback
				console.log("error: ", err);
			},
			2000
		);
	}

	function executeExprience() {
		//console.log("Execute experiment DR1144B XXX");
		document.body.classList.add("DR1144B");

		// Back to top Arrow
		let movetoTopArrow = `
  <div class="movetoTopArrowContainer">
    <span class="movetoTopArrowIcon">
      <o2uk-svg-resolver role="row" class="svg-resolver o2uk-svg-resolver dropdown-chevron ng-star-inserted" aria-hidden="true">
        <div class="o2uk-link-svg o2uk-link-svg_l">
          <span class="o2uk-icon-font icon-chevron-up"></span>
        </div>
        <title></title>
      </o2uk-svg-resolver>
    </span>
    <span class="movetoTopArrow-text">Back to top</span>
  </div>`;

		let movetoTopArrowCount = 0;
		let movetoTopArrowInterval = setInterval(function () {
			let globalFootnote = document.body.querySelector("o2uk-global-footnote");
			if (
				globalFootnote &&
				!document.body.querySelector(".movetoTopArrowContainer")
			) {
				clearInterval(movetoTopArrowInterval);
				globalFootnote
					.closest(".o2uk-container")
					.insertAdjacentHTML("beforebegin", movetoTopArrow);
			} else if (movetoTopArrowCount > 200) {
				clearInterval(movetoTopArrowInterval);
			}
			movetoTopArrowCount++;
		}, 100);

		var scrollObj1144B = OverlayScrollbars(document.body);

		document.addEventListener("mousedown", function (event) {
			console.log("MouseDown event fired");
			let movetoTopArrowContainer = event.target.closest(
				".movetoTopArrowContainer"
			);
			if (movetoTopArrowContainer) {
				scrollObj1144B.scroll({ y: 150, behavior: "smooth" });
			}
		});

		function customizeMyviews() {
			// Function which will execute when we want to the experirnce i.e Phone tab
			//console.log("customizeMyviews DR1144B");

			document.body.classList.add("DR1144BphoneTab");

			let sortAndFilterSortElement = document.querySelectorAll(
				".DR1144BphoneTab .o2uk-sort-and-filter__sort-element"
			);

			let chipsItems = document.querySelectorAll(
				".DR1144BphoneTab .o2uk-chips__item"
			);

			if (sortAndFilterSortElement.length > 0) {
				sortAndFilterSortElement.forEach(function (element) {
					element.classList.add("visibilityHidden");
				});

				if (chipsItems.length === 0) {
					sortAndFilterSortElement.forEach(function (element) {
						element.classList.add("visibilityHidden");
					});
				} else {
					sortAndFilterSortElement.forEach(function (element) {
						element.classList.remove("visibilityHidden");
					});
				}
			}
			// handelling if the other that top picks option is selected on load and on tab change i.e. if the any og the tenure is selected then sort option will be visible

			//***************************----Phone Condition----****************************//

			if (window.innerWidth < 600) {
				//console.log("customizeMyviews Phone condition DR1144B");
			} else {
				//***************************----Desktop Condition----****************************//
				// console.log("customizeMyviews Desktop condition DR1144B");

				if (
					document.body.contains(document.querySelector(".tab1144BContainer"))
				) {
					setTimeout(() => {
						// On tab change we are hiding hence when coming back to the phone we are showing it
						document.querySelector(".tab1144BContainer").style.display = "flex";
					}, 1000);
				}

				// Adding tabs on the screen
				let tabForTenure = document.createElement("div");
				tabForTenure.className = "tab1144BContainer";
				tabForTenure.id = "tab114BCont";
				tabForTenure.innerHTML = `
  <div class="option1144B selectedOption" id="option1_25" manual_cm_re="DR114B-_-Challenger-_-Top picks">Top picks</div>
  <div class="option1144B" id="option2_25" manual_cm_re="DR114B-_-Challenger-_-24 month">24 month</div>
  <div class="option1144B" id="option3_25" manual_cm_re="DR114B-_-Challenger-_-12 month">12 month</div>
  <div class="option1144B" id="option4_25" manual_cm_re="DR114B-_-Challenger-_-30 day">30 day</div>
`;

				let addingTabsCount = 0;
				let addingTabsInt = setInterval(function () {
					if (
						document.body.contains(
							document.querySelector("plan-list-sorting-and-filter")
						) &&
						!document.body.contains(
							document.querySelector(".tab1144BContainer")
						)
					) {
						clearInterval(addingTabsInt);
						//console.log('tabs added DR1144B')
						document
							.querySelector("plan-list-sorting-and-filter")
							.insertAdjacentElement("beforebegin", tabForTenure);
					} else if (addingTabsCount > 1000) {
						clearInterval(addingTabsInt);
					}
					addingTabsCount++;
				}, 100);

				//On load if the tab selected
				let toTrackTabsCount = 0;
				let toTrackChip = setInterval(function () {
					//console.log('Entering to interval');
					let chipsItem = document.querySelector(".o2uk-chips__item");
					let option1144B = document.querySelectorAll(".option1144B");

					if (chipsItem && option1144B.length) {
						clearInterval(toTrackChip);

						if (chipsItem.getAttribute("aria-label").includes("30 Day")) {
							option1144B.forEach((option) =>
								option.classList.remove("selectedOption")
							);
							document
								.querySelector("#option4_25")
								.classList.add("selectedOption");
							document
								.querySelector(".o2uk-sort-and-filter__sort-element")
								.classList.remove("visibilityHidden");
						}

						if (chipsItem.getAttribute("aria-label").includes("12 Month")) {
							option1144B.forEach((option) =>
								option.classList.remove("selectedOption")
							);
							document
								.querySelector("#option3_25")
								.classList.add("selectedOption");
							document
								.querySelector(".o2uk-sort-and-filter__sort-element")
								.classList.remove("visibilityHidden");
						}

						if (chipsItem.getAttribute("aria-label").includes("24 Month")) {
							option1144B.forEach((option) =>
								option.classList.remove("selectedOption")
							);
							document
								.querySelector("#option2_25")
								.classList.add("selectedOption");
							document
								.querySelector(".o2uk-sort-and-filter__sort-element")
								.classList.remove("visibilityHidden");
						}
					} else if (toTrackTabsCount == 100) {
						document
							.querySelector(".o2uk-sort-and-filter__sort-element")
							.classList.add("visibilityHidden");
						clearInterval(toTrackChip);
					}

					toTrackTabsCount++;
				}, 100);

				function handleTabClick(e) {
					console.log("click onhandleTabClick 1144B");
					e.stopPropagation();

					// Remove the 'selectedOption' class from all elements with class 'option1144B'
					document.querySelectorAll(".option1144B").forEach(function (element) {
						element.classList.remove("selectedOption");
					});

					// Show the dropdown panel
					document.querySelector(
						".o2uk-sort-and-filter__sort-element .o2uk-pseudo-dropdown__panel"
					).style.display = "block";

					// Add the 'selectedOption' class to the clicked element
					this.classList.add("selectedOption");

					// Remove the element with id 'newCountDiv1144B' from the body
					const newCountDiv = document.getElementById("newCountDiv1144B");
					if (newCountDiv) {
						newCountDiv.remove();
					}

					if (this.innerHTML === "Top picks") {
						//console.log('click on Top picks 1144B');
						document
							.querySelectorAll(
								".o2uk-sort-and-filter__contract-length-element .o2uk-pseudo-dropdown__trigger"
							)[0]
							.click();

						setTimeout(function () {
							// Select the element with class 'mat-radio-input' and check its 'aria-label' attribute
							const radioInput = document.querySelector(
								'.mat-radio-input[aria-label*="Contract length"]'
							);

							// Check if the element exists and has the 'aria-label' containing 'Contract length'
							if (
								radioInput &&
								radioInput
									.getAttribute("aria-label")
									.includes("Contract length")
							) {
								// Perform a click on the element
								radioInput.click();
							}

							document
								.querySelector(".o2uk-sort-and-filter__sort-element")
								.classList.add("visibilityHidden");

							let option4Counter = 0;
							let option4Int = setInterval(function () {
								const checkboxes = document.querySelectorAll(
									".o2uk-sort-and-filter__filter-element .mat-checkbox p"
								);

								for (const checkbox of checkboxes) {
									if (checkbox.textContent.includes("Contract length")) {
										checkbox.click();
										clearInterval(option4Int);
										return;
									}
								}

								if (option4Counter >= 150) {
									clearInterval(option4Int);
								}
								option4Counter++;
							}, 100);
						}, 800);
					}

					if (this.innerHTML === "24 month") {
						//console.log('click on 24 month 1144B');
						if (document.body.querySelector(".o2uk-chips__item_remove-btn")) {
							document.body
								.querySelector(".o2uk-chips__item_remove-btn")
								.click();
						}

						setTimeout(function () {
							document
								.querySelectorAll(
									".o2uk-sort-and-filter__contract-length-element .o2uk-pseudo-dropdown__trigger"
								)[0]
								.click();
							// Select the element with class 'mat-radio-input' and check its 'aria-label' attribute
							const radioInput = document.querySelector(
								'.mat-radio-input[aria-label*="24 Month"]'
							);

							// Check if the element exists and has the 'aria-label' containing '24 Month'
							if (
								radioInput &&
								radioInput.getAttribute("aria-label").includes("24 Month")
							) {
								// Perform a click on the element
								radioInput.click();
							}

							document
								.querySelector(".o2uk-sort-and-filter__sort-element")
								.classList.remove("visibilityHidden");

							let option4Counter = 0;
							let option4Int = setInterval(function () {
								const checkboxes = document.querySelectorAll(
									".o2uk-sort-and-filter__filter-element .mat-checkbox p"
								);

								for (const checkbox of checkboxes) {
									if (checkbox.textContent.includes("24 Month")) {
										checkbox.click();
										clearInterval(option4Int);
										return;
									}
								}

								if (option4Counter >= 150) {
									clearInterval(option4Int);
								}
								option4Counter++;
							}, 100);
						}, 800);
					}

					if (this.innerHTML === "12 month") {
						//console.log('click on 12 month 1144B');
						if (document.body.querySelector(".o2uk-chips__item_remove-btn")) {
							document.body
								.querySelector(".o2uk-chips__item_remove-btn")
								.click();
						}

						setTimeout(function () {
							document
								.querySelectorAll(
									".o2uk-sort-and-filter__contract-length-element .o2uk-pseudo-dropdown__trigger"
								)[0]
								.click();

							const radioInput = document.querySelector(
								'.mat-radio-input[aria-label*="12 Month"]'
							);
							if (
								radioInput &&
								radioInput.getAttribute("aria-label").includes("12 Month")
							) {
								radioInput.click();
							}
							document
								.querySelector(".o2uk-sort-and-filter__sort-element")
								.classList.remove("visibilityHidden");

							let option4Counter = 0;
							let option4Int = setInterval(function () {
								const checkboxes = document.querySelectorAll(
									".o2uk-sort-and-filter__filter-element .mat-checkbox p"
								);

								for (const checkbox of checkboxes) {
									if (checkbox.textContent.includes("12 Month")) {
										checkbox.click();
										clearInterval(option4Int);
										return;
									}
								}

								if (option4Counter >= 150) {
									clearInterval(option4Int);
								}
								option4Counter++;
							}, 100);
						}, 800);
					}
					if (this.innerHTML === "30 day") {
						//console.log('click on 30 Day 1144B');
						if (document.body.querySelector(".o2uk-chips__item_remove-btn")) {
							document.body
								.querySelector(".o2uk-chips__item_remove-btn")
								.click();
						}

						document
							.querySelectorAll(
								".o2uk-sort-and-filter__contract-length-element .o2uk-pseudo-dropdown__trigger"
							)[0]
							.click();

						setTimeout(function () {
							const radioInput = document.querySelector(
								'.mat-radio-input[aria-label*="30 Day"]'
							);
							if (
								radioInput &&
								radioInput.getAttribute("aria-label").includes("30 Day")
							) {
								radioInput.click();
							}
							document
								.querySelector(".o2uk-sort-and-filter__sort-element")
								.classList.remove("visibilityHidden");

							let option4Counter = 0;
							let option4Int = setInterval(function () {
								const checkboxes = document.querySelectorAll(
									".o2uk-sort-and-filter__filter-element .mat-checkbox p"
								);

								for (const checkbox of checkboxes) {
									if (checkbox.textContent.includes("30 Day")) {
										checkbox.click();
										clearInterval(option4Int);
										return;
									}
								}

								if (option4Counter >= 150) {
									clearInterval(option4Int);
								}
								option4Counter++;
							}, 100);
						}, 800);
					}
				}

				document.removeEventListener("click", handleTabClick); // Remove existing click event listener
				document.addEventListener("click", function (event) {
					if (event.target.classList.contains("option1144B")) {
						console.log(event.target, "Event target xxx");
						handleTabClick.call(event.target, event);
					}
				});
			}

			//-------Common functions below--------------------------------
		}
		//------------------------------------------------------------------------------------------------
		function toRemoveMyViews() {
			console.log("toRemoveMyViews DR1144B");

			// Remove the class 'DR1144BphoneTab' from the body
			document.body.classList.remove("DR1144BphoneTab");

			// Add the class 'hideThisTile' to elements with the class 'o2uk-notification-message'

			// Remove the class 'visibilityHidden' from elements with the class 'o2uk-sort-and-filter__sort-element'
			document
				.querySelectorAll(".o2uk-sort-and-filter__sort-element")
				.forEach((element) => {
					element.classList.remove("visibilityHidden");
				});

			// Set the visibility property of elements with the class 'o2uk-sort-and-filter__count' to 'visible'
			document
				.querySelectorAll(".o2uk-sort-and-filter__count")
				.forEach((element) => {
					element.style.visibility = "visible";
				});

			// Show the last element with the class 'o2uk-expansion-panel' under elements with the class 'o2uk-sort-and-filter__filter-element'
			document
				.querySelectorAll(
					".o2uk-sort-and-filter__filter-element .o2uk-expansion-panel"
				)
				.forEach((element) => {
					element.style.display = "block";
				});

			// Get all elements with the class 'tab1144BContainer' and hide them
			document.querySelectorAll(".tab1144BContainer").forEach((element) => {
				element.style.display = "none";
			});

			document.querySelectorAll(".o2uk-chips__item").forEach((element) => {
				element.classList.remove("visibilityHidden");
			});
			// console.log("toRemoveMyViews DR1144B End");
		}

		// window.customizeMyviewsFunction = customizeMyviews;
		// window.toRemoveMyViewsFunction = toRemoveMyViews;

		// tracking
		if (!document.querySelector("body .trackingFor_featured")) {
			const body = document.querySelector("body");

			const trackingDivs = [
				"<div class='testClick trackingFor_featured' manual_cm_re='DR1144B-_-Challenger-_-Top picks'></div>",
				"<div class='testClick trackingFor_30day' manual_cm_re='DR1144B-_-Challenger-_-30day'></div>",
				"<div class='testClick trackingFor_24months' manual_cm_re='DR1144B-_-Challenger-_-24months'></div>",
				"<div class='testClick trackingFor_12months' manual_cm_re='DR1144B-_-Challenger-_-12months'></div>",
			];

			trackingDivs.forEach((div) => {
				body.insertAdjacentHTML("beforeend", div);
			});
		}

		// On load condition is phone
		if (
			window.location.href.includes("tab=phone") ||
			(document.querySelector(".device-plan-tab o2uk-tabs .o2uk-tabs__tab") &&
				document
					.querySelector(".device-plan-tab o2uk-tabs .o2uk-tabs__tab")
					.classList.contains("active")) ||
			(document.querySelector(".o2uk-tabs o2uk-select") &&
				document
					.querySelector(".o2uk-tabs o2uk-select")
					.getAttribute("aria-label") == "Phones")
		) {
			console.log("Condition is phone DR1144B");
			sessionStorage.setItem("hasOtherTabCLicked", 0);
			//movingRoamBoxFunction();
			customizeMyviews();
			// if (window.innerWidth < 600) {
			//   let sortElement = document.querySelectorAll('.o2uk-sort-and-filter__sort-element');
			//   sortElement.forEach(function (element) {
			//     element.classList.add('visibilityHidden');
			//   });
			// }
		}
		console.log("I am coming here 11111...");

		// clicked on phone tab
		document
			.querySelectorAll('.o2uk-tabs__tab[aria-label="Phones"]')
			.forEach(function (tab) {
				tab.addEventListener("click", function () {
					sessionStorage.setItem("hasOtherTabCLicked", 0);
					let filterElement = document.querySelector(
						".o2uk-sort-and-filter__filter-element .o2uk-filter__selected-options"
					);
					if (filterElement) {
						filterElement.textContent = "0 filters applied";
					}
					//console.log('clicked on phone tab');
					customizeMyviews();
					// console.log('%c Clicked on tabs', 'font-size:13px; background:#000; color:#333;');
				});
			});

		//clicked on Other tabs
		document
			.querySelectorAll(
				'.o2uk-tabs__tab[aria-label="Tablets"], .o2uk-tabs__tab[aria-label="Smartwatches"], .o2uk-tabs__tab[aria-label="Mobile broadband"]'
			)
			.forEach(function (tab) {
				tab.addEventListener("click", function () {
					sessionStorage.setItem("hasOtherTabCLicked", 1);
					const removebtn = document.querySelector("#clickOption1");
					if (removebtn) {
						removebtn.classList.add("active");
					}
					document.querySelectorAll(".option1144B").forEach(function (option) {
						option.classList.remove("selectedOption");
					});
					document.querySelector("#option1_25").classList.add("selectedOption");
					toRemoveMyViews();
					console.log(
						"%c Clicked on tabs",
						"font-size:13px; background:#000; color:#333;"
					);
				});
			});

		// console.log('I am coming here...');

		if (window.innerWidth < 600) {
			document.addEventListener("touchstart", function (e) {
				console.log("Clicked on dropdown in phone dimension");
				const clickedOption = e.target.closest(".DR1144BphoneTab .o2uk-option");
				const clickedOption1 = e.target.closest(
					".DR1144BphoneTab .mat-radio-button"
				);

				if (clickedOption) {
					console.log(
						'Clicked on an element containing "clickedOption" DR1144B'
					);

					const optionContent = clickedOption.querySelector(
						".o2uk-option-content"
					);

					if (optionContent && optionContent.textContent.includes("Phones")) {
						// Your logic here
						// console.log('Clicked on an element containing "Phones" DR1144B');
						sessionStorage.setItem("hasOtherTabCLicked", 0);
						//movingRoamBoxFunction();
						customizeMyviews();
					} else {
						// console.log('Clicked on an element containing "Else" DR1144B');
						sessionStorage.setItem("hasOtherTabCLicked", 1);
						toRemoveMyViews();
					}
				}
				if (clickedOption1) {
					console.log(
						'Clicked on an element containing "clickedOption1" DR1144B'
					);
					const optionContent1 = clickedOption1.querySelector(
						".mat-radio-label-content"
					);

					if (optionContent1.textContent.includes("Featured")) {
						// Your logic here
						console.log('Clicked on an element containing "Featured" DR1144B');
						let sortElement = document.querySelectorAll(
							".o2uk-sort-and-filter__sort-element"
						);
						sortElement.forEach(function (element) {
							element.classList.add("visibilityHidden");
						});

						document.querySelector(".trackingFor_featured").click();
					} else {
						console.log(
							'Clicked on an element containing "Featured Else" DR1144B'
						);
						let sortElement = document.querySelectorAll(
							".o2uk-sort-and-filter__sort-element"
						);
						sortElement.forEach(function (element) {
							element.classList.remove("visibilityHidden");
						});
						if (optionContent1.textContent.includes("24 Month")) {
							document.querySelector(".trackingFor_24months").click();
						}
						if (optionContent1.textContent.includes("12 Month")) {
							document.querySelector(".trackingFor_12months").click();
						}
						if (optionContent1.textContent.includes("30 Day")) {
							document.querySelector(".trackingFor_30day").click();
						}
					}
				}
			});
		}
	}
})();
