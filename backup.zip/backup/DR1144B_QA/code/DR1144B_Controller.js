console.log("VMO2AB_Version2 - DR1144B Controller");
(function () {
    function poll(fn, callback, errback, timeout, interval) {
        var endTime = Number(new Date()) + (timeout || 2000);
        interval = interval || 4000;
        (function p() {
            // If the condition is met, we're done! 
            if (fn()) {
                callback();
            }
            // If the condition isn't met but the timeout hasn't elapsed, go again
            else if (Number(new Date()) < endTime) {
                setTimeout(p, interval);
            }
            // Didn't match and too much time, reject!
            else {
                errback(new Error('timed out for ' + fn + ': ' + arguments));
            }
        })();
    }
    poll(
        function () {
            return typeof jQuery == "function" && typeof $ == "function";
        },
        function () {
            // Done, success callback
            loadExperience();
        },
        function (err) {
            // Error, failure callback
            console.log("error: ", err);
        },
        40000
    );

    function loadExperience() {
        poll(
            function () {
                if (typeof utag_data === 'object') {
                    let dr1144B_status = utag_data.customer_vm_life_cycle_status ? utag_data.customer_vm_life_cycle_status : utag_data_copy.customer_vm_life_cycle_status;
                    let flag = false;
                    if (dr1144B_status == 'eligible') {
                        if (!$("body").find(".onLoadTrackClick1144").length) {
                            $("body").append('<div class="onLoadTrackClick1144" manual_cm_re = "DR1144B-_-Controller-_-onLoad">');
                            $("body").find(".onLoadTrackClick1144").trigger('mousedown');
                        }
                        //((!(dr1144B_status == 'eligible')) || dr1144B_status == 'undefined')
                    }
                    else {
                        flag = true;
                    }

                    return !!$('.o2uk-sort-and-filter__filter-element .o2uk-expansion-panel').last().length && !$('body').find('.DR1144B').length && flag;
                }
            },
            function () {
                // Done, success callback
                executeExprience();
            },
            function (err) {
                // Error, failure callback
                console.log("error: ", err);
            }
        );
    }

    function executeExprience() {
        $('body').addClass('DR1144B');


        if (!$('body').find('.controllerClick').length) {
            $('body').append(`<div class='controllerClick trackingFor_Featured' manual_cm_re = 'DR1144B-_-Controller-_-Featured'></div>
            <div class='controllerClick trackingFor_30day' manual_cm_re = 'DR1144B-_-Controller-_-30day'></div>
            <div class='controllerClick trackingFor_24months' manual_cm_re = 'DR1144B-_-Controller-_-24months'></div>
            <div class='controllerClick trackingFor_12months' manual_cm_re = 'DR1144B-_-Controller-_-12months'></div>`);
        }


        // function handleClickTrackings(event) {
        //     event.preventDefault();
        //     console.log(event, "Event from handleClickTrackings");
        //     if ((window.location.href.includes('tab=phone') || $('body').find('.device-plan-tab o2uk-tabs .o2uk-tabs__tab').first().hasClass('active') || $('body').find('.o2uk-tabs o2uk-select').attr('aria-label') == 'Phones')) {
        //         $('.toTrackClick1144').trigger('click',function (e) {
        //             console.log(e,'Clicked on filter', e.target.classList);
        //         });

        //     }
        // }

        // $(document).on("click", ".o2uk-sort-and-filter__contract-length-element", handleClickTrackings);



        $('.o2uk-sort-and-filter__contract-length-element .o2uk-pseudo-dropdown__panel').on("click", function (event) {
            // console.log('1144 clicked on header', event.target);
            setTimeout(function () {
                // console.log('getting clicked 1144', this);

                if ($(event.target).text().indexOf('Featured') >= 0 || $(event.target).find('.mat-radio-label-content').text().indexOf('Featured') >= 0) {
                    // console.log('1144 121212 clicked Featured QWE');
                    if ((window.location.href.includes('tab=phone') || $('body').find('.device-plan-tab o2uk-tabs .o2uk-tabs__tab').first().hasClass('active') || $('body').find('.o2uk-tabs o2uk-select').attr('aria-label') == 'Phones')) {
                        $('.trackingFor_Featured').trigger('click');
                    }
                }

                if ($(event.target).text().indexOf('30 Day') >= 0 || $(event.target).find('.mat-radio-label-content').text().indexOf('30 Day') >= 0) {
                    // console.log('1144 121212 clicked 30 QWE');
                    if ((window.location.href.includes('tab=phone') || $('body').find('.device-plan-tab o2uk-tabs .o2uk-tabs__tab').first().hasClass('active') || $('body').find('.o2uk-tabs o2uk-select').attr('aria-label') == 'Phones')) {
                        $('.trackingFor_30day').trigger('click');
                    }
                }
                if ($(event.target).text().indexOf('12 Month') >= 0 || $(event.target).find('.mat-radio-label-content').text().indexOf('12 Month') >= 0) {
                    // console.log('1144 1212121 clicked 12 QWE');
                    if ((window.location.href.includes('tab=phone') || $('body').find('.device-plan-tab o2uk-tabs .o2uk-tabs__tab').first().hasClass('active') || $('body').find('.o2uk-tabs o2uk-select').attr('aria-label') == 'Phones')) {
                        $('.trackingFor_12months').trigger('click');
                    }
                }
                if ($(event.target).text().indexOf('24 Month') >= 0 || $(event.target).find('.mat-radio-label-content').text().indexOf('24 Month') >= 0) {
                    // console.log('1144 1212121 clicked 24 QWE');
                    if ((window.location.href.includes('tab=phone') || $('body').find('.device-plan-tab o2uk-tabs .o2uk-tabs__tab').first().hasClass('active') || $('body').find('.o2uk-tabs o2uk-select').attr('aria-label') == 'Phones')) {
                        $('.trackingFor_24months').trigger('click');
                    }
                }
            }, 500);
        });
    }
})();