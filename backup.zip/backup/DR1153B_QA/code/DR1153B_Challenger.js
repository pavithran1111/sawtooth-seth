console.log("DR1153B challenger"); // if legacy test
// console.log("VMO2AB_Version2 - DR1153B challenger"); // if 360 test
(function () {
    let experimentID = '28185800405';
    function loadGlassbox() {
        try {
            _detector.triggerABTestingEvent(
                'Optimizely',
                experimentID,
                'Live_DR1153B',
                '24104221017',
                'Exp B'
            );
        } catch (error) {
            console.log(error.message);
        }
    }
    loadGlassbox();
    function GA4Integration() {
        if (typeof gtag !== "undefined") {
            gtag('event', 'optimizely_campaign', {
                'optimizely_experiment': experimentID,
                'optimizely_experiment_name': "DR1153B Tariff filters on PDP",
                'optimizely_variant_name': "DR1153B Exp B"
            });
        }
    }
    GA4Integration();


    function poll(fn, callback, errback, timeout, interval) {
        var endTime = Number(new Date()) + (timeout || 8000);
        interval = interval || 100;
        (function p() {
            // If the condition is met, we're done! 
            if (fn()) {
                callback();
            }
            // If the condition isn't met but the timeout hasn't elapsed, go again
            else if (Number(new Date()) < endTime) {
                setTimeout(p, interval);
            }
            // Didn't match and too much time, reject!
            else {
                errback(new Error('timed out for ' + fn + ': ' + arguments));
            }
        })();
    }
    poll(
        function () {
            return typeof jQuery == "function" && typeof $ == "function";
        },
        function () {
            // Done, success callback
            loadExperience();
        },
        function (err) {
            // Error, failure callback
            console.log("error: ", err);
        },
        40000
    );

    function loadExperience() {
        let isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
        poll(
            function () {
                return !!isMobile && $('o2uk-sort-and-filter-wrapper').length && !$('body').hasClass('DR1153B').length

            },
            function () {
                // Done, success callback
                executeExprience();

            },
            function (err) {
                // Error, failure callback
                console.log("error: ", err);
            }
        );
    }

    function executeExprience() {
        console.log("1153B Should be Executing");
        $('body').addClass('DR1153B');
        $('body').find('.addHeight').remove();
        $('body').find('.addtoObserve').remove();

        let rpiBannerIsPresent = $('body').find('.DR1198-static-bar').length;
        let divHeight = $('body').find('o2uk-sort-and-filter-wrapper').height();
        let addHeightDiv = `<div class="addHeight" style="height:0px"></div>`;
        let addtoObserveDiv = `<div class="addtoObserve"></div>`;












        let count11153B = 0;
        const interval1153 = setInterval(() => {
            if ($('.o2uk-buble-loader_fade-out').length) {
                !$('body').find('.addHeight').length ? $('o2uk-sort-and-filter-wrapper').after(addHeightDiv) : 0;
                !$('body').find('.addtoObserve').length ? $('o2uk-sort-and-filter-wrapper').before(addtoObserveDiv) : 0;

                console.log('addHeightDiv length 1153B: ', $('body').find('.addHeight').length);
                console.log('addtoObserve length 1153B: ', $('body').find('.addtoObserve').length);

                const sectionOne = document.querySelector('.addtoObserve');
                const sectionFooter = document.querySelector('.footer-content-global');

                const options = {
                    root: null,
                    threshold: 0,
                    rootMargin: "0px"
                };

                const observer = new IntersectionObserver(function (entries, observer) {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            $('o2uk-sort-and-filter-wrapper').removeClass('fixedTopFilter fixedTopFilterwithRPI');
                            $('body').find('.addHeight').attr('style', 'height:0px');
                        }
                        if (!entry.isIntersecting && entry.boundingClientRect.top < 0) {
                            $('body').find('.addHeight').attr('style', `height:${divHeight}px`);
                            $('o2uk-sort-and-filter-wrapper').addClass(rpiBannerIsPresent ? 'fixedTopFilterwithRPI' : 'fixedTopFilter');
                        }
                    });
                }, options);

                const observer2 = new IntersectionObserver(function (entries, observer) {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            $('o2uk-sort-and-filter-wrapper').css('display', 'none');
                        }
                        if (!entry.isIntersecting) {
                            $('o2uk-sort-and-filter-wrapper').css('display', 'block');
                        }
                    });
                }, options);

                observer.observe(sectionOne);
                observer2.observe(sectionFooter);
                clearInterval(interval1153);
            }
            else if (++count11153B > 200) {
                clearInterval(interval1153);
            }
        }, 100);




        //             if (scrollObj.scroll().position.y > 600 && (!$('.fixedTopFilter').length || !$('.fixedTopFilterwithRPI').length)) {
        //                 !$('body').find('.addHeight').length ? $('o2uk-sort-and-filter-wrapper').before(addHeightDiv) : 0;
        //                 $('o2uk-sort-and-filter-wrapper').addClass(rpiBannerIsPresent ? 'fixedTopFilterwithRPI' : 'fixedTopFilter');
        //             } else if (scrollObj.scroll().position.y < 600 && ($('.fixedTopFilter').length || $('.fixedTopFilterwithRPI').length)) {
        //                 $('o2uk-sort-and-filter-wrapper').removeClass('fixedTopFilter');
        //                 $('o2uk-sort-and-filter-wrapper').removeClass('fixedTopFilterwithRPI');
        //                 $('body').find('.addHeight').remove();
        //             }

    }
})();