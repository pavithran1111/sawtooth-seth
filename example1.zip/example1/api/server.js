// import express from 'express';
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');

const dBConfig  = require('./config/database.config.js');
const app = express();

app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());
app.use(cors());

mongoose.Promise = global.Promise;

//Connecting to the database
mongoose.connect(dBConfig.url, {useNewUrlParser:true})
  .then(()=>{
    console.log('Database Connected Successfully');
  }).catch((err)=>{
    console.log('Error occured exiting!', err);
    process.exit();
  });

app.get('/', (req, res)=>{
  res.json({"message":"Welcome to Employee"})
});

require('./mvc/routes/routes.js')(app);

app.listen(3001,() => {
  console.log("Server is listening on post 3001");
});