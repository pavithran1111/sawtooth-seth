
module.exports = (app) => {
  const employee = require('../controller/controller.js');

  //Retrieve All Employee
  app.get('/employee', employee.getAllDetails);

  //Get One Employee
  app.get('/employee/:id', employee.getOneEmployee);
  
  //Create new Employee
  app.post('/employee', employee.add);

  //Edit an Employee
  app.patch('/edit/:id', employee.updateEmployee);

  //Delete an Employee
  app.delete('/delete/:id', employee.deleteEmployee);
}
