'use strict';
const mongoose = require('mongoose');
require('../model/model.js');
const Employee = mongoose.model('employee');

//Add employee to the database
exports.add = (req, res) => {
  console.log('testing')
  const Emp = new Employee(req.body);
  Emp.save((err, data)=>{
    if(err){
      res.send(err)
    }
    res.json(data)
  });
}

//Retrieve all employee from the database
exports.getAllDetails = (req, res) => {
  Employee.find({}, (err, data)=>{
    if(err){
      res.send(err)
    }
    res.json(data)
  });
}

//One employee from the database
exports.getOneEmployee = (req, res) => {
  Employee.find({_id:req.params.id}, (err, data)=>{
    if(err){
      res.send(err)
    }
    res.json(data)
  });
}

//Edit an employee to the database
exports.updateEmployee = (req, res) => {
  Employee.findByIdAndUpdate(req.params.id, req.body,{runValidators: true}, (err, data)=>{
    if(err)
      res.send(err)
    res.json(data);
  });
}

//Delete an employee from the database
exports.deleteEmployee = (req, res) => {
  console.log(req.params.id)
  Employee.findByIdAndDelete(req.params.id, (err, data)=>{
    if(err)
      res.send(err);
  res.json(data);
  })
}