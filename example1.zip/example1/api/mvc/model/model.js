const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const employee = new Schema({
  name: {
    type: String
  },
  created_date: {
    type: Date,
    default: Date.now
  }
});

const collection1 = mongoose.model('employee', employee) 
module.export = { collection1 }