import React, {useContext} from "react";
import {Color, Size} from "./A";
import {AppContext} from './context';
const C = ()=>{
  const data = useContext(AppContext);
  return(<div>{data}
    <Color.Consumer>
      {(a)=>{
        return (<Size.Consumer>{
          (b)=>{
            return (<div>{a} {b}</div>)
          }
          }
        </Size.Consumer>)
      }}
    </Color.Consumer>
  </div>)
}

export default C;