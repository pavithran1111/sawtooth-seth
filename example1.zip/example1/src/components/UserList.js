import { useEffect, useState } from "react";
import axios from "axios";

function UserList() {
    const [userList, setUserList] = useState([]);

    useEffect(()=>{
      const fetchUserList = async() =>{
          try{
              await axios.get("https://jsonplaceholder.typicode.com/users").then((res) => setUserList(res.data))
          } catch(err) {
              console.log(err)
          }
      }

      fetchUserList()
    },[])

    return (
        <div className="middle">
            <h2>Users</h2>
            <p data-testid="home">Home</p>
            {
                userList.map((user)=>{
                    return(
                        <div key={user.id} className="row">
                            <p>{user.name}</p>
                            <p>{user.email}</p>
                        </div>
                    )
                })
            }
        </div>
    )
}

export default UserList