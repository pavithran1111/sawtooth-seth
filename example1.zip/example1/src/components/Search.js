
const Search=({ onChange})=>{
  console.log('Search child component', onChange);
  return (          
  <input type="text" onChange={(e)=>onChange(e.target.value)} />
  )
}

export default Search;