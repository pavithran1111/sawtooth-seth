import React from "react";
import C from "./C";

const B = ()=>{
  return(<div><C /></div>)
}

export default B;