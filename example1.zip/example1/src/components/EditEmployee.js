import React, {useEffect, useState} from "react";
import EditBookForm from "./EditBookForm";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import axios from 'axios';

const EditEmployee = () => {
  const navigate = useNavigate()
  const [data, setData] = useState()
  const { register, formState: { errors },  handleSubmit, reset } = useForm({defaultValues: data});

  const [id, setId] = useState(()=> window.location.href.substring(window.location.href.lastIndexOf('/')).replace('/',''))

  const fetchData = async () => {
    const res = await axios.get(`http://localhost:3001/employee/${id}`);
    console.log(res.data[0])
    setData(res.data[0]);
  }

  useEffect(()=>{
    fetchData()
  }, [])

  return (
    data ? <EditBookForm preloadedValues={data} id={id} />   : <div>Loading</div>
  )
}

export default EditEmployee;