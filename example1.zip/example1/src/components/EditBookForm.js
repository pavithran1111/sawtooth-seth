import React, {useState} from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import {motion} from "framer-motion";

function EditEmpForm({preloadedValues, id}) {
  const [error, setError] = useState('')
  const navigate = useNavigate()
  const { register, formState: { errors }, handleSubmit, reset } = useForm({defaultValues: preloadedValues});

  const onSubmit = async data => {
    console.log(data)
    const res = await axios.patch(`http://localhost:3001/edit/${id}`, data);

    if(res === 11000 ){
      setError('The name of the Emp is already available')
    }
    else {
      navigate('/employee', { replace: true });
      reset();
    }
  }

  const handleChange = () => {
    setError('Error')
  }

  return (
    <motion.div initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    exit={{ opacity: 0 }}
    transition={{ duration: .5 }}>
      <h1>Edit Employee</h1>
      <form onSubmit={handleSubmit(onSubmit)}>
        <label>Name</label>
        <input type="text" {...register('name', {required: true})} />
        {errors.name?.type === 'required' && <span>Name is required{`${error}`}</span>}
        <button type="submit">Add</button>
      </form>
    </motion.div>
  );
}

export default EditEmpForm;