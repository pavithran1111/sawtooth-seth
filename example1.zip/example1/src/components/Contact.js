import {motion} from 'framer-motion';
import { useEffect, useState } from 'react';
const Contact = () => {
  const [count, setCount] = useState(0);
  const [obj, setObj] = useState({name1:'', email:'', number:''});
  useEffect(()=>{
    const interval = setInterval(()=>{
      setCount(count+1);
    }, 1000);
    return ()=>{
      clearInterval(interval);
    }
  }, [count]);

  const handleChange = (e) =>{
    console.log(e.target.value);
    console.log(e.target.name);
    setObj({...obj, name1:e.target.value});
    console.log(obj)
  }

  const handleClick = (e) =>{
    console.log(e.target.value)
  }

  return (
    <motion.div className='middle' initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    exit={{ opacity: 0 }}
    transition={{ duration: .5 }}>
      Contact Us
      <h1>{count}</h1>
      <><input type="text" name="name1" onChange={handleChange} /><button onClick={handleClick}>Add data</button></>
    </motion.div>
  )
}

export default Contact;