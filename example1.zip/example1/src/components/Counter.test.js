import {render, fireEvent} from '@testing-library/react';
import Counter from './Counter';

describe(Counter, ()=>{
  it('Is the initial value count is zero', ()=>{
    const { getByTestId } = render(<Counter initialCount={0} />);
    const countValue = Number(getByTestId("count").textContent);
    expect(countValue).toEqual(0);
  });

  it('To check the increment button works fine', ()=>{
    const { getByTestId, getByRole } = render(<Counter initialCount={0} />);
    const incrementBtn = getByRole("button", {name: "Increment"});
    fireEvent.click(incrementBtn);
    const countValue = Number(getByTestId("count").textContent);
    expect(countValue).toEqual(1);
  });

  it('To check the decrement button works fine', ()=>{
    const { getByTestId, getByRole } = render(<Counter initialCount={0} />);
    const decrementBtn = getByRole("button", {name: "Decrement"});
    fireEvent.click(decrementBtn);
    const countValue = Number(getByTestId("count").textContent);
    expect(countValue).toEqual(-1);
  });

  it('Check that restart button works fine', ()=>{
    const {getByTestId, getByRole} = render(<Counter initialCount={10} />);
    const restartBtn = getByRole("button", {name: "Restart"});
    fireEvent.click(restartBtn);
    const countValue = Number(getByTestId("count").textContent);
    expect(countValue).toEqual(0);
  });

  // it('Check the sign changes on click switch', ()=>{
  //   const {getByTestId, getByRole} = render(<Counter initialCount={50} />);
  //   const switchSign = getByRole('button', {name: "SwitchSign"});
  //   fireEvent.click(switchSign);
  //   const countValue = Number(getByTestId("count").textContent);
  //   expect(countValue).toEqual(-50);
  // })
});