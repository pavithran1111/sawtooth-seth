import React, { useReducer } from "react"

function reducer(state, action){

  const {type} = action;
  switch(type){
    case 'increment': {
      const newCount = state.count+1;
      const hasError = newCount>5;
      return {...state, count:hasError?state.count:newCount, error:hasError?"Reached maximum count":null}
    }
    case 'decrement': {
      const newCount = state.count-1;
      const hasError = newCount<0;
      return {...state, count:hasError?state.count:newCount, error:hasError?"Reach minimum count":null}
    }
    default:
      return state;
  }
}

const DemoReducer = ()=>{

  const[state, dispatch] = useReducer(reducer, {
    count: 0,
    error:null
  });
  return (<div className="middle"><div>Count {state.count}</div>
    {state.error && <div>{state.error}</div>}
    <button onClick={()=> dispatch({type:"increment"})}>Increment</button>
    <button onClick={()=> dispatch({type:"decrement"})}>Decrement</button>
  </div>)

}

export default DemoReducer;