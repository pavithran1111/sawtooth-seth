import { useEffect, useState } from "react";
import axios from 'axios';
const FollowerList = ()=>{
  const [followList, setFollowList] = useState([]);

  useEffect(()=>{
    fetchData();
  }, []);

  const fetchData = async()=>{
    const {data} = await axios.get('https://randomuser.me/api/?results=5')
    console.log(data.results)
    setFollowList(data.results)
    // fetch('https://randomuser.me/api/?results=5').then((data)=>{
    //   return data.json();
    // }).then((res)=>{
    //   setData(res);
    // }).catch((err)=>{
    //   console.log(err.message);
    // })
  }


  return(<div className="middle">
    {followList && followList.map((item, index)=>{
      return <p key={index}>{item.gender} {item.email}</p>
    })}
  </div>)

}

export default FollowerList;