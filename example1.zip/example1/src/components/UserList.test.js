//https://dev.to/nachothegre8t/mocking-axios-get-requests-a-practical-guide-for-reliable-react-testing-using-jest-3kik
import { render, waitFor, screen } from "@testing-library/react";
import axios from "axios";
import UserList from "./UserList";
//mock the axios module
jest.mock('axios');

const dummyUserList = [
    {
      userId: 1,
      id: 1,
      name: "Nacho",
      email: "nacho@gmail.com"
    },
    {
      userId: 1,
      id: 2,
      name: "Nochi",
      email: "nochi@gmail.com"
    },
    {
      userId: 1,
      id: 3,
      name: "Davidszn",
      email: "david@gmail.com"
    },
  ];

describe('User Component', ()=>{
    it('should render user render', async()=>{
        render(<UserList />);
        await waitFor(()=>{
            expect(screen.getByText(/users/i)).toBeInTheDocument();
        });
    });

    // if('Should contain first row as certain text', ()=>{
    //     const { getByTestId} = render(<UserList />);
    //     const value = getByTestId("home").textContent;
    //     expect(value).toHaveTextContent("Hone");
    // })

    it("should render user list after fetching list", async ()=>{
        //resolving the get request with the dummyUserList
        axios.get.mockResolvedValue({ data: dummyUserList });
    
        // or you could use the following depending on your use case:
        // axios.get.mockImplementation(() => Promise.resolve(dummyUserList))
    
        render(<UserList/>)
        //another alternative to wait for block is findby queries
        expect(await screen.findByText(/nacho@gmail.com/i)).toBeInTheDocument()
    
        // Optionally, you can check for the number of calls to axios.get
        expect(axios.get).toHaveBeenCalledTimes(1);
      })

})