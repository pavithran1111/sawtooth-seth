import React, { useState } from "react";
import { useForm } from "react-hook-form";
import {motion} from "framer-motion";

const Todo = () => {
  const { register,  handleSubmit, reset } = useForm();
  const [result, setResult] = useState([]);
  const onSubmit = (data) => {
    // setResult(prevData =>[...prevData, data.todo]);
    setResult(prevData => [...prevData, { todo:data.todo }]);
    console.log(result)
    reset({todo:''})
  }

  const handleRemove = id => {
    const newResult = [...result]
    newResult.splice(id, 1)
    //result.splice(id, 1)
    // setResult([...result])
    setResult(newResult)
  }

  return (
    <div className="container">
    <div className="content-container">
    <motion.div initial={{ x: -550 }}
    animate={{ x: 0 }}
    exit={{ x: 550 }}
    transition={{ duration: .3, ease:"easeIn" }}>

      <h1 className="heading">Todo Listing</h1>
      <form onSubmit={handleSubmit(onSubmit)}>
        <input type="text" {...register('todo', {required: true})} />
        <button>Add</button>
      </form>
    
      <div className="content-container content-result">
      {result && Object.keys(result).length ? <div className="content-todo">
        {/* {result.map( (e, index) =>
          <div key={index} className="todo-list">
            <div>{ e }</div>
            <div onClick={()=>handleClose(index)} className="close">X</div>
          </div>
        )} */}
        {Object.keys(result).map( index =>
          <div key={index} className="todo-list">
            <div>{ result[index].todo }</div>
            <div onClick={()=>handleRemove(index)} className="close">X</div>
          </div>
        )}
      </div>:<div>No todo list</div>}
      </div>
      </motion.div>
    </div>
    </div>
  )
}

export default Todo;