import React, { useEffect } from "react";

const First = ()=>{

  useEffect(()=>{
    for(let i=0; i<1000000000; i++){

    }
  }, [])

  return(<div>First</div>)
}

export default First;