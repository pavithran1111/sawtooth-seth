import { useEffect, useState } from "react";

const deBouncing = (func, delay)=>{
  console.log('debouncing', delay)
  let timerId;
  return function(){
    const context = this;
    const args = arguments;
    clearTimeout(timerId);
    timerId = setTimeout(function(){
      func.apply(context, args)
    }, delay);
  }
}

const UseFetch = ({url}) => {
  const [data, setData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [input, setInput] = useState("");
  useEffect(()=>{
    fetch(url).then((res1)=> res1.json()).then((data)=> setData(data));
  }, [url]);

  const handleChange = (e) =>{
    console.log(e.target.value);
    const query = e.target.value;
    setInput(query);
    const search = () => {
      const queryData = data.filter((item) => {
        return item.title.toLowerCase().includes(query.toLowerCase());
      });
      setFilteredData(queryData);
    };

    const optimisedSearch = deBouncing(search, 100);
    optimisedSearch();
  }

  return (<div className="form">
  <input type="text" name="search" value={input} onChange={handleChange} />
  {input ? filteredData.map((item, index) => (
            <p key={index}>
              {item.id} - {item.title}
            </p>
          )) : data.map((item, index) => (
            <p key={index}>
              {item.id} - {item.title}
            </p>
          ))
  }
  </div>);
}

export default UseFetch;