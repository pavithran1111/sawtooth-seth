import React from 'react';
import { Routes, Route, useLocation} from "react-router-dom";
import Home from "./Home";
import Employee from "./Employee";
import About from "./About";
import Contact from "./Contact";
import AddEmployee from "./AddEmployee";
import EditEmployee from "./EditEmployee";
import Todo from "./Toto";
import SignIn from "./SignIn";
import Register from "./Register";
import Form from "./Form";
import Counter from "./Counter";
import FollowerList from "./FollowerList";
import UserList from "./UserList";
import DemoReducer from "./DemoReducer";
import {AnimatePresence} from "framer-motion";

const AnimatesRoutes = () => {
  const location = useLocation();
  return (
    <AnimatePresence mode="wait">
      <Routes key={location.pathname} location={location}>
        <Route path="/" element={<Home />} />
        <Route path="/employee" element={<Employee />} />
        <Route path="/about-us" element={<About />} />
        <Route path="/contact-us" element={<Contact />} />
        <Route path="/add-employee" element={<AddEmployee />} />
        <Route path="/edit-employee/:id" element={<EditEmployee />} />
        <Route path="/todo" element={<Todo />} />
        <Route path="/sign-in" element={<SignIn />} />
        <Route path="/register" element={<Register />} />
        <Route path="/form" element={<Form />} />
        <Route path="/counter" element={<Counter />} />
        <Route path="/FollowerList" element={<FollowerList />} />
        <Route path="/UserList" element={<UserList />} />
        <Route path="/DemoReducer" element={<DemoReducer />} />
      </Routes>
    </AnimatePresence>
  )
}

export default AnimatesRoutes;