import {motion} from "framer-motion";
import AddData  from "./AddData";
import React, { Suspense, useCallback, useEffect, useMemo, useRef, useState } from "react";

//Filter
import UseFetch from "./UseFetch";
import "../css/Form.css";
import A from "./A";
//Code splitting & lazy loading
// import First from "./First";
import Second from "./Second";
const First = React.lazy(()=>import("./First"));

const squareNumber = ((input)=> {
  console.log("Squaring will be done!", input);
  return Math.pow(input, 2);
});

const Form = () => {
  const [count, setCount] = useState(10);
  const name = useRef(0);
  const address = useRef();
  const [number, setNumber] = useState(0);
  const expensiveValue = useMemo(() => squareNumber(number), [number]);
  const [todo, setTodo] = useState([]);
  const [data, setData] = useState();

  useEffect(()=>{
    console.log('run useEffect');
    address.current.focus();
  },[count]);
  
  //useFetch("https://jsonplaceholder.typicode.com/todos");
  const handleSubmit = (e)=>{
    e.preventDefault();
    console.log(e.target.username.value)
    console.log('ref name', name.current.value)
    console.log(e.target.address.value)
  }

  const handleChange = (e) =>{
    console.log(name.current.value);
    //setName(() => e.target.value)
  }

  const numberChange = (e) => {
    setNumber(e.target.value);
  }

  const handleClick = (e)=>setCount((prev)=> e.target.name === "plus" ? prev+1 : prev-1);

  const addTodo = useCallback(() => {
    console.log(data)
    setTodo((a)=> [...a, data]);
  }, [data]);

  const getData = useCallback((e) =>{
    setData(e.target.value)
  }, []);

  return (
    <motion.div initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    exit={{ opacity: 0 }}
    transition={{ duration: .5 }}>
      <Suspense fallback={<h1>Loading....</h1>}>
      <First />
      </Suspense>
      <Second />
      <A />
      {count}
      <button onClick={handleClick} name="plus">Increment</button>
      <button onClick={handleClick} name="minus">decrement</button>
      <h1>Hello Square {expensiveValue}</h1>
      <form onSubmit={handleSubmit} className="form">
        <input type="text" name="username" ref={name} onChange={handleChange} />
        <input type="text" name="address" ref={address} />
        <input type="number" name="number" value={number} onChange={numberChange} />
        <input type="submit" value="Submit" />
      </form>
      <AddData todo={todo} addTodo={addTodo} getData={getData} />
      <UseFetch url={"https://jsonplaceholder.typicode.com/todos"} />
      {/* <div className="form">
        <input type="text" name="search" onChange={handleSearch} />
        {data && data.map((item)=> <p key={item.id}>{item.title}</p>)}
      </div> */}
    </motion.div>
  )
}

export default Form;