import React from "react";
import B from "./B";
import {AppContext} from './context';
let Color = React.createContext();
let Size = React.createContext();
const b = [1,3,5,6,7,88,23]
const A = ()=>{
  return(<AppContext.Provider value={b}>
    <Color.Provider value="[a,s,ef,fd,t,hst,rht]">
    <Size.Provider value="32">
      <B />
      </Size.Provider>
    </Color.Provider>
    </AppContext.Provider>)
}
export {Color, Size}
export default A;