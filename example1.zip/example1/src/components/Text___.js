import {render, screen, cleanup} from "@testing-library/react";
import "@testing-library/jest-dom";

// afterEach function runs after each test suite is executed
afterEach(()=>{
  cleanup();
})

//Text 1 - Testing if the text element is rendered correctly to the DOM.
describe('Text Component', ()=>{
  test('Text Rendering', ()=>{
    render(<Text toggle={true} displayTxt={"GeeksForGeeks"} />);
    const text = screen.getByTestId("text");
    expect(text).toBeInTheDocument();
  });

  //Test 2: Testing the content of the text element when the toggle is set to true.
  test("Displaying the text when toggle is set to true", ()=>{

    render(<Text toggle={true} displayTxt={"GeeksForGeeks"} />);
    const text = screen.getByTestId("text");
    expect(text).toHaveTextContent("GeeksForGeeks");

  });

    //Test 3: Testing the content of the text element when the toggle is set to false.
    test("Displaying the text when toggle is set to false", ()=>{

      render(<Text toggle={false} displayTxt={"GeeksForGeeks"} />);
      const text = screen.getByTestId("text");
      expect(text).toBeEmptyDOMElement();
  
    });

});




