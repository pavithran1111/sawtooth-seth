import { memo } from "react";
import {motion} from "framer-motion";

const AddData = ({todo, addTodo, getData}) => {
  console.log("child render");
  return (
    <motion.div initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    exit={{ opacity: 0 }}
    transition={{ duration: .5 }}>
      <h2>My Data</h2>
      <input type="text" onBlur={getData} />
      {todo.map((to, index) =>{
        return <p key={index}>{to}</p>
      })}
      <button onClick={addTodo}>Add Todo</button>
    </motion.div>
  )
}

export default memo(AddData);