import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import {motion} from "framer-motion";

const AddEmployee = () => {
const navigate = useNavigate()
const { register, formState: { errors },  handleSubmit } = useForm();

  axios.interceptors.request.use(
    function (req) {
      console.log('req');
      req.time = { startTime: new Date() };
      console.log('req', req)
      return req;
    },
    (err) => {
      return Promise.reject(err);
    }
  );

  axios.interceptors.response.use(
    function (res) {
      console.log('res');
      res.config.time.endTime = new Date();
      res.duration =
        res.config.time.endTime - res.config.time.startTime;
        console.log('res',res)
        console.log('Duration',res.duration)
      return res;
    },
    (err) => {
      return Promise.reject(err);
    }
  );

const onSubmit = (data) => {
  console.log(data)
  axios.post('http://localhost:3001/employee', data).then((res)=>{
    if(res.status === 200)
    navigate(`/employee`, { replace: true });
  })
  .catch((err)=>{
    console.log(err)
  })
}

  return (
    <motion.div initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    exit={{ opacity: 0 }}
    transition={{ duration: .5 }}>
      <h1>Add Employee</h1>
      <form onSubmit={handleSubmit(onSubmit)}>
        <label>Name</label>
        <input type="text" {...register('name', {required: true})} />
        {errors.name?.type === 'required' && <span>Name is required</span>}
      <button type="submit">Add</button>
      </form>
    </motion.div>
  )
}

export default AddEmployee;