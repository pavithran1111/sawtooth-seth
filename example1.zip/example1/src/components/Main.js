import React, {useState} from 'react';
import {Link} from "react-router-dom";
import Logo from '../logo.svg';
import AnimatesRoutes from "./AnimatesRoutes";
import "../css/Main.css";
const Nav = () => {
  const [open, setOpen] = useState('close');
  const openSlide = ()=>{
    setOpen('open-nav');
  }
  const closeSlide = ()=>{
    setOpen('close');
  }
  return (
    <div>
      <header className={`header ${open}`}>
        <div className='logo'>
          <a href='/'><img src={`${Logo}`} width={75} alt="logo" /></a>
        </div>
        <div className='menu-nav'>
          <ul className="menu-nav-list">
            <li><Link to="/" className="arrow-down">Home</Link></li>
            <li><Link to="/employee" className="arrow-down">Employee</Link></li>
            <li><Link to="/about-us" className="arrow-down">About Us</Link></li>
            <li><Link to="/contact-us" className="arrow-down">Contact Us</Link></li>
            <li><Link to="/todo" className="arrow-down">Todo List</Link></li>
          </ul>
        </div>
        <button className="btn-mobile-nav">
        <ion-icon className="icon-mobile-nav" name="menu-outline" onClick={openSlide}></ion-icon>
        <ion-icon className="icon-mobile-nav" name="close-outline" onClick={closeSlide}></ion-icon>
      </button>
      </header>
      <AnimatesRoutes />
    </div>
  )
}

export default Nav;