import axios from "axios";
import { useEffect, useState } from "react";


const debouncingFunc = (func, delay) => {
  let timerId;
  return function () {
    const context = this;
    const args = arguments;
    clearTimeout(timerId);
    timerId = setTimeout(function () {
      func.apply(context, args);
    }, delay);
  };
};

export default function App() {
  const [input, setInput] = useState("");
  const [data, setData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);

  useEffect(() => {
    (async () => {
      const result = await axios.get(
        "https://jsonplaceholder.typicode.com/todos"
      );
      setData(result.data);
    })();
  }, []);

  const handleChange = (e) => {
    const query = e.target.value;
    setInput(query);

    const search = () => {
      const queryData = data.filter((item) => {
        return item.title.toLowerCase().includes(query.toLowerCase());
      });
      setFilteredData(queryData);
    };
    const optimisedSearch = debouncingFunc(search, 500);
    optimisedSearch();
  };

  return (
    <div className="form">
      <input
        type="text"
        name="input"
        id=""
        value={input}
        placeholder="search something..."
        onChange={handleChange}
      />
      <div>
        {input ? filteredData.map((item) => <p key={item.id}>{item.title}</p>): data.map((item) => <p key={item.id}>{item.title}</p>)}
      </div>
    </div>
  );
}
