import ImgDesk from "../images/hp-tech-to-watch-hero-desktop.webp";
import { Link } from "react-router-dom";
import {motion} from "framer-motion";

const Home = () => {
  return (
    <div className="img-background">
    <motion.div 
      initial={{ x: -550 }}
      animate={{ x: 0 }}
      exit={{ x: 550 }}
      transition={{ ease:"easeIn", duration: .3 }}
      >
      <picture>
      <source type="image/webp" media="(max-width: 1023px)" srcSet="https://cognizant.scene7.com/is/image/cognizant/hp-tech-to-watch-hero-tablet" />
      <source type="image/webp" media="(min-width: 1024px)" srcSet="https://cognizant.scene7.com/is/image/cognizant/hp-cybersecurity-hero-desktop" />
      <img height="50" width="100" className="img-main" src={`${ImgDesk}`} alt="Tech to watch" />
      </picture>
      <div className="img-text">
        <h1>Generate new value from new technologies</h1>
        <p>Get started with the state of global payments, our comprehensive industry analysis.
        </p>
        <Link href="#" className="banner-button">
          <span className="button-text">Find out how</span>
        </Link>
      </div>
      </motion.div>
    </div>
  )
}

export default Home;