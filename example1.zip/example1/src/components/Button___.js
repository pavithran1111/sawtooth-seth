//Reference: https://www.geeksforgeeks.org/how-to-test-react-components-using-jest/
import {render,screen, cleanup, getByTestId} from "@testing-library/react";
import "@testing-library/jest-dom";
import Button from "./Button";

afterEach(()=>{
  cleanup(); //Reset the DOM after each test suits
});

describe('Button Component', ()=>{
  const setToggle = jest.fn();
  render(<Button setToggle={setToggle} btnText="Click Me!" />);
  const button = screen.getByTestId("button");

  // Test 1
  test("Button Rendering", () => {
    expect(button).toBeInTheDocument();
})

// Test 2 
test("Button Text", () => {
    expect(button).toHaveTextContent("Click Me!");
})
});
