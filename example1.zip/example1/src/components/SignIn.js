import {motion} from "framer-motion";
import { useState } from "react";
import { useForm } from "react-hook-form";
import '../css/SignIn.css';
const SignIn = () => {
  const { handleSubmit, register, setError, formState: { errors } } = useForm();

  const onSubmit = values => alert(values.email + " " + values.password);

  const [popupStyle, showpopUp] = useState('hide');

  const popup = ()=>{
    showpopUp('login-popup');
    setTimeout(()=> showpopUp('hide'), 3000);
  }
  

  return (
    <motion.div initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    exit={{ opacity: 0 }}
    transition={{ duration: .5 }}>
      
    <div className="login-wrapper">
      <form onSubmit={handleSubmit(onSubmit)} className="form-wrapper">
        <h1>Log In</h1>
        <input id="email" className="input" placeholder="Email" type="text" {...register('email', { required: true, pattern: {value:/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i} } )}  />
        {errors.email && errors.email.type === "required" && (
          <span className="form-errors">Username/Email is required</span>
        )}
        <input id="password" className="input" placeholder="Password" {...register('password', {required: true} )} type="password" />
        {errors.password && errors.password.type == "required" && (
          <span className="form-errors">Passowrd is required</span>
        )}
        <input /*onClick={popup}*/ className="submit" type="submit" />
        <p className="text">Or Login using</p>
        <div className="alt-login">
          <div className="facebook"></div>
          <div className="google"></div>
        </div>
        <div className={popupStyle}>
          <h2>Login Failed</h2>
          <div>Username or passowrd is incorrect</div>
        </div>
      </form>
    </div>

    </motion.div>
  )
}

export default SignIn;