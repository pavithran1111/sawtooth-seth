import { useEffect, useState } from "react";
import axios from "axios";
import {motion} from "framer-motion";
// import { useNavigate } from "react-router-dom";
const BASE_URL = 'http://localhost:3001';


// const contentVariable = {
//   initial:{
//     y:10,
//     opacity: 0
//   },
//   enter: {
//     y:0,
//     opacity: 1
//   },
//   exit: {
//     y:-10,
//     opacity: 0
//   }
// }

const Employee = () => {
  const [data, setData] = useState([])
  // const navigate = useNavigate()
  useEffect(()=>{
    fetchData()
  },[]);

  const handleDelete = async id => {
    if(window.confirm('Are you need to delete?') === true){
      const res = await axios.delete(`${BASE_URL}/delete/${id}`)
      console.log(res)
      window.location.reload(false)
    }
  }


  const fetchData = async () => {
    let res = await axios.get(`${BASE_URL}/employee`)
    setData(res?.data)
  }

  return (
    <div className="container">
    <div className="content-container">
      <motion.div
        initial={{ x: -550 }}
        animate={{ x: 0}}  
        exit={{ x: 550 }}
        transition= {{
          ease: "easeIn",
          duration: 0.3,
      }}
      >
      <h1 className="heading">Listing</h1>
      <a href="/add-employee">Add Employee</a>
      <table className="table">
        <thead>
        <tr className="row">
          <th className="cell">S.No</th>
          <th className="cell">Name</th>
          <th className="cell">Edit</th>
          <th className="cell">Delete</th>
        </tr>
        </thead>
      <tbody>
      {data && data.map((value, index)=>(
        <tr key={index+1} className="row">
          <td className="cell">{index+1}</td>
          <td className="cell">{value.name}</td>
          <td className="cell"><a href={`edit-employee/${value._id}`} className="edit-button">Edit</a></td>
          <td className="cell"><p onClick={()=> handleDelete(value._id)} className="delete-button">Delete</p></td>
        </tr>
      ))}
      </tbody>
      </table>
      </motion.div>
    </div>
    </div>
  )
}

export default Employee;