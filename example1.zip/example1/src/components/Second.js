import React from "react";

const Second = ()=>{
  return(<div>Second</div>)
}

export default Second;