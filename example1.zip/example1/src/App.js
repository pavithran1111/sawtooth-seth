import './css/App.css';
import Main from './components/Main';
import { BrowserRouter as Router, Link} from 'react-router-dom';
import {AnimatePresence} from 'framer-motion';
import Text from './components/Text';
import Button from './components/Button';
import { useState } from 'react';

function App() {
  const [toggle, setToggle] = useState(true);

  const [menu, setMenu] = useState(['Home', 'About Us', 'Contact Us', 'Gallery']);
  return (
    <AnimatePresence>
    <div className="App">
      <Router>
      <div className="global-header"><div className="global-left-header"><span>Personal</span><span>Business</span></div><div className="global-right-header"><Link to="/sign-in">Sign In</Link><span>or</span><Link to="/register">Register</Link></div></div>
      <Main />
      <Text toggle={toggle} displayTxt="GeeksForGeeks" />
      <Button setToggle={setToggle} btnTxt="Toggle text" />
      </Router>

      {/* <h1>Hello</h1>
      <div className='menu1'>
        {menu.map((item, index)=> <li key={index}>{item}</li>)}
      </div> */}
    </div>
    </AnimatePresence>
  );
}

export default App;