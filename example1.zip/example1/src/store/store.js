import {configStore } from "@reduxjs/toolkit";
import counterReducer from "../reducers/index";

const store = configStore({counter: counterReducer});

export default store;